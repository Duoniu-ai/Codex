import fs from "fs";
import path from "path";
import { randomUUID } from "crypto";
import { UserPlan, getUserById, saveUser } from "./auth";
import { vipPlans, creditPacks, VipPlan, CreditPack } from "./plans";

export type OrderType = "vip" | "credits";
export type OrderStatus = "pending" | "paid" | "cancelled";

export interface Order {
  id: string;
  userId: string;
  type: OrderType;
  planId?: UserPlan;
  creditAmount?: number;
  amount: number;
  status: OrderStatus;
  createdAt: string;
  paidAt: string | null;
}

export { vipPlans, creditPacks };
export type { VipPlan, CreditPack };

const DATA_DIR = path.join(process.cwd(), "data");
const ORDERS_FILE = path.join(DATA_DIR, "orders.json");

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function readOrders(): Record<string, Order> {
  ensureDataDir();
  if (!fs.existsSync(ORDERS_FILE)) {
    return {};
  }
  try {
    const raw = fs.readFileSync(ORDERS_FILE, "utf-8");
    return JSON.parse(raw) as Record<string, Order>;
  } catch {
    return {};
  }
}

function writeOrders(orders: Record<string, Order>) {
  ensureDataDir();
  fs.writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2), "utf-8");
}

export function saveOrder(order: Order): void {
  const orders = readOrders();
  orders[order.id] = order;
  writeOrders(orders);
}

export function getOrderById(id: string): Order | null {
  const orders = readOrders();
  return orders[id] || null;
}

export function getOrdersByUser(userId: string): Order[] {
  const orders = readOrders();
  return Object.values(orders)
    .filter((o) => o.userId === userId)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export function createVipOrder(userId: string, planId: UserPlan): Order {
  const plan = vipPlans.find((p) => p.id === planId);
  if (!plan) {
    throw new Error("套餐不存在");
  }

  const order: Order = {
    id: randomUUID(),
    userId,
    type: "vip",
    planId,
    amount: plan.price,
    status: "pending",
    createdAt: new Date().toISOString(),
    paidAt: null,
  };

  saveOrder(order);
  return order;
}

export function createCreditsOrder(userId: string, packId: string): Order {
  const pack = creditPacks.find((p) => p.id === packId);
  if (!pack) {
    throw new Error("充值包不存在");
  }

  const order: Order = {
    id: randomUUID(),
    userId,
    type: "credits",
    creditAmount: pack.amount,
    amount: pack.price,
    status: "pending",
    createdAt: new Date().toISOString(),
    paidAt: null,
  };

  saveOrder(order);
  return order;
}

export function processOrderPayment(orderId: string): Order {
  const order = getOrderById(orderId);
  if (!order) {
    throw new Error("订单不存在");
  }
  if (order.status !== "pending") {
    throw new Error("订单状态异常");
  }

  const user = getUserById(order.userId);
  if (!user) {
    throw new Error("用户不存在");
  }

  if (order.type === "vip" && order.planId) {
    const plan = vipPlans.find((p) => p.id === order.planId);
    if (!plan) {
      throw new Error("套餐不存在");
    }

    user.plan = order.planId;
    user.vipExpiresAt = new Date(Date.now() + plan.periodDays * 24 * 60 * 60 * 1000).toISOString();
    if (plan.monthlyCredits > 0) {
      user.credits += plan.monthlyCredits;
    }
  } else if (order.type === "credits" && order.creditAmount) {
    user.credits += order.creditAmount;
  }

  saveUser(user);

  order.status = "paid";
  order.paidAt = new Date().toISOString();
  saveOrder(order);

  return order;
}
