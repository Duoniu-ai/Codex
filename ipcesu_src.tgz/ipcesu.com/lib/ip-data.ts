export interface IpInfo {
  ip: string;
  country: string;
  countryCode: string;
  region: string;
  city: string;
  isp: string;
  asn: string;
  lat: number;
  lng: number;
  timezone: string;
  score: number;
  scoreLabel: string;
  nativeIp: string;
  tags: string[];
  operatorType: string;
  trafficType: string;
  asnOrg: string;
  company: string;
  provider: string;
  cidr: string;
  asnType: string;
  ipRange: string;
  asnIpv4Count: string;
  bandwidth: string;
  asnRegistered: string;
  bogon: string;
  reverseDns: string;
  openPorts: number[];
  riskFlag: string;
  abuseLevel: string;
  abuseLevelColor: string;
  blacklist: string;
  rpki: string;
  vpn: string;
  proxy: string;
  tor: string;
  robot: string;
  globalPing: { region: string; countryCode: string; latency: string; color: string }[];
  geoSources: { source: string; country: string; countryCode: string; region: string; city: string; lat: number; lng: number }[];
  relatedDomains: string[];
  locationHistory: { date: string; country: string; countryCode: string; region: string; city: string }[];
  neighbors: string[];
  asnHistory: { date: string; asn: string; org: string }[];
  companyHistory: { date: string; company: string }[];
}

function hashIp(ip: string): number {
  let hash = 0;
  for (let i = 0; i < ip.length; i++) {
    hash = (hash << 5) - hash + ip.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

export function getEnhancedIpInfo(ip: string): IpInfo {
  if (ip === "127.0.0.1" || ip.startsWith("192.168.") || ip.startsWith("10.")) {
    return {
      ip,
      country: "本地",
      countryCode: "LO",
      region: "内网",
      city: "本地网络",
      isp: "Local Network",
      asn: "AS0",
      lat: 0,
      lng: 0,
      timezone: "Asia/Shanghai",
      score: 0,
      scoreLabel: "内网",
      nativeIp: "内网地址",
      tags: ["内网"],
      operatorType: "Local",
      trafficType: "-",
      asnOrg: "Local Network",
      company: "Local Network",
      provider: "Local Network",
      cidr: "-",
      asnType: "-",
      ipRange: "-",
      asnIpv4Count: "-",
      bandwidth: "-",
      asnRegistered: "-",
      bogon: "否（内网）",
      reverseDns: "-",
      openPorts: [],
      riskFlag: "安全",
      abuseLevel: "低",
      abuseLevelColor: "green",
      blacklist: "未列入",
      rpki: "Valid",
      vpn: "未检测到",
      proxy: "未检测到",
      tor: "未检测到",
      robot: "未检测到",
      globalPing: [],
      geoSources: [],
      relatedDomains: [],
      locationHistory: [],
      neighbors: [],
      asnHistory: [],
      companyHistory: [],
    };
  }

  const h = hashIp(ip);
  const isChina = ip.startsWith("116.") || ip.startsWith("117.") || ip.startsWith("118.") || ip.startsWith("119.") || ip.startsWith("120.") || ip.startsWith("121.") || ip.startsWith("122.") || ip.startsWith("123.") || ip.startsWith("124.") || ip.startsWith("125.") || ip.startsWith("126.") || ip.startsWith("175.") || ip.startsWith("180.") || ip.startsWith("182.") || ip.startsWith("183.") || ip.startsWith("219.") || ip.startsWith("220.") || ip.startsWith("221.") || ip.startsWith("222.") || ip.startsWith("223.");

  const chinaBase = { code: "CN", name: "中国", region: "浙江", city: "杭州", lat: 30.2741, lng: 120.1551, isp: "Chinanet", asn: "AS4134 CHINANET BACKBONE", org: "CHINANET-BACKBONE", company: "China Telecom", provider: "Chinanet", cidr: "103.106.229.0/24", asnType: "mixed", bandwidth: "300-500Gbps", asnRegistered: "2017-02-09" };
  const countries = [
    chinaBase,
    { code: "US", name: "美国", region: "California", city: "Los Angeles", lat: 34.0522, lng: -118.2437, isp: "Cloudflare", asn: "AS13335 CLOUDFLARENET", org: "CLOUDFLARENET", company: "Cloudflare, Inc.", provider: "Cloudflare", cidr: "172.245.236.0/24", asnType: "hosting", bandwidth: "10Tbps+", asnRegistered: "2010-07-23" },
    { code: "SG", name: "新加坡", region: "Singapore", city: "Singapore", lat: 1.3521, lng: 103.8198, isp: "BrainStorm Network", asn: "AS136258 BRAINSTORM-AS", org: "BRAINSTORM-AS", company: "BrainStorm Network, Inc", provider: "BrainStorm Network", cidr: "103.106.229.0/24", asnType: "business", bandwidth: "300-500Gbps", asnRegistered: "2017-02-09" },
    { code: "HK", name: "香港", region: "Hong Kong", city: "Hong Kong", lat: 22.3193, lng: 114.1694, isp: "HGC Global Communications", asn: "AS9304 HGCOMPASS", org: "HGCOMPASS", company: "HGC Global Communications Limited", provider: "HGC", cidr: "45.154.206.0/24", asnType: "hosting", bandwidth: "1-10Tbps", asnRegistered: "2005-08-18" },
    { code: "JP", name: "日本", region: "Tokyo", city: "Tokyo", lat: 35.6762, lng: 139.6503, isp: "NTT Communications", asn: "AS4713 NTT Communications Corporation", org: "ODN", company: "NTT Communications Corporation", provider: "NTT", cidr: "118.238.0.0/16", asnType: "isp", bandwidth: "10Tbps+", asnRegistered: "2004-09-08" },
  ];
  const base = isChina ? chinaBase : countries[h % countries.length];

  const tagsPool = ["机房IP", "家宽IP", "广播IP", "原生IP", "商业IP", "数据中心"];
  const tags = [tagsPool[h % tagsPool.length], tagsPool[(h + 2) % tagsPool.length]];
  if (isChina) {
    tags[0] = "机房IP";
    tags[1] = "商业IP";
  }

  const score = 30 + (h % 71);
  let scoreLabel = "一般";
  if (score >= 80) scoreLabel = "优秀";
  else if (score >= 60) scoreLabel = "良好";
  else if (score >= 40) scoreLabel = "一般";
  else scoreLabel = "较差";

  const isIpv6 = ip.includes(":");
  const parts = ip.split(".");
  const ipStart = !isIpv6 && parts.length === 4 ? `${parts[0]}.${parts[1]}.${parts[2]}.0` : ip;
  const ipEnd = !isIpv6 && parts.length === 4 ? `${parts[0]}.${parts[1]}.${parts[2]}.255` : ip;

  const globalPing = [
    { region: "上海", countryCode: "CN", latency: base.code === "CN" ? "12 ms" : "超时", color: base.code === "CN" ? "green" : "red" },
    { region: "香港", countryCode: "HK", latency: "28 ms", color: "green" },
    { region: "东京", countryCode: "JP", latency: "69 ms", color: "green" },
    { region: "新加坡", countryCode: "SG", latency: base.code === "SG" ? "2 ms" : "42 ms", color: "green" },
    { region: "洛杉矶", countryCode: "US", latency: "174 ms", color: "yellow" },
    { region: "温哥华", countryCode: "CA", latency: "211 ms", color: "yellow" },
    { region: "法兰克福", countryCode: "DE", latency: "234 ms", color: "yellow" },
    { region: "巴黎", countryCode: "FR", latency: "150 ms", color: "yellow" },
  ];

  const geoSources = [
    { source: "MaxMind", country: base.name, countryCode: base.code, region: base.region, city: base.city, lat: base.lat, lng: base.lng },
    { source: "IP2Location", country: base.name, countryCode: base.code, region: base.region, city: base.city, lat: base.lat + 0.01, lng: base.lng + 0.01 },
    { source: "DB-IP", country: base.name, countryCode: base.code, region: base.region, city: base.city, lat: base.lat - 0.01, lng: base.lng - 0.01 },
    { source: "IPinfo", country: base.name, countryCode: base.code, region: base.region, city: base.city, lat: base.lat + 0.005, lng: base.lng - 0.005 },
  ];

  const relatedDomains = [
    "example.com",
    "test-" + (h % 100) + ".net",
    "demo-" + ((h + 1) % 100) + ".org",
  ];

  const locationHistory = [
    { date: "2025-01", country: base.name, countryCode: base.code, region: base.region, city: base.city },
    { date: "2024-09", country: base.name, countryCode: base.code, region: base.region, city: base.city },
    { date: "2024-03", country: base.name, countryCode: base.code, region: base.region, city: base.city },
  ];

  const neighbors = isIpv6
    ? Array.from({ length: 6 }, (_, i) => {
        const hextets = ip.split(":");
        const lastIdx = hextets.length - 1;
        const last = parseInt(hextets[lastIdx] || "0", 16);
        const next = (last + ((h + i * 5) % 65535) + 1) % 65536;
        hextets[lastIdx] = next.toString(16);
        return hextets.join(":");
      })
    : [
        `${parts[0]}.${parts[1]}.${parts[2]}.${(h % 253) + 1}`,
        `${parts[0]}.${parts[1]}.${parts[2]}.${((h + 5) % 253) + 1}`,
        `${parts[0]}.${parts[1]}.${parts[2]}.${((h + 11) % 253) + 1}`,
        `${parts[0]}.${parts[1]}.${parts[2]}.${((h + 17) % 253) + 1}`,
        `${parts[0]}.${parts[1]}.${parts[2]}.${((h + 23) % 253) + 1}`,
        `${parts[0]}.${parts[1]}.${parts[2]}.${((h + 29) % 253) + 1}`,
      ];

  const asnHistory = [
    { date: "2024-06", asn: base.asn, org: base.org },
    { date: "2023-02", asn: "AS" + (10000 + (h % 90000)), org: "Legacy Network" },
  ];

  const companyHistory = [
    { date: "2024-06", company: base.company },
    { date: "2022-11", company: base.provider + " Legacy" },
  ];

  const abuseColors = ["green", "green", "yellow", "yellow", "red"];
  const abuseLevels = ["低", "低", "中", "中", "高"];
  const abuseIdx = h % abuseLevels.length;

  return {
    ip,
    country: base.name,
    countryCode: base.code,
    region: base.region,
    city: base.city,
    isp: base.isp,
    asn: base.asn,
    lat: base.lat,
    lng: base.lng,
    timezone: base.code === "CN" ? "Asia/Shanghai" : "UTC",
    score,
    scoreLabel,
    nativeIp: tags.includes("原生IP") ? "原生 IP" : "广播 IP (" + base.code + ")",
    tags,
    operatorType: ["Business", "ISP", "Hosting", "Enterprise"][h % 4],
    trafficType: ["机器偏多", "人机混合", "以人为主", "未知"][h % 4],
    asnOrg: base.org,
    company: base.company,
    provider: base.provider,
    cidr: base.cidr,
    asnType: base.asnType,
    ipRange: `${ipStart} - ${ipEnd}`,
    asnIpv4Count: (23000 + (h % 50000)).toLocaleString(),
    bandwidth: base.bandwidth,
    asnRegistered: base.asnRegistered,
    bogon: "否（公网可达）",
    reverseDns: "-",
    openPorts: [80, 443, ((h % 65535) + 1)],
    riskFlag: abuseIdx >= 4 ? "存在风险" : "未发现明显威胁",
    abuseLevel: abuseLevels[abuseIdx],
    abuseLevelColor: abuseColors[abuseIdx],
    blacklist: abuseIdx >= 4 ? "已列入" : "纯净",
    rpki: "Valid",
    vpn: "未检测到",
    proxy: "未检测到",
    tor: "未检测到",
    robot: abuseIdx >= 4 ? "检测到" : "未检测到",
    globalPing,
    geoSources,
    relatedDomains,
    locationHistory,
    neighbors,
    asnHistory,
    companyHistory,
  };
}
