import {
  Activity,
  Network,
  Globe,
  Shield,
  Search,
  Code,
  Bot,
  FileText,
  Lock,
  Clock,
  Server,
  Radio,
  Scan,
  Fingerprint,
  AlertTriangle,
  Cpu,
  Languages,
  BrainCircuit,
  Image,
  Sparkles,
  Link,
  ShieldCheck,
  Route,
  Layers,
  Copy,
  BarChart3,
  Type,
  CheckCircle,
  Hash,
  Bug,
  TrendingUp,
  Zap,
  Binary,
  Regex,
  CalendarClock,
  Fingerprint as FingerprintIcon,
  Cookie,
  MailCheck,
  Crosshair,
  Gauge,
  AppWindow,
  Unlink,
  FileSearch,
  type LucideIcon,
} from "lucide-react";

export interface Tool {
  id: string;
  label: string;
  description: string;
  href: string;
  icon: LucideIcon;
  category: string;
  badge?: string;
}

export interface ToolCategory {
  id: string;
  label: string;
  description: string;
  icon: LucideIcon;
}

export interface ToolTab {
  id: string;
  label: string;
  categories: string[];
}

export const toolCategories: ToolCategory[] = [
  {
    id: "network",
    label: "网络检测",
    description: "多节点网络性能与连通性检测",
    icon: Network,
  },
  {
    id: "speed",
    label: "网站测速",
    description: "HTTP 测速与网页性能分析",
    icon: Clock,
  },
  {
    id: "batch",
    label: "批量检测",
    description: "多目标批量并发检测",
    icon: Layers,
  },
  {
    id: "analysis",
    label: "数据分析",
    description: "SEO、SSL 与站长工具",
    icon: BarChart3,
  },
  {
    id: "domain",
    label: "域名网站",
    description: "域名解析、备案与注册信息",
    icon: Globe,
  },
  {
    id: "security",
    label: "安全工具",
    description: "网站安全与合规检测",
    icon: Shield,
  },
  {
    id: "seo",
    label: "SEO 优化",
    description: "网站排名与收录分析",
    icon: Search,
  },
  {
    id: "dev",
    label: "开发工具",
    description: "开发者常用编码与转换工具",
    icon: Code,
  },
  {
    id: "ai",
    label: "AI 工具",
    description: "基于大模型的智能辅助工具",
    icon: Bot,
  },
];

export const toolTabs: ToolTab[] = [
  { id: "all", label: "全部工具", categories: [] },
  { id: "network", label: "网络诊断", categories: ["network"] },
  { id: "speed", label: "网站测速", categories: ["speed"] },
  { id: "batch", label: "批量检测", categories: ["batch"] },
  { id: "analysis", label: "数据分析", categories: ["analysis"] },
];

export const tools: Tool[] = [
  // 网络诊断
  {
    id: "ping",
    label: "Ping 测试",
    description: "多节点网络延迟检测",
    href: "/ping",
    icon: Activity,
    category: "network",
  },
  {
    id: "ip",
    label: "IP 查询",
    description: "IP 归属地查询",
    href: "/ip",
    icon: Radio,
    category: "network",
  },
  {
    id: "dns",
    label: "DNS 查询",
    description: "域名解析记录查询",
    href: "/dns",
    icon: Server,
    category: "network",
  },
  {
    id: "traceroute",
    label: "路由追踪",
    description: "追踪网络路由路径",
    href: "/traceroute",
    icon: Route,
    category: "network",
  },
  {
    id: "tcping",
    label: "TCPing",
    description: "TCP 端口连通性检测",
    href: "/tcping",
    icon: Network,
    category: "network",
  },
  {
    id: "ping-ipv6",
    label: "Ping IPv6",
    description: "IPv6 网络延迟检测",
    href: "/ping-ipv6",
    icon: Globe,
    category: "network",
    badge: "IPv6",
  },
  {
    id: "tcping-ipv6",
    label: "TCPing IPv6",
    description: "IPv6 TCP 端口连通性检测",
    href: "/tcping-ipv6",
    icon: Globe,
    category: "network",
    badge: "IPv6",
  },
  {
    id: "traceroute-ipv6",
    label: "Traceroute IPv6",
    description: "IPv6 路由追踪",
    href: "/traceroute-ipv6",
    icon: Route,
    category: "network",
    badge: "IPv6",
  },
  {
    id: "bgp",
    label: "BGP 路由查询",
    description: "ASN 和路由信息查询",
    href: "/bgp",
    icon: Binary,
    category: "network",
  },

  // 网站测速
  {
    id: "http",
    label: "HTTP 检测",
    description: "网站状态码与响应头检测",
    href: "/http",
    icon: Link,
    category: "speed",
  },
  {
    id: "speed",
    label: "网站测速",
    description: "网页性能分析",
    href: "/speed",
    icon: Clock,
    category: "speed",
  },
  {
    id: "http-ipv6",
    label: "HTTP IPv6",
    description: "IPv6 网站测速",
    href: "/http-ipv6",
    icon: Globe,
    category: "speed",
    badge: "IPv6",
  },

  // 批量检测
  {
    id: "batch-ping",
    label: "批量 Ping",
    description: "多目标批量 Ping 检测",
    href: "/batch-ping",
    icon: Layers,
    category: "batch",
    badge: "限时免费",
  },
  {
    id: "batch-tcping",
    label: "批量 TCPing",
    description: "多目标批量 TCPing 检测",
    href: "/batch-tcping",
    icon: Copy,
    category: "batch",
    badge: "限时免费",
  },
  {
    id: "batch-http",
    label: "批量 HTTP(S)",
    description: "多目标批量 HTTP(S) 可用性检测",
    href: "/batch-http",
    icon: Copy,
    category: "batch",
    badge: "限时免费",
  },

  // 数据分析 / 站长工具
  {
    id: "ssl",
    label: "SSL 检测",
    description: "HTTPS 安全检测",
    href: "/ssl",
    icon: Lock,
    category: "analysis",
  },
  {
    id: "website-analysis",
    label: "网站分析",
    description: "SEO、性能、安全综合评估",
    href: "/website-analysis",
    icon: BarChart3,
    category: "analysis",
  },
  {
    id: "seo-diagnosis",
    label: "SEO 诊断",
    description: "网站 SEO 问题诊断",
    href: "/seo-diagnosis",
    icon: Search,
    category: "analysis",
  },
  {
    id: "tdk-check",
    label: "TDK 检测",
    description: "标题、描述、关键词检测",
    href: "/tdk-check",
    icon: Type,
    category: "analysis",
  },
  {
    id: "http-status",
    label: "HTTP 状态检测",
    description: "批量 URL 状态码检测",
    href: "/http-status",
    icon: CheckCircle,
    category: "analysis",
  },
  {
    id: "keyword-density",
    label: "关键词密度",
    description: "页面关键词分布分析",
    href: "/keyword-density",
    icon: Hash,
    category: "analysis",
  },
  {
    id: "backlink-check",
    label: "友情链接查询",
    description: "检测友链有效性与 SEO 价值",
    href: "/backlink-check",
    icon: Link,
    category: "analysis",
  },
  {
    id: "spider",
    label: "蜘蛛抓取",
    description: "模拟搜索引擎蜘蛛抓取",
    href: "/spider",
    icon: Bug,
    category: "analysis",
  },
  {
    id: "optimization",
    label: "SEO 优化",
    description: "全面 SEO 优化建议",
    href: "/optimization",
    icon: TrendingUp,
    category: "analysis",
  },

  // 域名网站
  {
    id: "whois",
    label: "Whois 查询",
    description: "域名注册信息",
    href: "/whois",
    icon: FileText,
    category: "domain",
  },
  {
    id: "icp",
    label: "ICP 备案",
    description: "域名备案信息查询",
    href: "/icp",
    icon: ShieldCheck,
    category: "domain",
  },
  {
    id: "cdn",
    label: "CDN 检测",
    description: "CDN 厂商识别",
    href: "/cdn",
    icon: Server,
    category: "domain",
  },

  // 安全工具
  {
    id: "portscan",
    label: "端口扫描",
    description: "主机端口检测",
    href: "/portscan",
    icon: Scan,
    category: "security",
  },
  {
    id: "security",
    label: "网站安全检测",
    description: "安全配置分析",
    href: "/security",
    icon: Shield,
    category: "security",
  },
  {
    id: "waf",
    label: "WAF 检测",
    description: "防火墙识别",
    href: "/waf",
    icon: Fingerprint,
    category: "security",
  },
  {
    id: "cors",
    label: "CORS 检测",
    description: "跨域配置安全检测",
    href: "/cors",
    icon: Crosshair,
    category: "security",
  },
  {
    id: "cookie-security",
    label: "Cookie 安全",
    description: "Cookie 安全配置检测",
    href: "/cookie-security",
    icon: Cookie,
    category: "security",
  },
  {
    id: "sensitive-info",
    label: "敏感信息泄露",
    description: "敏感文件泄露检测",
    href: "/sensitive-info",
    icon: AlertTriangle,
    category: "security",
  },
  {
    id: "email-security",
    label: "邮件安全检测",
    description: "SPF/DKIM/DMARC 检测",
    href: "/email-security",
    icon: MailCheck,
    category: "security",
  },

  // SEO 优化
  {
    id: "seo",
    label: "SEO 检测",
    description: "SEO 基础配置检测",
    href: "/seo",
    icon: Search,
    category: "seo",
  },
  {
    id: "dead-link",
    label: "死链检测",
    description: "无效链接检测",
    href: "/dead-link",
    icon: Unlink,
    category: "seo",
  },
  {
    id: "robots-txt",
    label: "Robots 检测",
    description: "爬虫规则分析",
    href: "/robots-txt",
    icon: FileSearch,
    category: "seo",
  },
  {
    id: "core-web-vitals",
    label: "Core Web Vitals",
    description: "核心网页指标检测",
    href: "/core-web-vitals",
    icon: Gauge,
    category: "seo",
  },
  {
    id: "open-graph",
    label: "Open Graph",
    description: "社交分享标签检测",
    href: "/open-graph",
    icon: AppWindow,
    category: "seo",
  },

  // 开发工具
  {
    id: "json",
    label: "JSON 格式化",
    description: "JSON 美化压缩校验",
    href: "/json",
    icon: Code,
    category: "dev",
  },
  {
    id: "base64",
    label: "Base64 编解码",
    description: "Base64 编码解码",
    href: "/base64",
    icon: FileText,
    category: "dev",
  },
  {
    id: "url-encode",
    label: "URL 编解码",
    description: "URL 编码解码工具",
    href: "/url-encode",
    icon: Link,
    category: "dev",
  },
  {
    id: "hash",
    label: "Hash 生成器",
    description: "MD5/SHA 哈希生成",
    href: "/hash",
    icon: Hash,
    category: "dev",
  },
  {
    id: "regex",
    label: "正则测试",
    description: "在线正则表达式测试",
    href: "/regex",
    icon: Regex,
    category: "dev",
  },
  {
    id: "timestamp",
    label: "时间戳转换",
    description: "时间戳日期互转",
    href: "/timestamp",
    icon: CalendarClock,
    category: "dev",
  },
  {
    id: "uuid",
    label: "UUID 生成器",
    description: "批量生成 UUID",
    href: "/uuid",
    icon: FingerprintIcon,
    category: "dev",
  },
];

export const aiTools: Array<Omit<Tool, "category"> & { category?: string }> = [
  {
    id: "chat",
    label: "AI 智能对话",
    description: "智能问答助手",
    href: "/ai-tools/chat",
    icon: Bot,
  },
  {
    id: "content",
    label: "AI 文案生成",
    description: "营销文案创作",
    href: "/ai-tools/content",
    icon: Sparkles,
  },
  {
    id: "code",
    label: "AI 代码助手",
    description: "代码生成优化",
    href: "/ai-tools/code",
    icon: Code,
  },
  {
    id: "seo",
    label: "AI SEO 优化",
    description: "SEO 优化建议",
    href: "/ai-tools/seo",
    icon: Search,
  },
  {
    id: "security",
    label: "AI 安全分析",
    description: "网站安全分析",
    href: "/ai-tools/security",
    icon: Shield,
  },
  {
    id: "summary",
    label: "AI 智能摘要",
    description: "内容智能摘要",
    href: "/ai-tools/summary",
    icon: FileText,
  },
  {
    id: "translate",
    label: "AI 翻译助手",
    description: "多语言翻译",
    href: "/ai-tools/translate",
    icon: Languages,
  },
  {
    id: "image",
    label: "AI 图片分析",
    description: "智能图片识别",
    href: "/ai-tools/image",
    icon: Image,
  },
];

export const stats = [
  { label: "全球节点", value: "100+", description: "覆盖全国及海外主要地区" },
  { label: "监控任务", value: "10万+", description: "实时监控网站可用性" },
  { label: "活跃用户", value: "5万+", description: "专业运维人员信赖" },
  { label: "响应速度", value: "99.9%", description: "高可用性保障" },
];
