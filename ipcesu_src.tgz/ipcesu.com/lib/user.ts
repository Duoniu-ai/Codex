export type UserPlan = "free" | "pro" | "enterprise";

export interface SafeUser {
  id: string;
  email: string;
  credits: number;
  plan: UserPlan;
  vipExpiresAt: string | null;
  createdAt: string;
}
