import { UserPlan } from "./user";

export interface VipPlan {
  id: UserPlan;
  name: string;
  price: number;
  periodDays: number;
  qps: string;
  monthlyCredits: number;
  features: string[];
  recommended: boolean;
}

export interface CreditPack {
  id: string;
  amount: number;
  price: number;
}

export const vipPlans: VipPlan[] = [
  {
    id: "pro",
    name: "专业版",
    price: 99,
    periodDays: 30,
    qps: "20",
    monthlyCredits: 50000,
    features: ["全部工具调用", "20 QPS 限制", "每月 50,000 积分", "优先工单支持"],
    recommended: true,
  },
  {
    id: "enterprise",
    name: "企业版",
    price: 999,
    periodDays: 30,
    qps: "不限",
    monthlyCredits: 0,
    features: ["全部工具调用", "不限 QPS", "不限调用次数", "专属技术支持", "定制开发"],
    recommended: false,
  },
];

export const creditPacks: CreditPack[] = [
  { id: "credits-100", amount: 100, price: 10 },
  { id: "credits-500", amount: 500, price: 45 },
  { id: "credits-2000", amount: 2000, price: 160 },
];

export function formatPrice(price: number): string {
  return `¥${price}`;
}

export function planBenefits(plan: UserPlan) {
  switch (plan) {
    case "enterprise":
      return { qps: "不限", monthlyCredits: "不限", support: "专属技术支持" };
    case "pro":
      return { qps: "20", monthlyCredits: "50,000", support: "工单支持" };
    default:
      return { qps: "5", monthlyCredits: "1,000", support: "社区支持" };
  }
}
