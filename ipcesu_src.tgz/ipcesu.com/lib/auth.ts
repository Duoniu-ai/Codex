import fs from "fs";
import path from "path";
import { randomUUID } from "crypto";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { cookies } from "next/headers";
import { NextRequest, NextResponse } from "next/server";
import { UserPlan } from "./user";

export type { UserPlan } from "./user";

export interface User {
  id: string;
  email: string;
  passwordHash: string;
  credits: number;
  plan: UserPlan;
  vipExpiresAt: string | null;
  createdAt: string;
}

export interface SafeUser {
  id: string;
  email: string;
  credits: number;
  plan: UserPlan;
  vipExpiresAt: string | null;
  createdAt: string;
}

const JWT_SECRET = process.env.JWT_SECRET || "ipcesu-default-secret-change-me";
const TOKEN_MAX_AGE = 60 * 60 * 24 * 7; // 7 天

const DATA_DIR = path.join(process.cwd(), "data");
const USERS_FILE = path.join(DATA_DIR, "users.json");

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function readUsers(): Record<string, User> {
  ensureDataDir();
  if (!fs.existsSync(USERS_FILE)) {
    return {};
  }
  try {
    const raw = fs.readFileSync(USERS_FILE, "utf-8");
    return JSON.parse(raw) as Record<string, User>;
  } catch {
    return {};
  }
}

function writeUsers(users: Record<string, User>) {
  ensureDataDir();
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), "utf-8");
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10);
}

export async function verifyPassword(
  password: string,
  hash: string
): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function createToken(user: User): string {
  return jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET, {
    expiresIn: TOKEN_MAX_AGE,
  });
}

export function verifyToken(token: string): { userId: string; email: string } | null {
  try {
    return jwt.verify(token, JWT_SECRET) as { userId: string; email: string };
  } catch {
    return null;
  }
}

export function getUserByEmail(email: string): User | null {
  const users = readUsers();
  return Object.values(users).find(
    (u) => u.email.toLowerCase() === email.toLowerCase()
  ) || null;
}

export function getUserById(id: string): User | null {
  const users = readUsers();
  return users[id] || null;
}

export function saveUser(user: User): void {
  const users = readUsers();
  users[user.id] = user;
  writeUsers(users);
}

export async function createUser(input: {
  email: string;
  password: string;
}): Promise<User> {
  const existing = getUserByEmail(input.email);
  if (existing) {
    throw new Error("该邮箱已注册");
  }

  const passwordHash = await hashPassword(input.password);
  const user: User = {
    id: randomUUID(),
    email: input.email.trim().toLowerCase(),
    passwordHash,
    credits: 100,
    plan: "free",
    vipExpiresAt: null,
    createdAt: new Date().toISOString(),
  };

  saveUser(user);
  return user;
}

export function toSafeUser(user: User): SafeUser {
  const { passwordHash, ...safe } = user;
  return safe;
}

export function setAuthCookie(response: NextResponse, token: string): void {
  response.cookies.set("token", token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: TOKEN_MAX_AGE,
    path: "/",
  });
}

export function clearAuthCookie(response: NextResponse): void {
  response.cookies.set("token", "", {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 0,
    path: "/",
  });
}

export function getTokenFromRequest(req: NextRequest): string | undefined {
  return req.cookies.get("token")?.value;
}

export async function getCurrentUser(): Promise<User | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get("token")?.value;
  if (!token) return null;

  const payload = verifyToken(token);
  if (!payload) return null;

  return getUserById(payload.userId);
}

export async function checkAndDeductCredits(
  req: NextRequest,
  amount = 1
): Promise<{ user?: SafeUser; error?: string }> {
  const token = getTokenFromRequest(req);
  if (!token) return {};

  const payload = verifyToken(token);
  if (!payload) {
    return { error: "登录已过期，请重新登录" };
  }

  const user = getUserById(payload.userId);
  if (!user) {
    return { error: "用户不存在" };
  }

  if (user.plan === "enterprise") {
    return { user: toSafeUser(user) };
  }

  if (user.credits < amount) {
    return { error: "积分不足，请充值或升级 VIP" };
  }

  user.credits -= amount;
  saveUser(user);

  return { user: toSafeUser(user) };
}
