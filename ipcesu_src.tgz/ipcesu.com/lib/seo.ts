import type { Metadata } from "next";

export const SITE_NAME = "IPcesu 工具站";
export const SITE_URL = "https://ipcesu.com";
export const SITE_DESCRIPTION =
  "IPcesu 是专业的在线网络工具站，提供 Ping 测试、IP 查询、DNS 查询、SSL 检测、Whois 查询、Traceroute 路由追踪、网站测速、SEO 诊断等数十种免费网络检测与网站分析工具。";
export const SITE_KEYWORDS = [
  "IPcesu",
  "在线工具",
  "网络工具",
  "Ping 测试",
  "IP 查询",
  "DNS 查询",
  "SSL 检测",
  "Whois 查询",
  "Traceroute",
  "路由追踪",
  "网站测速",
  "TCPing",
  "端口扫描",
  "SEO 诊断",
  "网站监控",
  "网络诊断",
  "HTTP 检测",
  "ICP 备案查询",
  "CDN 检测",
  "WAF 检测",
].join(", ");

export const CATEGORY_KEYWORDS: Record<string, string> = {
  network:
    "Ping 测试, IP 查询, DNS 查询, Traceroute, TCPing, 路由追踪, IPv6 测试, BGP 路由, 网络连通性, 网络延迟",
  speed:
    "网站测速, HTTP 检测, IPv6 测速, 网页性能, 响应时间, 网站速度测试, 页面加载速度",
  batch:
    "批量 Ping, 批量 TCPing, 批量 HTTP, 批量检测, 多目标检测, 并发检测",
  analysis:
    "SSL 检测, 网站分析, SEO 诊断, TDK 检测, HTTP 状态, 关键词密度, 友情链接, 蜘蛛抓取, SEO 优化",
  domain:
    "Whois 查询, ICP 备案, CDN 检测, 域名注册信息, 域名解析, 备案查询",
  security:
    "端口扫描, 网站安全检测, WAF 检测, CORS 检测, Cookie 安全, 敏感信息泄露, 邮件安全检测",
  seo: "SEO 检测, 死链检测, Robots 检测, Core Web Vitals, Open Graph, 搜索引擎优化, 网站排名",
  dev: "JSON 格式化, Base64 编解码, URL 编解码, Hash 生成, 正则测试, 时间戳转换, UUID 生成",
  ai: "AI 工具, AI 对话, AI 文案, AI 代码, AI SEO, AI 安全分析, AI 翻译, AI 图片分析",
};

interface SeoOptions {
  title: string;
  description: string;
  keywords?: string;
  path?: string;
  image?: string;
  noIndex?: boolean;
}

export function createMetadata(options: SeoOptions): Metadata {
  const { title, description, keywords, path, image, noIndex } = options;
  const url = path ? `${SITE_URL}${path}` : SITE_URL;
  const ogImage = image ?? `${SITE_URL}/og-image.png`;

  return {
    title,
    description,
    keywords: keywords ?? SITE_KEYWORDS,
    metadataBase: new URL(SITE_URL),
    alternates: {
      canonical: url,
    },
    openGraph: {
      title,
      description,
      url,
      siteName: SITE_NAME,
      locale: "zh_CN",
      type: "website",
      images: ogImage,
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: ogImage,
    },
    robots: noIndex
      ? { index: false, follow: false }
      : { index: true, follow: true },
  };
}

export function createToolMetadata(
  label: string,
  description: string,
  category: string,
  path: string
): Metadata {
  const keywords = [
    label,
    description,
    CATEGORY_KEYWORDS[category] ?? SITE_KEYWORDS,
    "在线工具, 免费工具, IPcesu",
  ].join(", ");

  return createMetadata({
    title: `${label} - 免费在线${label}工具`,
    description: `免费在线${label}：${description}。IPcesu 提供快速、准确的${label}服务，支持多节点检测，无需安装即可使用。`,
    keywords,
    path,
  });
}
