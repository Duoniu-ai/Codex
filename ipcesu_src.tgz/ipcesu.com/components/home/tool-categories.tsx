"use client";

import Link from "next/link";
import { tools, toolCategories } from "@/lib/tools";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Layers } from "lucide-react";

export function ToolCategories() {
  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-8">
          <div>
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Layers className="h-6 w-6 text-primary" />
              工具分类
            </h2>
            <p className="text-muted-foreground mt-1">
              全方位的网络检测与网站分析工具
            </p>
          </div>
          <Link
            href="/tools"
            className="hidden md:flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            查看全部 <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {toolCategories.map((category) => {
            const categoryTools = tools.filter(
              (tool) => tool.category === category.id
            );
            if (categoryTools.length === 0) return null;

            return (
              <Card
                key={category.id}
                className="h-full border border-border/40 bg-white hover:shadow-md transition-shadow duration-300 overflow-hidden"
              >
                <div className="flex items-center gap-3 px-4 py-3 bg-gradient-to-r from-slate-100 to-slate-50 border-b border-border/40">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
                    <category.icon className="h-5 w-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-base text-foreground">
                      {category.label}
                    </h3>
                  </div>
                  <Link
                    href={`/tools?category=${category.id}`}
                    className="text-xs text-muted-foreground hover:text-primary transition-colors shrink-0"
                  >
                    全部
                  </Link>
                </div>

                <CardContent className="p-4">
                  <div className="flex flex-wrap gap-2">
                    {categoryTools.slice(0, 8).map((tool) => (
                      <Link
                        key={tool.id}
                        href={tool.href}
                        className="inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-sm text-muted-foreground hover:bg-slate-100 hover:text-foreground transition-colors"
                        title={tool.description}
                      >
                        <tool.icon className="h-3.5 w-3.5 shrink-0" />
                        <span className="line-clamp-1">{tool.label}</span>
                      </Link>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
