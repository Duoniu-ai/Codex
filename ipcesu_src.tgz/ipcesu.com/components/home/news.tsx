"use client";

import Link from "next/link";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { newsData } from "@/lib/news-data";
import { ArrowRight, Newspaper, Calendar } from "lucide-react";

const categoryConfig: Record<
  string,
  { label: string; color: string; href: string }
> = {
  "技术教程": {
    label: "技术教程",
    color: "bg-orange-500/10 text-orange-600 hover:bg-orange-500/10",
    href: "/article?category=技术教程",
  },
  "帮助中心": {
    label: "帮助中心",
    color: "bg-emerald-500/10 text-emerald-600 hover:bg-emerald-500/10",
    href: "/article?category=帮助中心",
  },
  "网站公告": {
    label: "网站公告",
    color: "bg-blue-500/10 text-blue-600 hover:bg-blue-500/10",
    href: "/article?category=网站公告",
  },
};

const categoryOrder = ["技术教程", "帮助中心", "网站公告"];

export function News() {
  const latestByCategory = categoryOrder.map((category) => ({
    category,
    items: newsData
      .filter((item) => item.category === category)
      .sort(
        (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
      )
      .slice(0, 5),
  }));

  return (
    <section className="py-12 bg-white border-t border-border/40">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-red-500/10 rounded-lg">
              <Newspaper className="h-6 w-6 text-red-500" />
            </div>
            <div>
              <h2 className="text-2xl font-bold">热门资讯</h2>
              <p className="text-muted-foreground mt-1">
                技术教程、帮助中心与网站公告
              </p>
            </div>
          </div>
          <Link
            href="/article"
            className="hidden md:flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            更多资讯 <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {latestByCategory.map(({ category, items }) => {
            const config = categoryConfig[category];
            if (items.length === 0) return null;
            return (
              <Card
                key={category}
                className="h-full border border-border/40 bg-white hover:shadow-md transition-shadow duration-300 overflow-hidden"
              >
                <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-slate-100 to-slate-50 border-b border-border/40">
                  <div className="flex items-center gap-2">
                    <Badge
                      className={`text-xs border-0 ${config.color}`}
                    >
                      {config.label}
                    </Badge>
                  </div>
                  <Link
                    href={config.href}
                    className="text-xs text-muted-foreground hover:text-primary transition-colors"
                  >
                    更多
                  </Link>
                </div>
                <CardContent className="p-4">
                  <ul className="space-y-3">
                    {items.map((item) => (
                      <li key={item.id}>
                        <Link
                          href={`/article/${item.id}`}
                          className="group flex items-start gap-2 text-sm"
                        >
                          <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-muted-foreground/40 group-hover:bg-primary transition-colors" />
                          <div className="min-w-0 flex-1">
                            <span className="text-foreground group-hover:text-primary transition-colors line-clamp-1">
                              {item.title}
                            </span>
                            <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                              <Calendar className="h-3 w-3" />
                              <span>{item.date}</span>
                            </div>
                          </div>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
