"use client";

import Link from "next/link";
import { Code2, Zap, Shield, BarChart3, ArrowRight } from "lucide-react";

const features = [
  { icon: Zap, label: "快速响应" },
  { icon: Shield, label: "安全认证" },
  { icon: Code2, label: "详细文档" },
  { icon: BarChart3, label: "调用统计" },
];

export function ApiCta() {
  return (
    <section className="py-12 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid gap-8 md:grid-cols-2 items-center">
          <div className="rounded-xl border py-6 shadow-sm bg-slate-900 text-white overflow-hidden">
            <div className="px-6">
              <div className="flex items-center gap-2 text-slate-400 text-sm mb-4">
                <Code2 className="h-4 w-4" />
                <span>API调用示例</span>
              </div>
              <pre className="text-xs md:text-sm text-green-400 font-mono leading-relaxed overflow-x-auto">
                <code>{`curl -X POST https://api.ipcesu.com/v1/ping \\
  -H "Authorization: Bearer YOUR_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "target": "example.com",
    "nodes": ["beijing", "shanghai"]
  }'`}</code>
              </pre>
              <div className="mt-4 rounded-lg bg-slate-800 p-3 text-xs text-slate-400 font-mono">
                响应示例： {"{"} "status": "success", "avg": "45ms" {"}"}
              </div>
            </div>
          </div>

          <div className="flex flex-col justify-center">
            <div className="inline-flex w-fit items-center gap-1.5 px-2 py-1 rounded bg-orange-100 text-orange-600 text-xs mb-4">
              <Zap className="h-3 w-3" />
              开发者
            </div>
            <h2 className="text-3xl font-bold mb-4">
              开放API接口
            </h2>
            <p className="text-muted-foreground mb-6 text-sm leading-relaxed">
              提供标准化RESTful API，支持Ping测试、DNS查询、SSL检测等核心功能，轻松集成到您的业务系统。
            </p>
            <div className="grid grid-cols-2 gap-3 mb-6">
              {features.map((item) => (
                <div key={item.label} className="flex items-center gap-2 text-sm text-foreground">
                  <item.icon className="h-4 w-4 text-muted-foreground" />
                  {item.label}
                </div>
              ))}
            </div>
            <Link
              href="/api-docs"
              className="inline-flex w-fit items-center justify-center rounded-lg bg-foreground text-background px-5 py-2 text-sm font-medium transition-colors hover:bg-foreground/90"
            >
              查看API文档 <ArrowRight className="h-4 w-4 ml-2" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
