"use client";

import Link from "next/link";
import { aiTools } from "@/lib/tools";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

const iconColors = [
  "bg-blue-500/10 text-blue-600",
  "bg-emerald-500/10 text-emerald-600",
  "bg-orange-500/10 text-orange-600",
  "bg-purple-500/10 text-purple-600",
  "bg-red-500/10 text-red-600",
  "bg-pink-500/10 text-pink-600",
  "bg-cyan-500/10 text-cyan-600",
  "bg-indigo-500/10 text-indigo-600",
];

export function AiTools() {
  return (
    <section className="py-12 bg-white border-t border-border/40">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-lg">
              <Sparkles className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h2 className="text-2xl font-bold">AI 智能工具</h2>
              <p className="text-muted-foreground mt-1">
                基于大模型的智能辅助工具
              </p>
            </div>
          </div>
          <Link
            href="/ai-tools"
            className="hidden md:flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            探索更多 <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {aiTools.slice(0, 8).map((tool, index) => (
            <Link key={tool.id} href={tool.href}>
              <Card className="h-full border border-border/40 bg-white shadow-sm group hover:shadow-lg hover:-translate-y-1 transition-all duration-300">
                <CardContent className="p-4 flex items-start gap-3">
                  <div
                    className={cn(
                      "flex h-10 w-10 shrink-0 items-center justify-center rounded-lg transition-colors",
                      iconColors[index % iconColors.length]
                    )}
                  >
                    <tool.icon className="h-5 w-5" />
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-semibold text-base text-foreground group-hover:text-primary transition-colors line-clamp-1">
                      {tool.label}
                    </h3>
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {tool.description}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
