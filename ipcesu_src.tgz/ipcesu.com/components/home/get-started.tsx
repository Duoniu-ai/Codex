"use client";

import Link from "next/link";
import { Rocket } from "lucide-react";

export function GetStarted() {
  return (
    <section className="py-12 bg-slate-50 dark:bg-slate-950">
      <div className="container mx-auto px-4 text-center">
        <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-white border border-border shadow-sm mb-5">
          <Rocket className="h-6 w-6 text-foreground" />
        </div>
        <h2 className="text-3xl font-bold mb-4">
          开始使用 IPcesu 工具站
        </h2>
        <p className="text-muted-foreground mb-6 text-sm md:text-base max-w-xl mx-auto">
          注册即可获得免费积分，体验所有工具和监控服务
        </p>
        <div className="flex flex-wrap items-center justify-center gap-3">
          <Link
            href="/user/register"
            className="inline-flex items-center justify-center rounded-lg bg-slate-900 text-white px-5 py-2 text-sm font-medium transition-colors hover:bg-slate-800"
          >
            免费注册
          </Link>
          <Link
            href="/user/vip"
            className="inline-flex items-center justify-center rounded-lg bg-white text-foreground border border-border px-5 py-2 text-sm font-medium transition-colors hover:bg-slate-50"
          >
            查看VIP特权
          </Link>
        </div>
      </div>
    </section>
  );
}
