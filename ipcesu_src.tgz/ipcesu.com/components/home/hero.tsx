"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Search,
  Server,
  MapPin,
  Database,
  Shield,
  Globe,
  FileText,
  Zap,
  Lock,
  Copy,
  Loader2,
} from "lucide-react";

interface HeroProps {
  ipInfo?: {
    ip: string;
    location: string;
    isp: string;
  };
}

const quickTools = [
  { label: "Ping测试", href: "/ping", icon: Server },
  { label: "IP查询", href: "/ip", icon: MapPin },
  { label: "DNS查询", href: "/dns", icon: Database },
  { label: "SSL检测", href: "/ssl", icon: Shield },
  { label: "Whois查询", href: "/whois", icon: Globe },
  { label: "ICP备案", href: "/icp", icon: FileText },
  { label: "网站测速", href: "/speed", icon: Zap },
  { label: "被墙检测", href: "/blocked", icon: Lock },
];

const toolOptions = [
  { value: "ping", label: "Ping测试" },
  { value: "ip", label: "IP查询" },
  { value: "dns", label: "DNS查询" },
  { value: "ssl", label: "SSL检测" },
  { value: "whois", label: "Whois查询" },
];

const toolLabelMap = Object.fromEntries(toolOptions.map((o) => [o.value, o.label]));

export function Hero({ ipInfo: initialIpInfo }: HeroProps) {
  const router = useRouter();
  const [tool, setTool] = useState("ping");
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(!initialIpInfo);
  const [ipInfo, setIpInfo] = useState(initialIpInfo);

  useEffect(() => {
    if (initialIpInfo) return;
    fetch("/api/ip-info")
      .then((res) => res.json())
      .then((data) => {
        setIpInfo({
          ip: data.ip || "--",
          location:
            `${data.country || ""} ${data.region || ""} ${data.city || ""}`.trim() || "--",
          isp: data.isp || "--",
        });
      })
      .catch(() => {
        setIpInfo({ ip: "--", location: "--", isp: "--" });
      })
      .finally(() => {
        setLoading(false);
      });
  }, [initialIpInfo]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    router.push(`/${tool}?q=${encodeURIComponent(query.trim())}`);
  };

  const handleCopyIp = () => {
    if (ipInfo?.ip && ipInfo.ip !== "--") {
      navigator.clipboard.writeText(ipInfo.ip);
    }
  };

  return (
    <>
      <section className="bg-slate-900 text-white text-sm">
        <div className={`container flex min-h-16 items-center py-2 ${loading ? "justify-center" : "justify-between"}`}>
          {loading ? (
            <div className="flex items-center gap-2 text-slate-400">
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
              <span>获取IP信息中...</span>
            </div>
          ) : ipInfo ? (
            <>
              <div className="flex items-center gap-4 sm:gap-6 min-w-0 flex-1">
                <div className="flex items-center gap-2 min-w-0">
                  <span className="text-slate-400 shrink-0">IP:</span>
                  <span
                    className="font-mono font-medium truncate"
                    title={ipInfo.ip || ""}
                  >
                    {ipInfo.ip || "--"}
                  </span>
                  <button
                    onClick={handleCopyIp}
                    className="hover:text-primary transition-colors shrink-0"
                    aria-label="复制 IP"
                  >
                    <Copy className="h-3.5 w-3.5" />
                  </button>
                </div>
                <div className="hidden sm:flex items-center gap-2 shrink-0">
                  <span className="text-slate-400">位置:</span>
                  <span>{ipInfo.location || "--"}</span>
                </div>
                <div className="hidden md:flex items-center gap-2 shrink-0">
                  <span className="text-slate-400">运营商:</span>
                  <span>{ipInfo.isp || "--"}</span>
                </div>
              </div>
              <Link
                href="/ip"
                className="text-slate-300 hover:text-white hover:underline text-xs shrink-0 ml-4"
              >
                详细信息 →
              </Link>
            </>
          ) : null}
        </div>
      </section>

      <section className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 py-16 md:py-24 relative overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-20 left-10 w-72 h-72 bg-blue-500 rounded-full filter blur-[100px]" />
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-purple-500 rounded-full filter blur-[120px]" />
        </div>

        <div className="container relative z-10">
          <div className="text-center mb-10">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              IPcesu 工具站
            </h1>
            <p className="text-lg text-slate-300 max-w-2xl mx-auto">
              专业的网站质量监测与网络性能检测平台，提供Ping测试、DNS查询、SSL检测等数十种在线工具
            </p>
          </div>

          <div className="max-w-3xl mx-auto">
            <form
              onSubmit={handleSearch}
              className="flex items-stretch bg-white rounded-full shadow-2xl overflow-hidden h-12"
            >
              <div className="shrink-0 pl-4 pr-2 border-r border-slate-200 flex items-center">
                <Select value={tool} onValueChange={(value) => value && setTool(value)}>
                  <SelectTrigger className="w-auto border-0 bg-transparent text-foreground focus:ring-0 h-10 text-sm px-0 hover:text-primary transition-colors">
                    <span>{toolLabelMap[tool]}</span>
                  </SelectTrigger>
                  <SelectContent>
                    {toolOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="请输入域名或IP，如: www.baidu.com 或 8.8.8.8"
                className="flex-1 border-0 bg-transparent text-sm focus-visible:ring-0 h-12 px-4"
              />
              <Button
                type="submit"
                className="bg-slate-900 hover:bg-slate-800 h-12 px-7 rounded-none text-sm shrink-0"
              >
                <Search className="h-4 w-4 mr-2" />
                立即检测
              </Button>
            </form>
          </div>

          <div className="mt-10">
            <div className="flex flex-wrap justify-center gap-3">
              {quickTools.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-white text-sm transition-all hover:scale-105"
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
