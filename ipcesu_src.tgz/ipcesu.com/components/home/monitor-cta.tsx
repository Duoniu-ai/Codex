"use client";

import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { Check } from "lucide-react";

const features = [
  "全球100+监测节点",
  "多种监控类型（HTTP、Ping、TCP、SSL）",
  "微信、邮件、钉钉多渠道告警",
  "详细的历史数据和趋势分析",
];

export function MonitorCta() {
  return (
    <section className="py-12 bg-slate-900 text-white">
      <div className="container mx-auto px-4">
        <div className="grid gap-8 md:grid-cols-2 items-center">
          <div>
            <Badge className="bg-primary/20 text-primary border-transparent mb-4">监控服务</Badge>
            <h2 className="text-3xl font-bold mb-4">
              7x24小时网站监控
            </h2>
            <p className="text-slate-300 mb-6 leading-relaxed">
              实时监控网站可用性、响应时间、SSL证书等关键指标，第一时间发现故障并告警通知。
            </p>
            <ul className="space-y-3 mb-6">
              {features.map((feature) => (
                <li key={feature} className="flex items-center gap-3 text-sm text-slate-300">
                  <Check className="h-4 w-4 text-emerald-400 shrink-0" />
                  {feature}
                </li>
              ))}
            </ul>
            <div className="flex flex-wrap items-center gap-3">
              <Link
                href="/monitor"
                className="inline-flex items-center justify-center rounded-lg bg-white text-slate-900 px-5 py-2.5 text-sm font-medium transition-colors hover:bg-white/90"
              >
                进入控制台
              </Link>
              <Link
                href="/user/register"
                className="inline-flex items-center justify-center rounded-lg border border-white/20 text-white px-5 py-2.5 text-sm font-medium transition-colors hover:bg-white/10"
              >
                了解详情
              </Link>
            </div>
          </div>

          <div className="rounded-xl border border-white/10 bg-slate-800 p-5">
            <div className="flex items-center justify-between mb-4 text-xs text-white/60">
              <span>实时监控概览</span>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400">运行中</span>
            </div>
            <div className="grid grid-cols-3 gap-3 mb-6">
              <div className="rounded-lg bg-slate-900/50 p-3 text-center">
                <div className="text-xl font-bold text-emerald-400">99.9%</div>
                <div className="text-xs text-white/50">可用率</div>
              </div>
              <div className="rounded-lg bg-slate-900/50 p-3 text-center">
                <div className="text-xl font-bold text-white">45ms</div>
                <div className="text-xs text-white/50">平均响应</div>
              </div>
              <div className="rounded-lg bg-slate-900/50 p-3 text-center">
                <div className="text-xl font-bold text-purple-400">12</div>
                <div className="text-xs text-white/50">监控任务</div>
              </div>
            </div>
            <div className="flex items-end gap-1 h-24">
              {[40, 55, 35, 70, 45, 80, 60, 75, 50, 85, 65, 55].map((h, i) => (
                <div
                  key={i}
                  className="flex-1 rounded-t bg-gradient-to-t from-white/60 to-white"
                  style={{ height: `${h}%` }}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
