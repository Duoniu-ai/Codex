"use client";

import { stats } from "@/lib/tools";
import { Globe, BarChart3, Users, Zap } from "lucide-react";

const icons = [Globe, BarChart3, Users, Zap];

export function Stats() {
  return (
    <section className="bg-white dark:bg-slate-900 border-b py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {stats.map((stat, index) => {
            const Icon = icons[index];
            return (
              <div key={stat.label} className="text-center">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Icon className="h-5 w-5 text-slate-600" />
                  <div className="text-3xl font-bold text-slate-900 dark:text-white">
                    {stat.value}
                  </div>
                </div>
                <div className="font-medium text-slate-900 dark:text-white">
                  {stat.label}
                </div>
                <div className="text-xs text-muted-foreground">
                  {stat.description}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
