"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { User, Zap, Crown, Settings, Receipt } from "lucide-react";

const navItems = [
  { href: "/user/profile", label: "个人中心", icon: User },
  { href: "/user/credits", label: "积分管理", icon: Zap },
  { href: "/user/vip", label: "VIP会员", icon: Crown },
  { href: "/user/orders", label: "订单记录", icon: Receipt },
  { href: "/user/settings", label: "设置", icon: Settings },
];

interface UserSidebarProps {
  className?: string;
}

export function UserSidebar({ className }: UserSidebarProps) {
  const pathname = usePathname();

  return (
    <nav
      className={cn(
        "flex flex-col gap-1 rounded-xl border border-border/40 bg-card p-2",
        className
      )}
    >
      {navItems.map((item) => {
        const active = pathname === item.href;
        return (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
              active
                ? "bg-foreground text-background"
                : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
            )}
          >
            <item.icon className="h-4 w-4" />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}
