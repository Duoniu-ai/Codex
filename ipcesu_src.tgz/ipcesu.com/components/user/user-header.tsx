"use client";

import { useEffect, useState } from "react";
import { Crown, Mail, Calendar } from "lucide-react";
import { planBenefits } from "@/lib/plans";
import type { UserPlan } from "@/lib/user";

interface UserInfo {
  id: string;
  email: string;
  credits: number;
  plan: UserPlan;
  vipExpiresAt: string | null;
  createdAt: string;
}

interface UserHeaderProps {
  user: UserInfo;
}

function getPlanBadge(plan: UserPlan) {
  switch (plan) {
    case "enterprise":
      return "bg-amber-500/10 text-amber-600 border-amber-500/20";
    case "pro":
      return "bg-primary/10 text-primary border-primary/20";
    default:
      return "bg-muted text-muted-foreground border-border";
  }
}

function getPlanName(plan: UserPlan) {
  switch (plan) {
    case "enterprise":
      return "企业版";
    case "pro":
      return "专业版";
    default:
      return "免费版";
  }
}

export function UserHeader({ user }: UserHeaderProps) {
  const [nickname, setNickname] = useState("");

  useEffect(() => {
    const stored = localStorage.getItem(`ipcesu:nickname:${user.email}`);
    setNickname(stored || user.email.split("@")[0]);
  }, [user.email]);

  const benefits = planBenefits(user.plan);

  return (
    <div className="flex flex-col sm:flex-row sm:items-center gap-4 rounded-xl border border-border/40 bg-card p-5">
      <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-primary to-primary/70 text-primary-foreground text-xl font-bold">
        {nickname[0]?.toUpperCase() || user.email[0].toUpperCase()}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <h2 className="text-lg font-bold text-foreground truncate">
            {nickname}
          </h2>
          <span
            className={`inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium ${getPlanBadge(
              user.plan
            )}`}
          >
            <Crown className="h-3 w-3 mr-1" />
            {getPlanName(user.plan)}
          </span>
        </div>
        <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <Mail className="h-3.5 w-3.5" />
            {user.email}
          </span>
          <span className="flex items-center gap-1.5">
            <Calendar className="h-3.5 w-3.5" />
            注册于 {new Date(user.createdAt).toLocaleDateString("zh-CN")}
          </span>
        </div>
      </div>
      <div className="flex shrink-0 flex-wrap items-center gap-3 text-sm">
        <div className="rounded-lg bg-secondary/50 px-3 py-2">
          <div className="text-xs text-muted-foreground">调用额度</div>
          <div className="font-semibold text-foreground">
            {benefits.monthlyCredits}
            <span className="text-xs font-normal text-muted-foreground"> / 月</span>
          </div>
        </div>
        <div className="rounded-lg bg-secondary/50 px-3 py-2">
          <div className="text-xs text-muted-foreground">QPS</div>
          <div className="font-semibold text-foreground">{benefits.qps}</div>
        </div>
      </div>
    </div>
  );
}
