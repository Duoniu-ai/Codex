"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Activity,
  AlertCircle,
  ArrowRight,
  Clock,
  Globe,
  Pause,
  Play,
  Plus,
  Shield,
  Trash2,
  Zap,
} from "lucide-react";

interface MonitorTask {
  id: string;
  name: string;
  target: string;
  type: "HTTP" | "Ping" | "TCP" | "SSL";
  interval: number;
  status: "running" | "paused" | "error";
  lastCheck: string;
  uptime: number;
  responseTime: number;
}

const initialTasks: MonitorTask[] = [
  {
    id: "1",
    name: "官网首页",
    target: "https://ipcesu.com",
    type: "HTTP",
    interval: 5,
    status: "running",
    lastCheck: "2 分钟前",
    uptime: 99.98,
    responseTime: 42,
  },
  {
    id: "2",
    name: "API 接口",
    target: "https://ipcesu.com/api/ip-info",
    type: "HTTP",
    interval: 1,
    status: "running",
    lastCheck: "30 秒前",
    uptime: 99.95,
    responseTime: 28,
  },
  {
    id: "3",
    name: "DNS 服务器",
    target: "8.8.8.8",
    type: "Ping",
    interval: 15,
    status: "paused",
    lastCheck: "1 小时前",
    uptime: 99.9,
    responseTime: 12,
  },
  {
    id: "4",
    name: "HTTPS 证书",
    target: "ipcesu.com",
    type: "SSL",
    interval: 60,
    status: "running",
    lastCheck: "10 分钟前",
    uptime: 100,
    responseTime: 56,
  },
];

const typeIcons: Record<string, React.ReactNode> = {
  HTTP: <Globe className="h-3.5 w-3.5" />,
  Ping: <Activity className="h-3.5 w-3.5" />,
  TCP: <Zap className="h-3.5 w-3.5" />,
  SSL: <Shield className="h-3.5 w-3.5" />,
};

export function MonitorDashboard() {
  const [tasks, setTasks] = useState<MonitorTask[]>(initialTasks);
  const [target, setTarget] = useState("");
  const [type, setType] = useState<MonitorTask["type"]>("HTTP");
  const [interval, setInterval] = useState("5");

  const stats = useMemo(() => {
    const running = tasks.filter((t) => t.status === "running").length;
    const paused = tasks.filter((t) => t.status === "paused").length;
    const error = tasks.filter((t) => t.status === "error").length;
    const avgResponse = tasks.length
      ? Math.round(
          tasks.reduce((sum, t) => sum + t.responseTime, 0) / tasks.length
        )
      : 0;
    const avgUptime = tasks.length
      ? (tasks.reduce((sum, t) => sum + t.uptime, 0) / tasks.length).toFixed(2)
      : "0.00";
    return { running, paused, error, avgResponse, avgUptime };
  }, [tasks]);

  const handleAdd = () => {
    if (!target.trim()) return;
    const newTask: MonitorTask = {
      id: String(Date.now()),
      name: target.trim(),
      target: target.trim(),
      type,
      interval: Number(interval),
      status: "running",
      lastCheck: "刚刚",
      uptime: 99.9,
      responseTime: Math.floor(Math.random() * 80) + 20,
    };
    setTasks((prev) => [newTask, ...prev]);
    setTarget("");
  };

  const toggleStatus = (id: string) => {
    setTasks((prev) =>
      prev.map((t) =>
        t.id === id
          ? { ...t, status: t.status === "running" ? "paused" : "running" }
          : t
      )
    );
  };

  const removeTask = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  return (
    <div className="container mx-auto px-4 py-12">
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card className="border-border bg-card shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
              <Activity className="h-4 w-4" />
              运行中任务
            </div>
            <div className="text-3xl font-bold text-foreground">
              {stats.running}
            </div>
          </CardContent>
        </Card>
        <Card className="border-border bg-card shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
              <Clock className="h-4 w-4" />
              平均响应
            </div>
            <div className="text-3xl font-bold text-foreground">
              {stats.avgResponse} ms
            </div>
          </CardContent>
        </Card>
        <Card className="border-border bg-card shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
              <Shield className="h-4 w-4" />
              平均可用率
            </div>
            <div className="text-3xl font-bold text-foreground">
              {stats.avgUptime}%
            </div>
          </CardContent>
        </Card>
        <Card className="border-border bg-card shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
              <AlertCircle className="h-4 w-4" />
              异常任务
            </div>
            <div className="text-3xl font-bold text-foreground">
              {stats.error}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Add task */}
        <aside className="lg:col-span-1">
          <Card className="border-border bg-card shadow-sm lg:sticky lg:top-24">
            <CardHeader>
              <CardTitle className="text-base text-foreground flex items-center gap-2">
                <Plus className="h-4 w-4" />
                添加监控任务
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0 space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">
                  监控目标
                </label>
                <Input
                  value={target}
                  onChange={(e) => setTarget(e.target.value)}
                  placeholder="例如：https://example.com"
                  className="bg-secondary/50 border-border/50"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">
                  监控类型
                </label>
                <Select value={type} onValueChange={(v) => v && setType(v as MonitorTask["type"])}>
                  <SelectTrigger className="bg-secondary/50 border-border/50">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="HTTP">HTTP 监控</SelectItem>
                    <SelectItem value="Ping">Ping 监控</SelectItem>
                    <SelectItem value="TCP">TCP 监控</SelectItem>
                    <SelectItem value="SSL">SSL 证书监控</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">
                  监控频率
                </label>
                <Select value={interval} onValueChange={(v) => v && setInterval(v)}>
                  <SelectTrigger className="bg-secondary/50 border-border/50">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 分钟</SelectItem>
                    <SelectItem value="5">5 分钟</SelectItem>
                    <SelectItem value="15">15 分钟</SelectItem>
                    <SelectItem value="30">30 分钟</SelectItem>
                    <SelectItem value="60">60 分钟</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button
                onClick={handleAdd}
                className="w-full bg-foreground hover:bg-foreground/90 text-background"
              >
                添加任务
              </Button>
              <p className="text-xs text-muted-foreground">
                当前为演示环境，任务数据仅保存在当前会话中。
              </p>
            </CardContent>
          </Card>
        </aside>

        {/* Task list */}
        <section className="lg:col-span-2">
          <Card className="border-border bg-card shadow-sm">
            <CardHeader>
              <CardTitle className="text-base text-foreground">
                监控任务列表
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              {tasks.length === 0 ? (
                <div className="text-center py-16 text-muted-foreground text-sm">
                  暂无监控任务，请在左侧添加
                </div>
              ) : (
                <div className="overflow-x-auto -mx-5 px-5">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>任务</TableHead>
                        <TableHead>类型</TableHead>
                        <TableHead>频率</TableHead>
                        <TableHead>状态</TableHead>
                        <TableHead>可用率</TableHead>
                        <TableHead>响应</TableHead>
                        <TableHead className="text-right">操作</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {tasks.map((task) => (
                        <TableRow key={task.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium text-foreground">
                                {task.name}
                              </div>
                              <div className="text-xs text-muted-foreground font-mono">
                                {task.target}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="secondary" className="gap-1">
                              {typeIcons[task.type]}
                              {task.type}
                            </Badge>
                          </TableCell>
                          <TableCell>{task.interval} 分钟</TableCell>
                          <TableCell>
                            {task.status === "running" ? (
                              <span className="inline-flex items-center gap-1.5 text-sm text-emerald-600">
                                <span className="relative flex h-2 w-2">
                                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                                </span>
                                运行中
                              </span>
                            ) : task.status === "paused" ? (
                              <span className="inline-flex items-center gap-1.5 text-sm text-amber-600">
                                <Pause className="h-3.5 w-3.5" />
                                已暂停
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1.5 text-sm text-red-600">
                                <AlertCircle className="h-3.5 w-3.5" />
                                异常
                              </span>
                            )}
                          </TableCell>
                          <TableCell>{task.uptime}%</TableCell>
                          <TableCell>{task.responseTime} ms</TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => toggleStatus(task.id)}
                                className="inline-flex items-center justify-center rounded-md p-2 text-muted-foreground hover:bg-accent hover:text-foreground transition-colors"
                                title={task.status === "running" ? "暂停" : "启动"}
                              >
                                {task.status === "running" ? (
                                  <Pause className="h-4 w-4" />
                                ) : (
                                  <Play className="h-4 w-4" />
                                )}
                              </button>
                              <button
                                onClick={() => removeTask(task.id)}
                                className="inline-flex items-center justify-center rounded-md p-2 text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors"
                                title="删除"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>

          <div className="mt-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 rounded-xl border border-border bg-card shadow-sm p-5">
            <div>
              <div className="text-sm font-medium text-foreground">
                需要更高监控频率与更多节点？
              </div>
              <div className="text-xs text-muted-foreground">
                升级 VIP 可解锁 1 分钟级监控、全球多节点与更多告警渠道。
              </div>
            </div>
            <Link
              href="/user/vip"
              className="inline-flex items-center justify-center rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background transition-colors hover:bg-foreground/90 gap-2"
            >
              查看 VIP 套餐
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}
