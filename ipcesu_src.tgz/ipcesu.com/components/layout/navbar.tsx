"use client";

import Link from "next/link";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";
import {
  Menu,
  Activity,
  Zap,
  FileText,
  Newspaper,
  User,
  LogOut,
  Crown,
  Settings,
  Receipt,
  Gauge,
  Flame,
  BookOpen,
  HelpCircle,
  Megaphone,
} from "lucide-react";
import { toolCategories, tools, aiTools } from "@/lib/tools";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const monitorItems = [
  { label: "监控概览", description: "实时监控数据", href: "/monitor", icon: Activity },
  { label: "监控控制台", description: "管理监控任务", href: "/monitor/dashboard", icon: Gauge },
];

const newsCategories = [
  { label: "热门资讯", description: "全球AI资讯", href: "/article", icon: Flame },
  { label: "技术教程", description: "技术教程", href: "/article?category=技术教程", icon: BookOpen },
  { label: "帮助中心", description: "常见问题", href: "/article?category=帮助中心", icon: HelpCircle },
  { label: "网站公告", description: "新功能发布", href: "/article?category=网站公告", icon: Megaphone },
];

interface AuthUser {
  email: string;
  credits: number;
}

export function Navbar() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [nickname, setNickname] = useState("");
  const [navValue, setNavValue] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/auth/me", { credentials: "include" })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data?.user) {
          setUser({ email: data.user.email, credits: data.user.credits });
          const stored = localStorage.getItem(`ipcesu:nickname:${data.user.email}`);
          setNickname(stored || data.user.email.split("@")[0]);
        }
      })
      .catch(() => setUser(null));
  }, []);

  const handleLogout = async () => {
    await fetch("/api/auth/logout", {
      method: "POST",
      credentials: "include",
    });
    setUser(null);
    window.location.href = "/";
  };

  const triggerClass =
    "group inline-flex h-9 w-max items-center justify-center rounded-md px-4 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground disabled:pointer-events-none disabled:opacity-50 data-[state=open]:hover:bg-accent data-[state=open]:text-accent-foreground data-[state=open]:focus:bg-accent data-[state=open]:bg-accent/50 focus-visible:ring-ring/50 outline-none transition-[color,box-shadow] focus-visible:ring-[3px] focus-visible:outline-1 bg-transparent";

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-6">
            <Link href="/" className="flex items-center gap-2 flex-shrink-0">
              <Activity className="h-6 w-6 text-primary" />
              <span className="text-lg font-bold hidden sm:inline">
                IPcesu 工具站
              </span>
            </Link>

            <nav aria-label="主导航" className="hidden md:flex">
              <NavigationMenu
                value={navValue}
                onValueChange={setNavValue}
              >
              <NavigationMenuList className="gap-1">
                <NavigationMenuItem>
                  <NavigationMenuTrigger className={triggerClass}>
                    监控服务
                  </NavigationMenuTrigger>
                  <NavigationMenuContent className="w-64">
                    <ul className="grid gap-0.5 p-2">
                      {monitorItems.map((item) => (
                        <li key={item.href}>
                          <Link
                            href={item.href}
                            className="flex items-center gap-3 rounded-lg p-2.5 text-sm text-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
                          >
                            <item.icon className="h-4 w-4 shrink-0 text-primary/70" />
                            <div className="min-w-0">
                              <div className="font-medium line-clamp-1">{item.label}</div>
                              <div className="text-xs text-muted-foreground line-clamp-1">{item.description}</div>
                            </div>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <NavigationMenuTrigger className={triggerClass}>
                    工具集
                  </NavigationMenuTrigger>
                  <NavigationMenuContent className="w-[720px]">
                    <div className="max-h-[calc(100vh-8rem)] overflow-y-auto p-4">
                      <div className="space-y-1">
                        {toolCategories.map((category) => {
                          const categoryTools = tools.filter(
                            (tool) => tool.category === category.id
                          );
                          if (categoryTools.length === 0) return null;
                          return (
                            <div
                              key={category.id}
                              className="flex items-start gap-3 rounded-lg p-2 hover:bg-accent/50 transition-colors"
                            >
                              <div className="flex w-20 shrink-0 items-center gap-1.5 py-1.5 text-xs font-medium text-muted-foreground">
                                <category.icon className="h-3.5 w-3.5 shrink-0" />
                                <span className="line-clamp-1">{category.label}</span>
                              </div>
                              <div className="grid flex-1 grid-cols-3 gap-x-2">
                                {categoryTools.slice(0, 6).map((tool) => (
                                  <Link
                                    key={tool.id}
                                    href={tool.href}
                                    className="flex items-center gap-2 rounded-md px-2 py-1.5 text-sm text-muted-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
                                    title={tool.description}
                                  >
                                    <tool.icon className="h-4 w-4 shrink-0 text-primary/70" />
                                    <span className="line-clamp-1">{tool.label}</span>
                                  </Link>
                                ))}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                      <div className="mt-3 pt-3 border-t border-border/40">
                        <Link
                          href="/tools"
                          className="flex w-full items-center justify-center rounded-lg p-2 text-sm text-muted-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
                        >
                          查看全部工具
                        </Link>
                      </div>
                    </div>
                  </NavigationMenuContent>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <NavigationMenuTrigger className={triggerClass}>
                    AI工具
                  </NavigationMenuTrigger>
                  <NavigationMenuContent className="w-64">
                    <ul className="grid gap-0.5 p-2">
                      {aiTools.map((tool) => (
                        <li key={tool.id}>
                          <Link
                            href={tool.href}
                            className="flex items-center gap-3 rounded-lg p-2.5 text-sm text-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
                          >
                            <tool.icon className="h-4 w-4 shrink-0 text-primary/70" />
                            <div className="min-w-0">
                              <div className="font-medium line-clamp-1">{tool.label}</div>
                              <div className="text-xs text-muted-foreground line-clamp-1">{tool.description}</div>
                            </div>
                          </Link>
                        </li>
                      ))}
                    </ul>
                    <div className="p-2 pt-1">
                      <Link
                        href="/ai-tools"
                        className="flex w-full items-center justify-center rounded-lg p-2 text-sm text-muted-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
                      >
                        查看全部 AI 工具
                      </Link>
                    </div>
                  </NavigationMenuContent>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <Link href="/api-docs" className={triggerClass}>
                    <FileText className="h-4 w-4 mr-1.5" />
                    API文档
                  </Link>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <NavigationMenuTrigger className={triggerClass}>
                    <Newspaper className="h-4 w-4 mr-1.5" />
                    资讯
                  </NavigationMenuTrigger>
                  <NavigationMenuContent className="w-64">
                    <ul className="grid gap-0.5 p-2">
                      {newsCategories.map((item) => (
                        <li key={item.href}>
                          <Link
                            href={item.href}
                            className="flex items-center gap-3 rounded-lg p-2.5 text-sm text-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
                          >
                            <item.icon className="h-4 w-4 shrink-0 text-primary/70" />
                            <div className="min-w-0">
                              <div className="font-medium line-clamp-1">{item.label}</div>
                              <div className="text-xs text-muted-foreground line-clamp-1">{item.description}</div>
                            </div>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>
              </NavigationMenuList>
            </NavigationMenu>
            </nav>
          </div>

          <div className="flex items-center gap-2">
            <Link
              href="/user/credits"
              className="hidden sm:inline-flex h-9 items-center justify-center gap-1.5 rounded-md border border-border bg-background px-3 text-xs font-medium text-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
            >
              <Zap className="h-3.5 w-3.5" />
              {user ? `${user.credits}积分` : "0积分"}
            </Link>

            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger
                  className="relative flex size-9 shrink-0 overflow-hidden rounded-full bg-muted items-center justify-center hover:bg-muted/80 transition-colors outline-none focus-visible:ring-2 focus-visible:ring-ring/50"
                  title="个人中心"
                >
                  <span className="text-sm font-medium">
                    {nickname[0]?.toUpperCase() || user.email[0].toUpperCase()}
                  </span>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuGroup>
                    <DropdownMenuLabel className="font-normal p-2">
                      <div className="flex flex-col gap-0.5">
                        <span className="text-sm font-medium text-foreground truncate">
                          {nickname}
                        </span>
                        <span className="text-xs text-muted-foreground truncate">
                          {user.email}
                        </span>
                      </div>
                    </DropdownMenuLabel>
                  </DropdownMenuGroup>
                  <DropdownMenuSeparator />
                  <DropdownMenuGroup>
                    <DropdownMenuItem
                      onClick={() => router.push("/user/profile")}
                      className="cursor-pointer"
                    >
                      <User className="h-4 w-4 mr-2" />
                      个人中心
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => router.push("/user/credits")}
                      className="cursor-pointer"
                    >
                      <Zap className="h-4 w-4 mr-2" />
                      积分管理
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => router.push("/user/vip")}
                      className="cursor-pointer"
                    >
                      <Crown className="h-4 w-4 mr-2" />
                      VIP会员
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => router.push("/user/settings")}
                      className="cursor-pointer"
                    >
                      <Settings className="h-4 w-4 mr-2" />
                      设置
                    </DropdownMenuItem>
                  </DropdownMenuGroup>
                  <DropdownMenuSeparator />
                  <DropdownMenuGroup>
                    <DropdownMenuItem
                      onClick={handleLogout}
                      className="cursor-pointer"
                    >
                      <LogOut className="h-4 w-4 mr-2" />
                      退出登录
                    </DropdownMenuItem>
                  </DropdownMenuGroup>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link
                href="/user/login"
                className="relative flex size-9 shrink-0 overflow-hidden rounded-full bg-muted items-center justify-center hover:bg-muted/80 transition-colors"
                title="登录"
              >
                <span className="text-sm font-medium">U</span>
              </Link>
            )}

            <Sheet open={open} onOpenChange={setOpen}>
              <SheetTrigger className="md:hidden inline-flex items-center justify-center rounded-lg border border-border bg-background p-2 text-foreground transition-colors hover:bg-muted">
                <Menu className="h-5 w-5" />
              </SheetTrigger>
              <SheetContent side="right" className="w-72 p-0">
                <nav aria-label="移动端导航" className="flex flex-col gap-1 px-6 py-8">
                  <Link href="/" onClick={() => setOpen(false)} className="flex w-full items-center rounded-lg px-3 py-2.5 text-lg font-medium text-foreground hover:bg-accent hover:text-accent-foreground transition-colors">
                    首页
                  </Link>
                  <Link href="/monitor" onClick={() => setOpen(false)} className="flex w-full items-center rounded-lg px-3 py-2.5 text-lg font-medium text-foreground hover:bg-accent hover:text-accent-foreground transition-colors">
                    监控服务
                  </Link>
                  <Link href="/tools" onClick={() => setOpen(false)} className="flex w-full items-center rounded-lg px-3 py-2.5 text-lg font-medium text-foreground hover:bg-accent hover:text-accent-foreground transition-colors">
                    工具集
                  </Link>
                  <Link href="/ai-tools" onClick={() => setOpen(false)} className="flex w-full items-center rounded-lg px-3 py-2.5 text-lg font-medium text-foreground hover:bg-accent hover:text-accent-foreground transition-colors">
                    AI 工具
                  </Link>
                  <Link href="/api-docs" onClick={() => setOpen(false)} className="flex w-full items-center rounded-lg px-3 py-2.5 text-lg font-medium text-foreground hover:bg-accent hover:text-accent-foreground transition-colors">
                    API 文档
                  </Link>
                  <Link href="/article" onClick={() => setOpen(false)} className="flex w-full items-center rounded-lg px-3 py-2.5 text-lg font-medium text-foreground hover:bg-accent hover:text-accent-foreground transition-colors">
                    资讯
                  </Link>
                  <hr className="border-border" />
                  {user ? (
                    <>
                      <Link
                        href="/user/profile"
                        onClick={() => setOpen(false)}
                        className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
                      >
                        <User className="h-4 w-4" />
                        个人中心
                      </Link>
                      <Link
                        href="/user/credits"
                        onClick={() => setOpen(false)}
                        className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
                      >
                        <Zap className="h-4 w-4" />
                        积分管理
                      </Link>
                      <Link
                        href="/user/vip"
                        onClick={() => setOpen(false)}
                        className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
                      >
                        <Crown className="h-4 w-4" />
                        VIP会员
                      </Link>
                      <Link
                        href="/user/settings"
                        onClick={() => setOpen(false)}
                        className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
                      >
                        <Settings className="h-4 w-4" />
                        设置
                      </Link>
                      <Link
                        href="/user/orders"
                        onClick={() => setOpen(false)}
                        className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
                      >
                        <Receipt className="h-4 w-4" />
                        订单记录
                      </Link>
                      <button
                        onClick={() => {
                          setOpen(false);
                          handleLogout();
                        }}
                        className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
                      >
                        <LogOut className="h-4 w-4" />
                        退出登录
                      </button>
                    </>
                  ) : (
                    <>
                      <Link
                        href="/user/login"
                        onClick={() => setOpen(false)}
                        className="flex w-full items-center justify-center rounded-lg border border-border bg-background px-3 py-2 text-sm font-medium text-foreground transition-colors hover:bg-muted gap-2"
                      >
                        <User className="h-4 w-4" />
                        登录
                      </Link>
                      <Link
                        href="/user/register"
                        onClick={() => setOpen(false)}
                        className="flex w-full items-center justify-center rounded-lg bg-foreground px-3 py-2 text-sm font-medium text-background transition-colors hover:bg-foreground/90"
                      >
                        免费注册
                      </Link>
                    </>
                  )}
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>
    </>
  );
}
