"use client";

import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import { Sparkles, Copy, Check, RotateCcw } from "lucide-react";
import type { LucideIcon } from "lucide-react";

export interface AiToolPageProps {
  title: string;
  description: string;
  icon: LucideIcon;
  tips: string[];
  inputLabel?: string;
  inputPlaceholder?: string;
  example?: string;
  generateResponse: (input: string) => Promise<string> | string;
}

export function AiToolPage({
  title,
  description,
  icon,
  tips,
  inputLabel = "输入内容",
  inputPlaceholder = "请描述您的需求...",
  example,
  generateResponse,
}: AiToolPageProps) {
  const [input, setInput] = useState(example ?? "");
  const [output, setOutput] = useState("");
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const abortRef = useRef<boolean>(false);

  const handleGenerate = async () => {
    if (!input.trim()) return;
    abortRef.current = false;
    setLoading(true);
    setOutput("");
    try {
      const text = await generateResponse(input.trim());
      if (abortRef.current) return;
      // 模拟流式输出
      let index = 0;
      const interval = setInterval(() => {
        if (abortRef.current) {
          clearInterval(interval);
          return;
        }
        index += 3;
        setOutput(text.slice(0, index));
        if (index >= text.length) {
          clearInterval(interval);
        }
      }, 16);
    } catch {
      setOutput("生成失败，请稍后重试。");
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    abortRef.current = true;
    setInput("");
    setOutput("");
  };

  const handleCopy = async () => {
    if (!output) return;
    await navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <ToolPageLayout title={title} description={description} icon={icon} tips={tips}>
      <Card className="border-border bg-card shadow-sm">
        <CardContent className="p-5 space-y-5">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">{inputLabel}</label>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={inputPlaceholder}
              rows={5}
              className="w-full rounded-lg border border-input bg-transparent px-3 py-2 text-sm placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 outline-none resize-y"
            />
          </div>

          <div className="flex flex-wrap gap-2">
            <Button
              onClick={handleGenerate}
              disabled={loading || !input.trim()}
              className="bg-foreground hover:bg-foreground/90 text-background"
            >
              <Sparkles className="h-4 w-4 mr-1.5" />
              {loading ? "生成中..." : "立即生成"}
            </Button>
            <Button variant="outline" onClick={handleReset} disabled={loading}>
              <RotateCcw className="h-4 w-4 mr-1.5" />
              清空
            </Button>
          </div>

          {loading && !output && (
            <div className="space-y-3">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-5/6" />
              <Skeleton className="h-4 w-4/6" />
            </div>
          )}

          {(output || loading) && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-foreground">生成结果</label>
                {output && (
                  <Button variant="ghost" size="sm" onClick={handleCopy}>
                    {copied ? (
                      <Check className="h-4 w-4 mr-1.5" />
                    ) : (
                      <Copy className="h-4 w-4 mr-1.5" />
                    )}
                    {copied ? "已复制" : "复制"}
                  </Button>
                )}
              </div>
              <div className="min-h-[160px] max-h-[480px] overflow-auto rounded-lg border border-border bg-muted/30 p-4 text-sm whitespace-pre-wrap leading-relaxed text-foreground">
                {output || <span className="text-muted-foreground">AI 生成结果将显示在这里</span>}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </ToolPageLayout>
  );
}
