"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import { AlertTriangle } from "lucide-react";
import type { LucideIcon } from "lucide-react";

export interface SimulatedInput {
  id: string;
  label: string;
  type?: "text" | "textarea" | "number" | "select";
  placeholder?: string;
  options?: { value: string; label: string }[];
  defaultValue?: string;
  rows?: number;
}

export interface SimulatedToolPageProps {
  title: string;
  description: string;
  icon: LucideIcon;
  tips: string[];
  inputs: SimulatedInput[];
  onRun: (values: Record<string, string>) => Promise<unknown> | unknown;
  renderResult: (result: unknown) => React.ReactNode;
  buttonText?: string;
  loadingText?: string;
}

export function SimulatedToolPage({
  title,
  description,
  icon,
  tips,
  inputs,
  onRun,
  renderResult,
  buttonText = "开始检测",
  loadingText = "检测中...",
}: SimulatedToolPageProps) {
  const [values, setValues] = useState<Record<string, string>>(() =>
    Object.fromEntries(
      inputs.map((input) => [input.id, input.defaultValue ?? ""])
    )
  );
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<unknown>(null);
  const [error, setError] = useState("");

  const updateValue = (id: string, value: string) => {
    setValues((prev) => ({ ...prev, [id]: value }));
  };

  const handleRun = async () => {
    for (const input of inputs) {
      if (!values[input.id]?.trim()) {
        setError(`请填写 ${input.label}`);
        return;
      }
    }
    setLoading(true);
    setError("");
    setResult(null);
    try {
      const data = await onRun(values);
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "执行失败，请稍后重试");
    } finally {
      setLoading(false);
    }
  };

  const renderInput = (input: SimulatedInput) => {
    const className =
      "w-full rounded-lg border border-input bg-transparent px-3 py-2 text-sm placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 outline-none resize-y";

    if (input.type === "textarea") {
      return (
        <textarea
          value={values[input.id]}
          onChange={(e) => updateValue(input.id, e.target.value)}
          placeholder={input.placeholder}
          rows={input.rows ?? 4}
          className={className}
        />
      );
    }

    if (input.type === "select" && input.options) {
      return (
        <Select
          value={values[input.id]}
          onValueChange={(value) => value && updateValue(input.id, value)}
        >
          <SelectTrigger className="bg-secondary/50 border-border/50">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {input.options.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      );
    }

    return (
      <Input
        type={input.type === "number" ? "number" : "text"}
        value={values[input.id]}
        onChange={(e) => updateValue(input.id, e.target.value)}
        placeholder={input.placeholder}
        className="bg-secondary/50 border-border/50"
      />
    );
  };

  return (
    <ToolPageLayout
      title={title}
      description={description}
      icon={icon}
      tips={tips}
    >
      <Card className="border-border/40 bg-card shadow-sm">
        <CardContent className="p-5 space-y-5">
          <div className="grid grid-cols-1 gap-4">
            {inputs.map((input) => (
              <div key={input.id} className="space-y-2">
                <label className="text-sm font-medium text-foreground">
                  {input.label}
                </label>
                {renderInput(input)}
              </div>
            ))}
          </div>

          <Button
            onClick={handleRun}
            disabled={loading}
            className="bg-foreground hover:bg-foreground/90 text-background"
          >
            {loading ? loadingText : buttonText}
          </Button>
        </CardContent>
      </Card>

      {error && (
        <div className="p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
          {error}
        </div>
      )}

      {loading && (
        <div className="space-y-3">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
        </div>
      )}

      {result !== null && !loading && (
        <div className="space-y-4 animate-fade-in-up">
          <div className="flex items-start gap-2 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg p-3">
            <AlertTriangle className="h-3.5 w-3.5 shrink-0 mt-0.5" />
            当前为演示环境，检测结果由本地模拟生成，仅供参考。
          </div>
          {renderResult(result)}
        </div>
      )}
    </ToolPageLayout>
  );
}