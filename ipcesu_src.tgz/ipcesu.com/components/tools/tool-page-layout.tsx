"use client";

import { ReactNode } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LucideIcon, Lightbulb } from "lucide-react";

interface ToolPageLayoutProps {
  title: string;
  description: string;
  icon: LucideIcon;
  children: ReactNode;
  tips: string[];
}

export function ToolPageLayout({
  title,
  description,
  icon: Icon,
  children,
  tips,
}: ToolPageLayoutProps) {
  return (
    <main className="container mx-auto px-4 py-10">
      <article className="max-w-6xl mx-auto">
        <header className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <Icon className="h-6 w-6" aria-hidden="true" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">{title}</h1>
          </div>
          <p className="text-muted-foreground text-sm max-w-3xl">{description}</p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <section
            className="lg:col-span-2 space-y-6"
            aria-label={`${title}操作区`}
          >
            {children}
          </section>

          <aside className="lg:col-span-1">
            <Card className="border-border/40 bg-card shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-base text-foreground flex items-center gap-2">
                  <Lightbulb className="h-4 w-4 text-primary" />
                  使用说明
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <ul className="space-y-3">
                  {tips.map((tip, index) => (
                    <li
                      key={index}
                      className="text-sm text-muted-foreground flex items-start gap-2"
                    >
                      <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary text-xs font-medium">
                        {index + 1}
                      </span>
                      {tip}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </aside>
        </div>
      </article>
    </main>
  );
}