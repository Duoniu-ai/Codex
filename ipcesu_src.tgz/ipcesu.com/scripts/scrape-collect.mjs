import fs from "node:fs/promises";

const CATEGORIES = [
  { url: "https://www.ipcesu.com/article/tech/", category: "技术教程" },
  { url: "https://www.ipcesu.com/article/help/", category: "帮助中心" },
  { url: "https://www.ipcesu.com/article/news/", category: "网站公告" },
];

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function fetchHtml(url) {
  const res = await fetch(url, {
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    },
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${url}`);
  return res.text();
}

function stripHtml(str) {
  return str.replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim();
}

async function collectList(categoryInfo) {
  const html = await fetchHtml(categoryInfo.url);
  const items = [];
  const re = /<a href="(\/article\/(\d+)\.html)" class="article-list-item">(.*?)<\/a>/gs;
  let m;
  while ((m = re.exec(html)) !== null) {
    const link = m[1];
    const id = parseInt(m[2], 10);
    const inner = m[3];
    const titleMatch = inner.match(/<h2 class="article-list-title">(.*?)<\/h2>/s);
    const summaryMatch = inner.match(/<p class="article-list-summary">(.*?)<\/p>/s);
    const dateMatch = inner.match(/<span class="article-list-date">(.*?)<\/span>/s);
    const catMatch = inner.match(/<span class="article-list-category">(.*?)<\/span>/s);
    const title = titleMatch ? stripHtml(titleMatch[1]) : "";
    const summary = summaryMatch ? stripHtml(summaryMatch[1]) : "";
    const date = dateMatch ? stripHtml(dateMatch[1]) : "";
    const category = catMatch ? stripHtml(catMatch[1]) : categoryInfo.category;
    items.push({ id, title, summary, category, date, link });
  }
  return items;
}

async function main() {
  const all = [];
  for (const cat of CATEGORIES) {
    try {
      const items = await collectList(cat);
      all.push(...items);
      console.log(`// ${cat.category}: ${items.length} 篇`);
      for (const item of items) {
        console.log(`// ${item.id}: ${item.title} | ${item.date}`);
      }
    } catch (e) {
      console.error(`// 抓取失败 ${cat.url}: ${e.message}`);
    }
    await sleep(300);
  }
  await fs.writeFile(
    new URL("./collected.json", import.meta.url),
    JSON.stringify(all, null, 2),
    "utf-8"
  );
  console.log(JSON.stringify(all, null, 2));
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
