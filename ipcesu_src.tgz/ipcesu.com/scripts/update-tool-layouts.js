const fs = require("fs");
const path = require("path");

const rootDir = path.resolve(__dirname, "..");
const appDir = path.join(rootDir, "app");

const tools = [
  { id: "ping", label: "Ping 测试", description: "多节点网络延迟检测", category: "network" },
  { id: "ip", label: "IP 查询", description: "IP 归属地查询", category: "network" },
  { id: "dns", label: "DNS 查询", description: "域名解析记录查询", category: "network" },
  { id: "traceroute", label: "路由追踪", description: "追踪网络路由路径", category: "network" },
  { id: "tcping", label: "TCPing", description: "TCP 端口连通性检测", category: "network" },
  { id: "ping-ipv6", label: "Ping IPv6", description: "IPv6 网络延迟检测", category: "network" },
  { id: "tcping-ipv6", label: "TCPing IPv6", description: "IPv6 TCP 端口连通性检测", category: "network" },
  { id: "traceroute-ipv6", label: "Traceroute IPv6", description: "IPv6 路由追踪", category: "network" },
  { id: "bgp", label: "BGP 路由查询", description: "ASN 和路由信息查询", category: "network" },
  { id: "http", label: "HTTP 检测", description: "网站状态码与响应头检测", category: "speed" },
  { id: "speed", label: "网站测速", description: "网页性能分析", category: "speed" },
  { id: "http-ipv6", label: "HTTP IPv6", description: "IPv6 网站测速", category: "speed" },
  { id: "batch-ping", label: "批量 Ping", description: "多目标批量 Ping 检测", category: "batch" },
  { id: "batch-tcping", label: "批量 TCPing", description: "多目标批量 TCPing 检测", category: "batch" },
  { id: "batch-http", label: "批量 HTTP(S)", description: "多目标批量 HTTP(S) 可用性检测", category: "batch" },
  { id: "ssl", label: "SSL 检测", description: "HTTPS 安全检测", category: "analysis" },
  { id: "website-analysis", label: "网站分析", description: "SEO、性能、安全综合评估", category: "analysis" },
  { id: "seo-diagnosis", label: "SEO 诊断", description: "网站 SEO 问题诊断", category: "analysis" },
  { id: "tdk-check", label: "TDK 检测", description: "标题、描述、关键词检测", category: "analysis" },
  { id: "http-status", label: "HTTP 状态检测", description: "批量 URL 状态码检测", category: "analysis" },
  { id: "keyword-density", label: "关键词密度", description: "页面关键词分布分析", category: "analysis" },
  { id: "backlink-check", label: "友情链接查询", description: "检测友链有效性与 SEO 价值", category: "analysis" },
  { id: "spider", label: "蜘蛛抓取", description: "模拟搜索引擎蜘蛛抓取", category: "analysis" },
  { id: "optimization", label: "SEO 优化", description: "全面 SEO 优化建议", category: "analysis" },
  { id: "whois", label: "Whois 查询", description: "域名注册信息", category: "domain" },
  { id: "icp", label: "ICP 备案", description: "域名备案信息查询", category: "domain" },
  { id: "cdn", label: "CDN 检测", description: "CDN 厂商识别", category: "domain" },
  { id: "portscan", label: "端口扫描", description: "主机端口检测", category: "security" },
  { id: "security", label: "网站安全检测", description: "安全配置分析", category: "security" },
  { id: "waf", label: "WAF 检测", description: "防火墙识别", category: "security" },
  { id: "cors", label: "CORS 检测", description: "跨域配置安全检测", category: "security" },
  { id: "cookie-security", label: "Cookie 安全", description: "Cookie 安全配置检测", category: "security" },
  { id: "sensitive-info", label: "敏感信息泄露", description: "敏感文件泄露检测", category: "security" },
  { id: "email-security", label: "邮件安全检测", description: "SPF/DKIM/DMARC 检测", category: "security" },
  { id: "seo", label: "SEO 检测", description: "SEO 基础配置检测", category: "seo" },
  { id: "dead-link", label: "死链检测", description: "无效链接检测", category: "seo" },
  { id: "robots-txt", label: "Robots 检测", description: "爬虫规则分析", category: "seo" },
  { id: "core-web-vitals", label: "Core Web Vitals", description: "核心网页指标检测", category: "seo" },
  { id: "open-graph", label: "Open Graph", description: "社交分享标签检测", category: "seo" },
  { id: "json", label: "JSON 格式化", description: "JSON 美化压缩校验", category: "dev" },
  { id: "base64", label: "Base64 编解码", description: "Base64 编码解码", category: "dev" },
  { id: "url-encode", label: "URL 编解码", description: "URL 编码解码工具", category: "dev" },
  { id: "hash", label: "Hash 生成器", description: "MD5/SHA 哈希生成", category: "dev" },
  { id: "regex", label: "正则测试", description: "在线正则表达式测试", category: "dev" },
  { id: "timestamp", label: "时间戳转换", description: "时间戳日期互转", category: "dev" },
  { id: "uuid", label: "UUID 生成器", description: "批量生成 UUID", category: "dev" },
  { id: "blocked", label: "被墙检测", description: "检测网站或 IP 是否被墙", category: "network" },
];

const categoryKeywords = {
  network:
    "Ping 测试, IP 查询, DNS 查询, Traceroute, TCPing, 路由追踪, IPv6 测试, BGP 路由, 网络连通性, 网络延迟",
  speed:
    "网站测速, HTTP 检测, IPv6 测速, 网页性能, 响应时间, 网站速度测试, 页面加载速度",
  batch:
    "批量 Ping, 批量 TCPing, 批量 HTTP, 批量检测, 多目标检测, 并发检测",
  analysis:
    "SSL 检测, 网站分析, SEO 诊断, TDK 检测, HTTP 状态, 关键词密度, 友情链接, 蜘蛛抓取, SEO 优化",
  domain:
    "Whois 查询, ICP 备案, CDN 检测, 域名注册信息, 域名解析, 备案查询",
  security:
    "端口扫描, 网站安全检测, WAF 检测, CORS 检测, Cookie 安全, 敏感信息泄露, 邮件安全检测",
  seo: "SEO 检测, 死链检测, Robots 检测, Core Web Vitals, Open Graph, 搜索引擎优化, 网站排名",
  dev: "JSON 格式化, Base64 编解码, URL 编解码, Hash 生成, 正则测试, 时间戳转换, UUID 生成",
};

function createLayoutContent(tool) {
  return `import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "${tool.label}",
  "${tool.description}",
  "${tool.category}",
  "/${tool.id}",
);

export default function ${toPascalCase(tool.id)}Layout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
`;
}

function toPascalCase(str) {
  return str
    .split(/[-_/]/)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join("");
}

let updated = 0;
let skipped = 0;

for (const tool of tools) {
  const dir = path.join(appDir, tool.id);
  const layoutPath = path.join(dir, "layout.tsx");

  if (!fs.existsSync(dir)) {
    console.log(`skip (no dir): ${tool.id}`);
    skipped++;
    continue;
  }

  if (!fs.existsSync(layoutPath)) {
    fs.writeFileSync(layoutPath, createLayoutContent(tool), "utf-8");
    console.log(`created: ${layoutPath}`);
    updated++;
    continue;
  }

  fs.writeFileSync(layoutPath, createLayoutContent(tool), "utf-8");
  console.log(`updated: ${layoutPath}`);
  updated++;
}

console.log(`\nDone. Updated/Created: ${updated}, Skipped: ${skipped}`);
