import fs from "node:fs/promises";

const collectedPath = new URL("./collected.json", import.meta.url);
const outPath = new URL("../lib/news-data.tsx", import.meta.url);

const slugMap = {
  // 技术教程
  "如何使用Ping命令检测网络连通性": "ping-command-usage",
  "如何解读Ping测试结果": "reading-ping-results",
  "Traceroute路由追踪原理详解": "traceroute-principles",
  "网络延迟与丢包率的关系分析": "latency-packet-loss-analysis",
  "TCP与UDP协议在网络检测中的区别": "tcp-vs-udp",
  "DNS解析过程详解与优化方法": "dns-resolution-guide",
  "HTTP状态码详解及排查方法": "http-status-codes",
  "SSL/TLS证书工作原理与配置指南": "ssl-tls-certificate-guide",
  "IPv4与IPv6的区别及检测方法": "ipv4-vs-ipv6",
  "网络性能测试常用指标说明": "network-performance-metrics",
  // 帮助中心
  "如何正确使用在线Ping工具": "online-ping-tool-guide",
  "网站测速结果异常怎么办": "website-speed-abnormal",
  "TCPing检测失败的原因分析": "tcping-failure-analysis",
  "路由追踪结果中的星号是什么意思": "traceroute-asterisk-meaning",
  "DNS查询结果如何解读": "dns-query-results",
  "IP地址查询能获取哪些信息": "ip-lookup-info",
  "SSL证书检测结果说明": "ssl-check-results",
  "如何选择合适的检测节点": "choosing-test-nodes",
  "批量检测功能使用指南": "batch-test-guide",
  "检测历史记录如何查看和管理": "test-history-management",
  // 网站公告
  "IP测速网全新功能上线公告": "new-features-launch",
  "网站服务器升级维护通知": "server-upgrade-notice",
  "数据安全与隐私保护政策更新": "privacy-policy-update",
  "网站使用条款变更说明": "terms-update",
  "新工具上线公告：IPv6检测功能": "ipv6-tool-launch",
  "用户反馈与功能改进计划": "user-feedback-improvements",
  "网站性能优化完成公告": "performance-optimization-done",
  "合作伙伴招募计划": "partner-recruitment",
  "网站改版说明与新功能介绍": "website-redesign",
  "节假日服务调整通知": "holiday-service-adjustment",
};

const availableToolSlugs = new Set(["ping", "ip", "dns", "ssl", "whois"]);
const toolHrefMap = {
  "/ping/": "/tools/ping",
  "/ip/": "/tools/ip",
  "/dns/": "/tools/dns",
  "/ssl/": "/tools/ssl",
  "/whois/": "/tools/whois",
  "/http/": "/tools/speed",
  "/speed/": "/tools/speed",
};

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function fetchHtml(url) {
  const res = await fetch(url, {
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    },
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${url}`);
  return res.text();
}

function extractContent(html) {
  const startMarker = '<div class="article-content">';
  let start = html.indexOf(startMarker);
  if (start === -1) return "";
  start += startMarker.length;
  let depth = 1;
  let i = start;
  while (i < html.length && depth > 0) {
    const open = html.indexOf("<div", i);
    const close = html.indexOf("</div>", i);
    if (close === -1) break;
    if (open !== -1 && open < close) {
      depth++;
      i = open + 4;
    } else {
      depth--;
      i = close + 6;
    }
  }
  return html.slice(start, i - 6).trim();
}

function cleanHtml(html) {
  return (
    html
      // Remove scripts, styles, iframes
      .replace(/<script[\s\S]*?<\/script>/gi, "")
      .replace(/<style[\s\S]*?<\/style>/gi, "")
      .replace(/<iframe[\s\S]*?<\/iframe>/gi, "")
      // Remove event handlers and javascript: links
      .replace(/\s*on\w+="[^"]*"/gi, "")
      .replace(/\s*on\w+='[^']*'/gi, "")
      .replace(/href="javascript:[^"]*"/gi, 'href="#"')
      // Rewrite internal tool links
      .replace(/href="(\/[^"]+\/)"/g, (match, path) => {
        const replacement = toolHrefMap[path];
        return replacement ? `href="${replacement}"` : match;
      })
      // Trim whitespace between tags
      .replace(/>\s+</g, "><")
      .trim()
  );
}

function getRelatedToolSlugs(title, summary, content) {
  const text = `${title} ${summary} ${content}`.toLowerCase();
  const slugs = [];
  if (/ping|ping命令|在线ping/.test(text)) slugs.push("ping");
  if (/dns|域名解析/.test(text)) slugs.push("dns");
  if (/ssl|tls|证书/.test(text)) slugs.push("ssl");
  if (/ip地址|ipv4|ipv6|ip查询/.test(text)) slugs.push("ip");
  if (/whois|域名注册/.test(text)) slugs.push("whois");
  return [...new Set(slugs)].filter((s) => availableToolSlugs.has(s));
}

async function main() {
  const collected = JSON.parse(await fs.readFile(collectedPath, "utf-8"));

  const articles = [];
  for (const item of collected) {
    const url = `https://www.ipcesu.com${item.link}`;
    try {
      const html = await fetchHtml(url);
      const rawContent = extractContent(html);
      const content = cleanHtml(rawContent);
      const slug = slugMap[item.title];
      if (!slug) {
        console.warn(`No slug mapping for title: ${item.title}`);
      }
      articles.push({
        id: item.id,
        slug: slug || `article-${item.id}`,
        category: item.category,
        title: item.title,
        summary: item.summary,
        date: item.date,
        content,
        relatedToolSlugs: getRelatedToolSlugs(item.title, item.summary, content),
      });
      console.log(`Fetched ${item.id}: ${item.title} (${content.length} chars)`);
    } catch (e) {
      console.error(`Failed ${url}: ${e.message}`);
      articles.push({
        id: item.id,
        slug: slugMap[item.title] || `article-${item.id}`,
        category: item.category,
        title: item.title,
        summary: item.summary,
        date: item.date,
        content: `<p>${item.summary}</p>`,
        relatedToolSlugs: getRelatedToolSlugs(item.title, item.summary, ""),
      });
    }
    await sleep(300);
  }

  // Sort by category order then date descending
  const categoryOrder = { 技术教程: 1, 帮助中心: 2, 网站公告: 3 };
  articles.sort((a, b) => {
    if (categoryOrder[a.category] !== categoryOrder[b.category]) {
      return categoryOrder[a.category] - categoryOrder[b.category];
    }
    return b.date.localeCompare(a.date);
  });

  const fileContent = `export interface NewsItem {
  id: number;
  slug: string;
  category: string;
  title: string;
  summary: string;
  date: string;
  content: string;
  relatedToolSlugs?: string[];
}

export const newsData: NewsItem[] = ${JSON.stringify(articles, null, 2)};

export const newsItems = newsData;
`;

  await fs.writeFile(outPath, fileContent, "utf-8");
  console.log(`\nWrote ${articles.length} articles to ${outPath.pathname}`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
