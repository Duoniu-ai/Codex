const fs = require("fs");
const path = require("path");

const rootDir = path.resolve(__dirname, "..");
const appDir = path.join(rootDir, "app");

const aiTools = [
  { id: "chat", label: "AI 智能对话", description: "智能问答助手" },
  { id: "content", label: "AI 文案生成", description: "营销文案创作" },
  { id: "code", label: "AI 代码助手", description: "代码生成优化" },
  { id: "seo", label: "AI SEO 优化", description: "SEO 优化建议" },
  { id: "security", label: "AI 安全分析", description: "网站安全分析" },
  { id: "summary", label: "AI 智能摘要", description: "内容智能摘要" },
  { id: "translate", label: "AI 翻译助手", description: "多语言翻译" },
  { id: "image", label: "AI 图片分析", description: "智能图片识别" },
];

function createLayoutContent(tool) {
  return `import type { Metadata } from "next";
import { createMetadata } from "@/lib/seo";

export const metadata: Metadata = createMetadata({
  title: "${tool.label} - AI 智能辅助工具",
  description:
    "${tool.description}。IPcesu ${tool.label}基于大模型能力，为网络检测、内容创作与代码开发提供智能辅助。",
  keywords:
    "${tool.label}, AI 工具, 大模型, 智能辅助, IPcesu, ${tool.description}",
  path: "/ai-tools/${tool.id}",
});

export default function ${toPascalCase(tool.id)}AiLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
`;
}

function toPascalCase(str) {
  return str
    .split(/[-_/]/)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join("");
}

let updated = 0;

for (const tool of aiTools) {
  const dir = path.join(appDir, "ai-tools", tool.id);
  const layoutPath = path.join(dir, "layout.tsx");

  if (!fs.existsSync(dir)) {
    console.log(`skip (no dir): ai-tools/${tool.id}`);
    continue;
  }

  fs.writeFileSync(layoutPath, createLayoutContent(tool), "utf-8");
  console.log(`updated: ${layoutPath}`);
  updated++;
}

console.log(`\nDone. Updated/Created: ${updated}`);
