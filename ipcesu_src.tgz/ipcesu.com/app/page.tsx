import type { Metadata } from "next";
import Script from "next/script";
import { HomeClient } from "@/components/home/home-client";
import { createMetadata, SITE_NAME, SITE_URL } from "@/lib/seo";

export const metadata: Metadata = createMetadata({
  title: "IPcesu 工具站 - 免费在线网络工具与网站检测平台",
  description:
    "IPcesu 工具站免费提供 Ping 测试、IP 查询、DNS 查询、SSL 检测、Whois 查询、Traceroute 路由追踪、网站测速、SEO 诊断、端口扫描等数十种在线网络工具，助力网站运维、网络诊断与性能优化。",
  keywords:
    "IPcesu, 在线工具, 网络工具, Ping 测试, IP 查询, DNS 查询, SSL 检测, Whois 查询, Traceroute, 网站测速, SEO 诊断, 端口扫描, 网站监控, 网络诊断",
  path: "/",
});

const websiteSchema = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: SITE_NAME,
  url: SITE_URL,
  description:
    "IPcesu 是专业的在线网络工具站，提供 Ping 测试、DNS 查询、SSL 检测、Whois 查询、网站测速、SEO 诊断等数十种免费网络工具。",
  potentialAction: {
    "@type": "SearchAction",
    target: {
      "@type": "EntryPoint",
      urlTemplate: `${SITE_URL}/tools?q={search_term_string}`,
    },
    "query-input": "required name=search_term_string",
  },
};

const organizationSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: SITE_NAME,
  url: SITE_URL,
  logo: `${SITE_URL}/logo.png`,
  sameAs: [],
};

export default function HomePage() {
  return (
    <main>
      <Script
        id="schema-website"
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteSchema) }}
      />
      <Script
        id="schema-organization"
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }}
      />
      <HomeClient />
    </main>
  );
}
