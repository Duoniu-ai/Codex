import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "SSL 检测",
  "HTTPS 安全检测",
  "analysis",
  "/ssl",
);

export default function SslLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
