"use client";

import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import { Lock, Calendar, Building2, Globe, Shield } from "lucide-react";

interface SslResult {
  domain: string;
  valid: boolean;
  issuer: string;
  validFrom: string;
  validTo: string;
  daysRemaining: number;
  subject: string;
  san: string[];
}

export default function SslPage() {
  return (
    <Suspense fallback={<SslPageSkeleton />}>
      <SslPageForm />
    </Suspense>
  );
}

function SslPageSkeleton() {
  return (
    <ToolPageLayout
      title="SSL 检测"
      description="检测 HTTPS 证书状态、有效期和颁发机构"
      icon={Lock}
      tips={[
        "输入域名即可检测 SSL 证书状态",
        "显示证书颁发机构、有效期和剩余天数",
        "检测证书是否受信任",
        "支持查看证书主题备用名称（SAN）",
      ]}
    >
      <div className="space-y-3">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
      </div>
    </ToolPageLayout>
  );
}

function SslPageForm() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get("q") || "";

  const [domain, setDomain] = useState(initialQuery);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<SslResult | null>(null);
  const [error, setError] = useState("");

  const handleCheck = async () => {
    if (!domain.trim()) return;

    setLoading(true);
    setError("");
    setResult(null);

    try {
      const res = await fetch("/api/ssl", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ domain: domain.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "检测失败");
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "检测失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ToolPageLayout
      title="SSL 检测"
      description="检查 HTTPS 证书有效期、颁发机构、证书链"
      icon={Lock}
      tips={[
        "输入域名即可检测 SSL 证书状态",
        "显示证书颁发机构、有效期和剩余天数",
        "检测证书是否受信任",
        "支持查看证书主题备用名称（SAN）",
      ]}
    >
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <Input
          value={domain}
          onChange={(e) => setDomain(e.target.value)}
          placeholder="例如：baidu.com"
          className="flex-1 bg-secondary/50 border-border/50"
        />
        <Button
          onClick={handleCheck}
          disabled={loading}
          className="bg-foreground hover:bg-foreground/90 text-background"
        >
          {loading ? "检测中..." : "检测"}
        </Button>
      </div>

      {error && (
        <div className="p-4 rounded-lg bg-destructive/10 text-destructive text-sm mb-6">
          {error}
        </div>
      )}

      {loading && (
        <div className="space-y-3">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
        </div>
      )}

      {result && !loading && (
        <div className="space-y-4 animate-fade-in-up">
          <div className="flex items-center gap-3 mb-4">
            <Badge
              variant={result.valid ? "default" : "destructive"}
              className={
                result.valid
                  ? "bg-green-500/15 text-green-600 hover:bg-green-500/20 border-0"
                  : ""
              }
            >
              {result.valid ? "证书有效" : "证书异常"}
            </Badge>
            <span className="text-sm text-muted-foreground">
              剩余 {result.daysRemaining} 天
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Building2 className="h-4 w-4 text-foreground" />
                  颁发机构
                </div>
                <div className="font-medium text-foreground">{result.issuer}</div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Globe className="h-4 w-4 text-foreground" />
                  主题
                </div>
                <div className="font-medium text-foreground">{result.subject}</div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Calendar className="h-4 w-4 text-foreground" />
                  生效时间
                </div>
                <div className="font-medium text-foreground">{result.validFrom}</div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Calendar className="h-4 w-4 text-foreground" />
                  到期时间
                </div>
                <div className="font-medium text-foreground">{result.validTo}</div>
              </CardContent>
            </Card>
          </div>

          {result.san.length > 0 && (
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3 text-muted-foreground text-sm">
                  <Shield className="h-4 w-4 text-foreground" />
                  主题备用名称（SAN）
                </div>
                <div className="flex flex-wrap gap-2">
                  {result.san.map((name, i) => (
                    <span
                      key={i}
                      className="text-sm font-mono px-2 py-1 rounded bg-secondary/50 text-foreground"
                    >
                      {name}
                    </span>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </ToolPageLayout>
  );
}