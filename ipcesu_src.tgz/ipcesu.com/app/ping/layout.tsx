import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "Ping 测试",
  "多节点网络延迟检测",
  "network",
  "/ping",
);

export default function PingLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
