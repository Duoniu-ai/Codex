"use client";

import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import { Activity, Server, Gauge, Percent } from "lucide-react";

interface PingResult {
  resolvedIp: string;
  avgLatency: number;
  packetLoss: number;
  status: "success" | "timeout" | "error";
  node: string;
}

export default function PingPage() {
  return (
    <Suspense fallback={<PingPageSkeleton />}>
      <PingPageForm />
    </Suspense>
  );
}

function PingPageSkeleton() {
  return (
    <ToolPageLayout
      title="Ping 测试"
      description="测试网络连通性与延迟，支持多节点对比"
      icon={Activity}
      tips={[
        "输入域名或 IP 地址即可测试网络连通性",
        "支持 IPv4 地址测试",
        "测试结果包括解析 IP、平均延迟和丢包率",
        "多次测试取平均值，结果更准确",
      ]}
    >
      <div className="space-y-3">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
      </div>
    </ToolPageLayout>
  );
}

function PingPageForm() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get("q") || "";

  const [target, setTarget] = useState(initialQuery);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<PingResult | null>(null);
  const [error, setError] = useState("");

  const handleTest = async () => {
    if (!target.trim()) return;

    setLoading(true);
    setError("");
    setResult(null);

    try {
      const res = await fetch("/api/ping", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ target: target.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "测试失败");
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "测试失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ToolPageLayout
      title="Ping 测试"
      description="全球多节点网络延迟检测"
      icon={Activity}
      tips={[
        "输入域名或 IP 地址即可测试网络连通性",
        "支持 IPv4 地址测试",
        "测试结果包括解析 IP、平均延迟和丢包率",
        "多次测试取平均值，结果更准确",
      ]}
    >
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <Input
          value={target}
          onChange={(e) => setTarget(e.target.value)}
          placeholder="例如: baidu.com 或 8.8.8.8"
          className="flex-1 bg-secondary/50 border-border/50"
        />
        <Button
          onClick={handleTest}
          disabled={loading}
          className="bg-foreground hover:bg-foreground/90 text-background"
        >
          {loading ? "测试中..." : "开始测试"}
        </Button>
      </div>

      {error && (
        <div className="p-4 rounded-lg bg-destructive/10 text-destructive text-sm mb-6">
          {error}
        </div>
      )}

      {loading && (
        <div className="space-y-3">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
        </div>
      )}

      {result && !loading && (
        <div className="space-y-4 animate-fade-in-up">
          <div className="flex items-center gap-3 mb-4">
            <Badge
              variant={result.status === "success" ? "default" : "destructive"}
              className={
                result.status === "success"
                  ? "bg-green-500/15 text-green-600 hover:bg-green-500/20 border-0"
                  : ""
              }
            >
              {result.status === "success" ? "正常" : "超时"}
            </Badge>
            <span className="text-sm text-muted-foreground">
              测试节点：{result.node}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Server className="h-4 w-4 text-foreground" />
                  解析 IP
                </div>
                <div className="font-medium font-mono text-foreground">{result.resolvedIp}</div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Gauge className="h-4 w-4 text-foreground" />
                  平均延迟
                </div>
                <div className="font-medium text-foreground">{result.avgLatency.toFixed(2)} ms</div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Percent className="h-4 w-4 text-foreground" />
                  丢包率
                </div>
                <div className="font-medium text-foreground">{result.packetLoss.toFixed(0)} %</div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </ToolPageLayout>
  );
}