"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Cookie } from "lucide-react";

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "安全", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "建议", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "风险", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="Cookie 安全检测"
      description="Cookie 安全配置检测"
      icon={Cookie}
      tips={[
        "输入目标 URL 即可模拟检测 Set-Cookie 安全属性。",
        "敏感 Cookie 必须设置 Secure 与 HttpOnly。",
        "SameSite 建议根据业务需要合理配置。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      onRun={async () => {
        await new Promise((r) => setTimeout(r, 600 + Math.floor(Math.random() * 400)));
        const cookies = [
          { name: "session_id", secure: Math.random() > 0.2, httpOnly: Math.random() > 0.3, sameSite: Math.random() > 0.4 ? "Strict" : "Lax" },
          { name: "auth_token", secure: Math.random() > 0.1, httpOnly: Math.random() > 0.2, sameSite: "Strict" },
          { name: "tracker", secure: Math.random() > 0.5, httpOnly: Math.random() > 0.7, sameSite: "None" },
        ];
        return { count: cookies.length, cookies };
      }}
      renderResult={(result) => {
        const data = result as {
          count: number;
          cookies: { name: string; secure: boolean; httpOnly: boolean; sameSite: string }[];
        };
        return (
          <div className="space-y-4">
            <Card className="border-l-4 border-l-foreground">
              <CardContent className="pt-6">
                <div className="text-sm text-muted-foreground">检测 Cookie 数</div>
                <div className="text-3xl font-bold">{data.count}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Cookie 安全属性</CardTitle>
                <CardDescription>Secure / HttpOnly / SameSite 检查</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>名称</TableHead>
                      <TableHead>Secure</TableHead>
                      <TableHead>HttpOnly</TableHead>
                      <TableHead>SameSite</TableHead>
                      <TableHead>评估</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.cookies.map((c) => {
                      const ok = c.secure && c.httpOnly && c.sameSite !== "None";
                      return (
                        <TableRow key={c.name}>
                          <TableCell>{c.name}</TableCell>
                          <TableCell>{statusBadge(c.secure ? "pass" : "risk")}</TableCell>
                          <TableCell>{statusBadge(c.httpOnly ? "pass" : "risk")}</TableCell>
                          <TableCell>{c.sameSite}</TableCell>
                          <TableCell>{statusBadge(ok ? "pass" : "warn")}</TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}