import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "Cookie 安全",
  "Cookie 安全配置检测",
  "security",
  "/cookie-security",
);

export default function CookieSecurityLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
