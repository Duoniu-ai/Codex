import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "Whois 查询",
  "域名注册信息",
  "domain",
  "/whois",
);

export default function WhoisLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
