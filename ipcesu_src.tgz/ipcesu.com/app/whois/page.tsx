"use client";

import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import { FileText, Building2, Calendar, Server } from "lucide-react";

interface WhoisResult {
  domain: string;
  registrar: string;
  creationDate: string;
  expirationDate: string;
  nameServers: string[];
  status: string[];
}

export default function WhoisPage() {
  return (
    <Suspense fallback={<WhoisPageSkeleton />}>
      <WhoisPageForm />
    </Suspense>
  );
}

function WhoisPageSkeleton() {
  return (
    <ToolPageLayout
      title="Whois 查询"
      description="查询域名注册信息、到期时间和 DNS 服务器"
      icon={FileText}
      tips={[
        "输入域名即可查询注册信息",
        "显示注册商、注册时间和到期时间",
        "查看域名 DNS 服务器和状态",
        "部分域名可能因隐私保护无法显示完整信息",
      ]}
    >
      <div className="space-y-3">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
      </div>
    </ToolPageLayout>
  );
}

function WhoisPageForm() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get("q") || "";

  const [domain, setDomain] = useState(initialQuery);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<WhoisResult | null>(null);
  const [error, setError] = useState("");

  const handleQuery = async () => {
    if (!domain.trim()) return;

    setLoading(true);
    setError("");
    setResult(null);

    try {
      const res = await fetch("/api/whois", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ domain: domain.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "查询失败");
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "查询失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ToolPageLayout
      title="Whois 查询"
      description="查询域名注册信息、到期时间、注册商"
      icon={FileText}
      tips={[
        "输入域名即可查询注册信息",
        "显示注册商、注册时间和到期时间",
        "查看域名 DNS 服务器和状态",
        "部分域名可能因隐私保护无法显示完整信息",
      ]}
    >
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <Input
          value={domain}
          onChange={(e) => setDomain(e.target.value)}
          placeholder="例如：baidu.com"
          className="flex-1 bg-secondary/50 border-border/50"
        />
        <Button
          onClick={handleQuery}
          disabled={loading}
          className="bg-foreground hover:bg-foreground/90 text-background"
        >
          {loading ? "查询中..." : "查询"}
        </Button>
      </div>

      {error && (
        <div className="p-4 rounded-lg bg-destructive/10 text-destructive text-sm mb-6">
          {error}
        </div>
      )}

      {loading && (
        <div className="space-y-3">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
        </div>
      )}

      {result && !loading && (
        <div className="space-y-4 animate-fade-in-up">
          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                <FileText className="h-4 w-4 text-foreground" />
                域名
              </div>
              <div className="text-xl font-bold font-mono text-foreground">{result.domain}</div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Building2 className="h-4 w-4 text-foreground" />
                  注册商
                </div>
                <div className="font-medium text-foreground">{result.registrar}</div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Calendar className="h-4 w-4 text-foreground" />
                  注册时间
                </div>
                <div className="font-medium text-foreground">{result.creationDate}</div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card sm:col-span-2">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Calendar className="h-4 w-4 text-foreground" />
                  到期时间
                </div>
                <div className="font-medium text-foreground">{result.expirationDate}</div>
              </CardContent>
            </Card>
          </div>

          {result.nameServers.length > 0 && (
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3 text-muted-foreground text-sm">
                  <Server className="h-4 w-4 text-foreground" />
                  DNS 服务器
                </div>
                <div className="flex flex-wrap gap-2">
                  {result.nameServers.map((ns, i) => (
                    <span
                      key={i}
                      className="text-sm font-mono px-2 py-1 rounded bg-secondary/50 text-foreground"
                    >
                      {ns}
                    </span>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {result.status.length > 0 && (
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3 text-muted-foreground text-sm">
                  <FileText className="h-4 w-4 text-foreground" />
                  域名状态
                </div>
                <div className="space-y-1">
                  {result.status.map((status, i) => (
                    <div key={i} className="text-sm text-foreground">
                      {status}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </ToolPageLayout>
  );
}