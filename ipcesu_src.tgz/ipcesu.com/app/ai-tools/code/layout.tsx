import type { Metadata } from "next";
import { createMetadata } from "@/lib/seo";

export const metadata: Metadata = createMetadata({
  title: "AI 代码助手 - AI 智能辅助工具",
  description:
    "代码生成优化。IPcesu AI 代码助手基于大模型能力，为网络检测、内容创作与代码开发提供智能辅助。",
  keywords:
    "AI 代码助手, AI 工具, 大模型, 智能辅助, IPcesu, 代码生成优化",
  path: "/ai-tools/code",
});

export default function CodeAiLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
