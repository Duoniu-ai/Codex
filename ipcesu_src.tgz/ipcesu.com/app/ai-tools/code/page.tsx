"use client";

import { Code } from "lucide-react";
import { AiToolPage } from "@/components/tools/ai-tool-page";

const sleep = () =>
  new Promise<void>((resolve) =>
    setTimeout(resolve, 400 + Math.floor(Math.random() * 401))
  );

export default function AiCodePage() {
  return (
    <AiToolPage
      title="AI 代码助手"
      description="代码生成优化"
      icon={Code}
      tips={[
        "说明使用的编程语言和运行环境",
        "描述清晰的输入输出格式",
        "提供关键约束或边界条件",
        "可要求生成单元测试或性能优化建议",
      ]}
      inputLabel="代码需求"
      inputPlaceholder="请输入需要实现的功能..."
      example="用 Python 写一个函数，检查 URL 是否可达"
      generateResponse={async (input) => {
        await sleep();
        return `已收到代码需求：“${input}”。\n\n实现思路如下：\n\n1. 根据目标语言选择合适的网络请求库，例如 Python 可使用 urllib.request 或 requests。\n2. 封装一个函数，接收 URL 参数，设置合理的超时时间（建议 5 秒）。\n3. 发送 HEAD 或 GET 请求，根据状态码判断可达性，2xx 与 3xx 视为正常。\n4. 对异常情况进行捕获，包括网络超时、DNS 解析失败、SSL 证书错误等，返回统一结果。\n5. 如需更高可靠性，可加入重试机制和代理支持。\n\n下方是一段示例伪代码结构，你可据此完成最终实现：\n\nfunction checkUrl(url):\n    try:\n        response = request(url, timeout=5)\n        return response.status < 400\n    except Exception as e:\n        return false, str(e)\n\n如果需要真实可运行的代码或单元测试，请补充语言和依赖版本。`;
      }}
    />
  );
}
