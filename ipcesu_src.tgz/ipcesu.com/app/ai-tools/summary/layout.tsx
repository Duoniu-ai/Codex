import type { Metadata } from "next";
import { createMetadata } from "@/lib/seo";

export const metadata: Metadata = createMetadata({
  title: "AI 智能摘要 - AI 智能辅助工具",
  description:
    "内容智能摘要。IPcesu AI 智能摘要基于大模型能力，为网络检测、内容创作与代码开发提供智能辅助。",
  keywords:
    "AI 智能摘要, AI 工具, 大模型, 智能辅助, IPcesu, 内容智能摘要",
  path: "/ai-tools/summary",
});

export default function SummaryAiLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
