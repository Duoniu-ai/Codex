"use client";

import { FileText } from "lucide-react";
import { AiToolPage } from "@/components/tools/ai-tool-page";

const sleep = () =>
  new Promise<void>((resolve) =>
    setTimeout(resolve, 400 + Math.floor(Math.random() * 401))
  );

export default function AiSummaryPage() {
  return (
    <AiToolPage
      title="AI 智能摘要"
      description="内容智能摘要"
      icon={FileText}
      tips={[
        "粘贴需要摘要的原文",
        "说明期望摘要长度",
        "可指定摘要风格，如简洁、学术、口语化",
        "长文可分段提交，提升摘要质量",
      ]}
      inputLabel="原始内容"
      inputPlaceholder="请粘贴需要总结的文章或段落..."
      example="（粘贴一段新闻或技术文章）"
      generateResponse={async (input) => {
        await sleep();
        return `已收到原始内容，现摘要如下：\n\n一、核心观点\n原文围绕“${input.slice(0, 30)}...”展开，主要说明了该主题的背景、关键问题及发展趋势。\n\n二、要点提炼\n1. 背景：介绍了当前环境及相关影响因素。\n2. 问题：指出了主要矛盾或挑战所在。\n3. 方案：提出了对应的解决思路或建议。\n4. 展望：总结了未来可能的发展方向。\n\n三、简要结论\n综合来看，合理应对上述问题需要结合实际场景，持续优化策略并跟踪效果。\n\n如需更精简的一句话摘要或按特定格式输出，请告诉我具体需求。`;
      }}
    />
  );
}
