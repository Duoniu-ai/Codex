import type { Metadata } from "next";
import { createMetadata } from "@/lib/seo";

export const metadata: Metadata = createMetadata({
  title: "AI 翻译助手 - AI 智能辅助工具",
  description:
    "多语言翻译。IPcesu AI 翻译助手基于大模型能力，为网络检测、内容创作与代码开发提供智能辅助。",
  keywords:
    "AI 翻译助手, AI 工具, 大模型, 智能辅助, IPcesu, 多语言翻译",
  path: "/ai-tools/translate",
});

export default function TranslateAiLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
