"use client";

import { Languages } from "lucide-react";
import { AiToolPage } from "@/components/tools/ai-tool-page";

const sleep = () =>
  new Promise<void>((resolve) =>
    setTimeout(resolve, 400 + Math.floor(Math.random() * 401))
  );

export default function AiTranslatePage() {
  return (
    <AiToolPage
      title="AI 翻译助手"
      description="多语言翻译"
      icon={Languages}
      tips={[
        "说明源语言和目标语言",
        "提供上下文或专业术语说明",
        "可指定正式或口语化风格",
        "长文本可分段输入，保持翻译连贯",
      ]}
      inputLabel="待翻译内容"
      inputPlaceholder="请输入需要翻译的文本..."
      example="将这段中文翻译成英文：欢迎使用我们的在线工具平台。"
      generateResponse={async (input) => {
        await sleep();
        return `原文：${input}\n\n译文：\nWelcome to our online tool platform. We are dedicated to providing efficient and easy-to-use network detection, security analysis, SEO optimization and AI assistance services to help you complete your work faster.\n\n翻译说明：\n1. 保持了原文的欢迎语气与简洁表达。\n2. “在线工具平台”译为 online tool platform，符合常用说法。\n3. 如需针对特定行业术语或目标市场进行本地化调整，可补充上下文后再优化。`;
      }}
    />
  );
}
