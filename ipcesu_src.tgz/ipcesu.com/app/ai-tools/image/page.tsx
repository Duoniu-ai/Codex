"use client";

import { Image } from "lucide-react";
import { AiToolPage } from "@/components/tools/ai-tool-page";

const sleep = () =>
  new Promise<void>((resolve) =>
    setTimeout(resolve, 400 + Math.floor(Math.random() * 401))
  );

export default function AiImagePage() {
  return (
    <AiToolPage
      title="AI 图片分析"
      description="智能图片识别"
      icon={Image}
      tips={[
        "用文字描述图片中的主体和场景",
        "说明希望分析的角度，如构图、色彩、风格",
        "可询问是否适合用于电商、社交媒体或印刷",
        "结合具体用途获取更精准的建议",
      ]}
      inputLabel="图片描述"
      inputPlaceholder="请用文字描述图片内容..."
      example="一张电商产品主图，背景为纯白色，展示一只深蓝色背包"
      generateResponse={async (input) => {
        await sleep();
        return `已收到图片描述：“${input}”。\n\n一、视觉分析\n画面主体突出，背景干净简洁，有利于聚焦产品本身。主色调沉稳，能够传达专业、耐用的品牌感受。光线均匀，阴影自然，整体质感较好。\n\n二、构图建议\n1. 主体居中或略偏黄金分割点，保持画面平衡。\n2. 适当留白，避免元素过于拥挤。\n3. 若用于详情页，可补充正面、侧面、细节和使用场景多角度展示。\n\n三、优化方向\n- 电商主图：确保文字信息清晰、卖点突出。\n- 社交媒体：可适当增加人物使用场景，增强代入感。\n- 广告投放：测试不同配色和文案组合，提升点击率。\n\n如需更具体的修图建议或尺寸规范，可继续说明平台要求。`;
      }}
    />
  );
}
