import type { Metadata } from "next";
import { createMetadata } from "@/lib/seo";

export const metadata: Metadata = createMetadata({
  title: "AI 图片分析 - AI 智能辅助工具",
  description:
    "智能图片识别。IPcesu AI 图片分析基于大模型能力，为网络检测、内容创作与代码开发提供智能辅助。",
  keywords:
    "AI 图片分析, AI 工具, 大模型, 智能辅助, IPcesu, 智能图片识别",
  path: "/ai-tools/image",
});

export default function ImageAiLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
