import Link from "next/link";
import type { Metadata } from "next";
import { aiTools } from "@/lib/tools";
import { Card, CardContent } from "@/components/ui/card";
import { createMetadata } from "@/lib/seo";

export const metadata: Metadata = createMetadata({
  title: "AI 工具 - 智能网络检测与内容创作助手",
  description:
    "IPcesu AI 工具基于大模型能力，提供 AI 智能对话、代码助手、SEO 优化、安全分析、智能摘要、翻译、图片分析等智能辅助能力。",
  keywords:
    "AI 工具, AI 对话, AI 代码助手, AI SEO, AI 安全分析, AI 翻译, AI 图片分析, 智能工具, 大模型",
  path: "/ai-tools",
});

export default function AiToolsPage() {
  return (
    <main className="container mx-auto px-4 py-12">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">AI 智能工具</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            基于大模型的智能辅助能力，把检测结果变成可执行的建议，提升网络诊断与内容创作效率。
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {aiTools.map((tool) => (
            <Link key={tool.id} href={tool.href}>
              <Card className="h-full border-border bg-card/50 backdrop-blur-sm hover:border-purple-500/40 transition-all">
                <CardContent className="p-6">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-purple-500/10 text-purple-500 mb-4">
                    <tool.icon className="h-6 w-6" />
                  </div>
                  <h2 className="font-semibold text-lg mb-1">{tool.label}</h2>
                  <p className="text-sm text-muted-foreground">
                    {tool.description}
                  </p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </main>
  );
}