"use client";

import { Search } from "lucide-react";
import { AiToolPage } from "@/components/tools/ai-tool-page";

const sleep = () =>
  new Promise<void>((resolve) =>
    setTimeout(resolve, 400 + Math.floor(Math.random() * 401))
  );

export default function AiSeoPage() {
  return (
    <AiToolPage
      title="AI SEO 优化"
      description="SEO 优化建议"
      icon={Search}
      tips={[
        "提供网页标题和目标关键词",
        "说明目标搜索引擎与行业竞争情况",
        "描述当前排名和流量数据",
        "列出已做过的优化措施",
      ]}
      inputLabel="页面/关键词"
      inputPlaceholder="请输入页面主题或关键词..."
      example="云服务器选购指南"
      generateResponse={async (input) => {
        await sleep();
        return `已收到优化目标：“${input}”。\n\n一、关键词策略\n围绕核心词拓展长尾关键词，如“云服务器哪家好”“云服务器配置推荐”“高性价比云服务器”。在标题、首段、H2/H3 标题中自然分布关键词，避免堆砌。\n\n二、页面优化\n1. 标题长度控制在 30 字以内，包含核心词。\n2. Meta Description 清晰概括内容，吸引点击。\n3. 图片添加描述性 Alt 文本，提升可读性与收录机会。\n\n三、内容建设\n提供对比表格、选购清单和真实案例，增加页面深度与停留时间。定期更新价格与优惠信息，保持内容新鲜度。\n\n四、外链与内链\n在相关文章中添加内链指向本页面，同时争取行业媒体或论坛的高质量外链。持续监测排名变化并迭代优化。`;
      }}
    />
  );
}
