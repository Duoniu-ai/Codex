import type { Metadata } from "next";
import { createMetadata } from "@/lib/seo";

export const metadata: Metadata = createMetadata({
  title: "AI SEO 优化 - AI 智能辅助工具",
  description:
    "SEO 优化建议。IPcesu AI SEO 优化基于大模型能力，为网络检测、内容创作与代码开发提供智能辅助。",
  keywords:
    "AI SEO 优化, AI 工具, 大模型, 智能辅助, IPcesu, SEO 优化建议",
  path: "/ai-tools/seo",
});

export default function SeoAiLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
