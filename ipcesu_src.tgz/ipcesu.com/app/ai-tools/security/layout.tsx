import type { Metadata } from "next";
import { createMetadata } from "@/lib/seo";

export const metadata: Metadata = createMetadata({
  title: "AI 安全分析 - AI 智能辅助工具",
  description:
    "网站安全分析。IPcesu AI 安全分析基于大模型能力，为网络检测、内容创作与代码开发提供智能辅助。",
  keywords:
    "AI 安全分析, AI 工具, 大模型, 智能辅助, IPcesu, 网站安全分析",
  path: "/ai-tools/security",
});

export default function SecurityAiLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
