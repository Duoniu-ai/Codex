"use client";

import { Shield } from "lucide-react";
import { AiToolPage } from "@/components/tools/ai-tool-page";

const sleep = () =>
  new Promise<void>((resolve) =>
    setTimeout(resolve, 400 + Math.floor(Math.random() * 401))
  );

export default function AiSecurityPage() {
  return (
    <AiToolPage
      title="AI 安全分析"
      description="网站安全分析"
      icon={Shield}
      tips={[
        "提供需要分析的域名或安全场景",
        "说明关注的安全风险类型",
        "描述已部署的安全措施",
        "可要求输出整改优先级与建议方案",
      ]}
      inputLabel="检测目标"
      inputPlaceholder="请输入域名或安全场景..."
      example="example.com 网站安全分析"
      generateResponse={async (input) => {
        await sleep();
        return `已收到安全分析目标：“${input}”。\n\n一、常见风险点\n1. HTTPS 配置：检查是否启用 HSTS、TLS 版本是否过低、证书是否过期。\n2. 响应头安全：确认是否配置 X-Frame-Options、Content-Security-Policy、X-Content-Type-Options 等。\n3. 敏感信息泄露：排查源码、API 响应、错误页面中是否暴露服务器版本、数据库地址或密钥。\n\n二、访问控制\n检查后台路径是否可被公开访问、是否存在默认口令、登录接口是否有防暴力破解机制。\n\n三、整改优先级\n高：修复 SSL/TLS 弱配置、清理敏感信息泄露。\n中：完善安全响应头、启用 WAF 防护。\n低：优化日志审计与告警策略。\n\n建议结合自动化扫描工具与人工渗透测试，定期进行安全复查。`;
      }}
    />
  );
}
