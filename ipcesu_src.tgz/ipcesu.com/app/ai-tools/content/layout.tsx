import type { Metadata } from "next";
import { createMetadata } from "@/lib/seo";

export const metadata: Metadata = createMetadata({
  title: "AI 文案生成 - AI 智能辅助工具",
  description:
    "营销文案创作。IPcesu AI 文案生成基于大模型能力，为网络检测、内容创作与代码开发提供智能辅助。",
  keywords:
    "AI 文案生成, AI 工具, 大模型, 智能辅助, IPcesu, 营销文案创作",
  path: "/ai-tools/content",
});

export default function ContentAiLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
