"use client";

import { Sparkles } from "lucide-react";
import { AiToolPage } from "@/components/tools/ai-tool-page";

const sleep = () =>
  new Promise<void>((resolve) =>
    setTimeout(resolve, 400 + Math.floor(Math.random() * 401))
  );

export default function AiContentPage() {
  return (
    <AiToolPage
      title="AI 文案生成"
      description="营销文案创作"
      icon={Sparkles}
      tips={[
        "描述目标人群和主要推广渠道",
        "提供产品卖点与差异化优势",
        "说明想要的文案风格，如活泼、专业、简洁",
        "可指定字数、关键词或需要突出的行动号召",
      ]}
      inputLabel="文案主题"
      inputPlaceholder="请输入产品、活动或主题..."
      example="为一款降噪耳机撰写小红书推广文案"
      generateResponse={async (input) => {
        await sleep();
        return `已收到文案主题：“${input}”。\n\n一、核心卖点提炼\n结合用户需求，提炼出“静谧聆听、超长续航、舒适佩戴”三大卖点，并用真实场景唤起共鸣。\n\n二、标题建议\n1. 还你一片安静，通勤也能沉浸听歌\n2. 戴上它，世界瞬间静音\n\n三、正文方向\n开头用场景切入，中间突出参数与体验，结尾加入限时优惠或行动号召。注意使用短句、表情符号和口语化表达，提升亲和力。\n\n四、行动号召\n引导用户点击链接、领取优惠券或评论互动，提升转化率。如需完整成稿，可继续告诉我具体字数和平台要求。`;
      }}
    />
  );
}
