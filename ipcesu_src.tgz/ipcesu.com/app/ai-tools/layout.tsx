import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "AI 工具 - IPcesu 工具站",
  description:
    "IPcesu 提供基于大模型的 AI 智能对话、文案生成、代码助手、SEO 优化、安全分析等智能工具。",
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
