import type { Metadata } from "next";
import { createMetadata } from "@/lib/seo";

export const metadata: Metadata = createMetadata({
  title: "AI 智能对话 - AI 智能辅助工具",
  description:
    "智能问答助手。IPcesu AI 智能对话基于大模型能力，为网络检测、内容创作与代码开发提供智能辅助。",
  keywords:
    "AI 智能对话, AI 工具, 大模型, 智能辅助, IPcesu, 智能问答助手",
  path: "/ai-tools/chat",
});

export default function ChatAiLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
