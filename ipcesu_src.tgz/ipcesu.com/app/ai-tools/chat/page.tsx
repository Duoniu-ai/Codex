"use client";

import { Bot } from "lucide-react";
import { AiToolPage } from "@/components/tools/ai-tool-page";

const sleep = () =>
  new Promise<void>((resolve) =>
    setTimeout(resolve, 400 + Math.floor(Math.random() * 401))
  );

export default function AiChatPage() {
  return (
    <AiToolPage
      title="AI 智能对话"
      description="智能问答助手"
      icon={Bot}
      tips={[
        "问题尽量具体，答案会更准确",
        "可一次围绕一个主题展开，方便理解上下文",
        "如需示例，可说明期望的输出格式",
        "复杂问题可拆分为多步提问，逐步深入",
      ]}
      inputLabel="对话内容"
      inputPlaceholder="请输入你想咨询的问题..."
      example="如何为网站选择合适的 SSL 证书？"
      generateResponse={async (input) => {
        await sleep();
        return `收到你的问题：“${input}”。\n\n针对这一问题，建议从实际场景出发：先明确目标受众和使用场景，再列出核心需求与约束条件。接着收集相关资料、对比不同方案，并优先验证关键假设。执行过程中保持迭代，根据反馈及时调整方向。\n\n如果你需要更具体的步骤、代码示例或模板，可以继续补充背景信息，我会进一步帮你完善。`;
      }}
    />
  );
}
