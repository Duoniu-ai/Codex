"use client";

import { useState } from "react";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Copy, Check, ArrowRightLeft, RotateCcw } from "lucide-react";

export default function Page() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [mode, setMode] = useState<"encode" | "decode">("encode");
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);

  const handleConvert = () => {
    try {
      if (!input) {
        setOutput("");
        setError("");
        return;
      }
      if (mode === "encode") {
        setOutput(btoa(unescape(encodeURIComponent(input))));
      } else {
        setOutput(decodeURIComponent(escape(atob(input))));
      }
      setError("");
    } catch (e) {
      setError(mode === "encode" ? "编码失败" : "解码失败：输入内容不是有效的 Base64");
      setOutput("");
    }
  };

  const handleSwap = () => {
    setMode(mode === "encode" ? "decode" : "encode");
    setInput(output);
    setOutput(input);
    setError("");
  };

  const handleCopy = async () => {
    if (!output) return;
    await navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const handleReset = () => {
    setInput("");
    setOutput("");
    setError("");
  };

  return (
    <ToolPageLayout
      title="Base64 编解码"
      description="Base64 编码与解码工具，支持中文"
      icon={FileText}
      tips={[
        "输入文本可进行 Base64 编码。",
        "输入 Base64 字符串可进行解码。",
        "支持中文字符，自动处理 Unicode。",
        "所有转换在浏览器本地完成。",
      ]}
    >
      <Card className="border-border/50 bg-card">
        <CardContent className="p-5 space-y-5">
          <div className="flex items-center gap-2">
            <Button
              variant={mode === "encode" ? "default" : "outline"}
              size="sm"
              onClick={() => {
                setMode("encode");
                setOutput("");
                setError("");
              }}
            >
              编码
            </Button>
            <Button
              variant={mode === "decode" ? "default" : "outline"}
              size="sm"
              onClick={() => {
                setMode("decode");
                setOutput("");
                setError("");
              }}
            >
              解码
            </Button>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">输入</label>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={mode === "encode" ? "输入需要编码的文本" : "输入需要解码的 Base64"}
              className="w-full min-h-[120px] rounded-lg border border-input bg-transparent px-3 py-2 text-sm placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 outline-none resize-y"
            />
          </div>

          <div className="flex flex-wrap gap-2">
            <Button onClick={handleConvert}>立即转换</Button>
            <Button variant="outline" onClick={handleSwap}>
              <ArrowRightLeft className="h-4 w-4 mr-1.5" />
              交换
            </Button>
            <Button variant="outline" onClick={handleReset}>
              <RotateCcw className="h-4 w-4 mr-1.5" />
              清空
            </Button>
          </div>

          {error && (
            <div className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">
              {error}
            </div>
          )}

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">结果</label>
              {output && (
                <Button variant="ghost" size="sm" onClick={handleCopy}>
                  {copied ? <Check className="h-4 w-4 mr-1.5" /> : <Copy className="h-4 w-4 mr-1.5" />}
                  {copied ? "已复制" : "复制"}
                </Button>
              )}
            </div>
            <div className="min-h-[80px] rounded-lg border border-border/50 bg-muted/30 px-3 py-2 text-sm break-all">
              {output || <span className="text-muted-foreground">转换结果将显示在这里</span>}
            </div>
          </div>
        </CardContent>
      </Card>
    </ToolPageLayout>
  );
}