"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Link } from "lucide-react";

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "有效", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "低质", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "失效", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="友情链接查询"
      description="检测友链有效性与 SEO 价值"
      icon={Link}
      tips={[
        "输入目标域名即可模拟分析友情链接。",
        "关注对方是否使用 nofollow 或已无法访问。",
        "友链数量过多可能稀释权重。",
      ]}
      inputs={[
        { id: "domain", label: "目标域名", type: "text", placeholder: "example.com" },
      ]}
      onRun={async () => {
        await new Promise((r) => setTimeout(r, 700 + Math.floor(Math.random() * 500)));
        const total = Math.floor(5 + Math.random() * 15);
        const dofollow = Math.floor(total * (0.6 + Math.random() * 0.3));
        const nofollow = total - dofollow;
        const dead = Math.floor(Math.random() * 3);
        const links = Array.from({ length: Math.min(total, 6) }).map((_, i) => ({
          url: `https://friend-${i + 1}.com`,
          anchor: `友链 ${i + 1}`,
          rel: i < nofollow ? "nofollow" : "dofollow",
          status: i < dead ? "risk" : i < nofollow ? "warn" : "pass" as "pass" | "warn" | "risk",
        }));
        return { total, dofollow, nofollow, dead, links };
      }}
      renderResult={(result) => {
        const data = result as {
          total: number;
          dofollow: number;
          nofollow: number;
          dead: number;
          links: { url: string; anchor: string; rel: string; status: "pass" | "warn" | "risk" }[];
        };
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">友链总数</div><div className="text-2xl font-semibold">{data.total}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">Dofollow</div><div className="text-2xl font-semibold text-green-700">{data.dofollow}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">Nofollow</div><div className="text-2xl font-semibold text-amber-700">{data.nofollow}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">失效</div><div className="text-2xl font-semibold text-red-700">{data.dead}</div></CardContent></Card>
            </div>
            <Card>
              <CardHeader>
                <CardTitle>友链详情</CardTitle>
                <CardDescription>抽样展示检测到的友情链接</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>链接</TableHead>
                      <TableHead>锚文本</TableHead>
                      <TableHead>Rel</TableHead>
                      <TableHead>状态</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.links.map((item, idx) => (
                      <TableRow key={idx}>
                        <TableCell className="whitespace-normal max-w-xs break-all">{item.url}</TableCell>
                        <TableCell>{item.anchor}</TableCell>
                        <TableCell>{item.rel}</TableCell>
                        <TableCell>{statusBadge(item.status)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}