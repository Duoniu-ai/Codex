import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "友情链接查询",
  "检测友链有效性与 SEO 价值",
  "analysis",
  "/backlink-check",
);

export default function BacklinkCheckLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
