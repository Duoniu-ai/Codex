import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "正则测试",
  "在线正则表达式测试",
  "dev",
  "/regex",
);

export default function RegexLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
