"use client";

import { useState, useEffect } from "react";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Regex, Copy, Check } from "lucide-react";

export default function Page() {
  const [pattern, setPattern] = useState("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}");
  const [flags, setFlags] = useState("g");
  const [text, setText] = useState("");
  const [matches, setMatches] = useState<string[]>([]);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!pattern || !text) {
      setMatches([]);
      setError("");
      return;
    }
    try {
      const regex = new RegExp(pattern, flags);
      const result = text.match(regex);
      setMatches(result || []);
      setError("");
    } catch (e) {
      setError("正则表达式语法错误");
      setMatches([]);
    }
  }, [pattern, flags, text]);

  const handleCopyPattern = async () => {
    await navigator.clipboard.writeText(`/${pattern}/${flags}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const samples = [
    { label: "邮箱", pattern: "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}", flags: "g" },
    { label: "手机号", pattern: "1[3-9]\\d{9}", flags: "g" },
    { label: "IP 地址", pattern: "(?:\\d{1,3}\\.){3}\\d{1,3}", flags: "g" },
    { label: "URL", pattern: "https?://[^\\s]+", flags: "g" },
  ];

  return (
    <ToolPageLayout
      title="正则测试"
      description="在线正则表达式测试，实时匹配结果"
      icon={Regex}
      tips={[
        "输入正则表达式和待匹配文本，实时查看匹配结果。",
        "支持常用标志位：g（全局）、i（忽略大小写）、m（多行）。",
        "可点击常用正则快速填充。",
        "所有匹配在浏览器本地完成。",
      ]}
    >
      <Card className="border-border/50 bg-card">
        <CardContent className="p-5 space-y-5">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">常用正则</label>
            </div>
            <div className="flex flex-wrap gap-2">
              {samples.map((s) => (
                <Button
                  key={s.label}
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setPattern(s.pattern);
                    setFlags(s.flags);
                  }}
                >
                  {s.label}
                </Button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div className="sm:col-span-3 space-y-2">
              <label className="text-sm font-medium">正则表达式</label>
              <div className="flex items-center gap-2 rounded-lg border border-input bg-transparent px-3 py-2">
                <span className="text-muted-foreground">/</span>
                <input
                  type="text"
                  value={pattern}
                  onChange={(e) => setPattern(e.target.value)}
                  placeholder="输入正则表达式"
                  className="flex-1 bg-transparent outline-none text-sm"
                />
                <span className="text-muted-foreground">/</span>
                <input
                  type="text"
                  value={flags}
                  onChange={(e) => setFlags(e.target.value)}
                  placeholder="flags"
                  className="w-16 bg-transparent outline-none text-sm text-center"
                />
              </div>
            </div>
            <div className="flex items-end">
              <Button variant="outline" className="w-full" onClick={handleCopyPattern}>
                {copied ? <Check className="h-4 w-4 mr-1.5" /> : <Copy className="h-4 w-4 mr-1.5" />}
                {copied ? "已复制" : "复制"}
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">测试文本</label>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="输入需要测试的文本"
              className="w-full min-h-[120px] rounded-lg border border-input bg-transparent px-3 py-2 text-sm placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 outline-none resize-y"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">匹配结果</label>
            {error ? (
              <div className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">
                {error}
              </div>
            ) : matches.length > 0 ? (
              <div className="rounded-lg border border-border/50 bg-muted/30 p-3 space-y-1">
                <div className="text-xs text-muted-foreground mb-2">共匹配 {matches.length} 处</div>
                {matches.map((m, i) => (
                  <code key={i} className="block text-xs break-all text-foreground bg-background rounded px-2 py-1">
                    {m}
                  </code>
                ))}
              </div>
            ) : text ? (
              <div className="rounded-lg border border-border/50 bg-muted/30 px-3 py-8 text-center text-sm text-muted-foreground">
                未匹配到任何结果
              </div>
            ) : (
              <div className="rounded-lg border border-border/50 bg-muted/30 px-3 py-8 text-center text-sm text-muted-foreground">
                输入测试文本后查看匹配结果
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </ToolPageLayout>
  );
}