import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "路由追踪",
  "追踪网络路由路径",
  "network",
  "/traceroute",
);

export default function TracerouteLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
