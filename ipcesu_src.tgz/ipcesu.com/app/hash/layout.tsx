import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "Hash 生成器",
  "MD5/SHA 哈希生成",
  "dev",
  "/hash",
);

export default function HashLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
