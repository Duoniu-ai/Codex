"use client";

import { useState, useEffect } from "react";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Hash, Copy, Check } from "lucide-react";

const algorithms = [
  { id: "md5", label: "MD5" },
  { id: "sha1", label: "SHA-1" },
  { id: "sha256", label: "SHA-256" },
  { id: "sha384", label: "SHA-384" },
  { id: "sha512", label: "SHA-512" },
];

async function digest(algorithm: string, text: string) {
  const encoder = new TextEncoder();
  const data = encoder.encode(text);
  const hashBuffer = await crypto.subtle.digest(algorithm, data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

export default function Page() {
  const [input, setInput] = useState("");
  const [results, setResults] = useState<Record<string, string>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    if (!input) {
      setResults({});
      return;
    }
    (async () => {
      const next: Record<string, string> = {};
      for (const alg of algorithms) {
        next[alg.id] = await digest(alg.id.toUpperCase(), input);
      }
      setResults(next);
    })();
  }, [input]);

  const handleCopy = async (id: string, value: string) => {
    await navigator.clipboard.writeText(value);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  return (
    <ToolPageLayout
      title="Hash 生成器"
      description="MD5 / SHA 哈希在线生成，支持多种算法"
      icon={Hash}
      tips={[
        "输入任意文本，实时生成多种哈希值。",
        "支持 MD5、SHA-1、SHA-256、SHA-384、SHA-512。",
        "哈希值常用于文件校验、密码存储、数据签名。",
        "所有计算在浏览器本地完成，数据不会上传到服务器。",
      ]}
    >
      <Card className="border-border/50 bg-card">
        <CardContent className="p-5 space-y-5">
          <div className="space-y-2">
            <label className="text-sm font-medium">输入文本</label>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="输入需要生成 Hash 的文本"
              className="w-full min-h-[120px] rounded-lg border border-input bg-transparent px-3 py-2 text-sm placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 outline-none resize-y"
            />
          </div>

          <div className="space-y-3">
            <label className="text-sm font-medium">生成结果</label>
            {input ? (
              <div className="space-y-2">
                {algorithms.map((alg) => (
                  <div
                    key={alg.id}
                    className="flex items-center gap-3 rounded-lg border border-border/50 bg-muted/30 px-3 py-2"
                  >
                    <span className="w-20 shrink-0 text-sm font-medium">{alg.label}</span>
                    <code className="flex-1 min-w-0 text-xs break-all text-muted-foreground">
                      {results[alg.id] || "计算中..."}
                    </code>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="shrink-0"
                      disabled={!results[alg.id]}
                      onClick={() => handleCopy(alg.id, results[alg.id])}
                    >
                      {copiedId === alg.id ? (
                        <Check className="h-4 w-4" />
                      ) : (
                        <Copy className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="rounded-lg border border-border/50 bg-muted/30 px-3 py-8 text-center text-sm text-muted-foreground">
                输入文本后将自动生成 Hash 结果
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </ToolPageLayout>
  );
}