import Link from "next/link";
import type { Metadata } from "next";
import { tools, aiTools, toolCategories } from "@/lib/tools";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { createMetadata } from "@/lib/seo";
import { cn } from "@/lib/utils";
import { ArrowRight, Layers } from "lucide-react";

export const metadata: Metadata = createMetadata({
  title: "工具集 - 免费在线网络工具大全",
  description:
    "IPcesu 工具集收录网络诊断、网站测速、批量检测、SEO 分析、域名查询、安全检测、开发工具等数十款免费在线工具，无需安装，打开即用。",
  keywords:
    "工具集, 在线工具大全, 网络工具, 网站测速, SEO 工具, 域名工具, 安全工具, 开发工具, 免费工具",
  path: "/tools",
});

const categoryStyles: Record<string, string> = {
  network: "bg-blue-500/10 text-blue-600",
  speed: "bg-cyan-500/10 text-cyan-600",
  batch: "bg-indigo-500/10 text-indigo-600",
  analysis: "bg-emerald-500/10 text-emerald-600",
  domain: "bg-orange-500/10 text-orange-600",
  security: "bg-red-500/10 text-red-600",
  seo: "bg-purple-500/10 text-purple-600",
  dev: "bg-slate-500/10 text-slate-600",
  ai: "bg-pink-500/10 text-pink-600",
};

export default function ToolsPage() {
  return (
    <main className="container mx-auto px-4 py-12">
      <div className="max-w-[1400px] mx-auto">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center p-3 bg-primary/10 rounded-2xl mb-4">
            <Layers className="h-8 w-8 text-primary" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-4">工具分类</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            全方位的网络检测与网站分析工具，助您快速诊断网络问题、分析网站状态、提升运维效率。
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {toolCategories.map((category) => {
            const categoryTools =
              category.id === "ai"
                ? aiTools
                : tools.filter((tool) => tool.category === category.id);

            if (categoryTools.length === 0) return null;

            return (
              <Card
                key={category.id}
                className="group border-border/40 bg-card shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300 overflow-hidden"
              >
                <CardHeader className="bg-gradient-to-r from-slate-100/80 to-slate-50/80 dark:from-slate-900/50 dark:to-slate-800/50 pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base flex items-center gap-2.5">
                      <div
                        className={cn(
                          "flex h-9 w-9 items-center justify-center rounded-lg",
                          categoryStyles[category.id] ??
                            "bg-primary/10 text-primary"
                        )}
                      >
                        <category.icon className="h-5 w-5" />
                      </div>
                      <div className="flex flex-col">
                        <span className="leading-tight">{category.label}</span>
                        <span className="text-xs font-normal text-muted-foreground">
                          {category.description}
                        </span>
                      </div>
                    </CardTitle>
                    <Badge
                      variant="secondary"
                      className="bg-background text-muted-foreground font-normal"
                    >
                      {categoryTools.length} 个
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="grid grid-cols-2">
                    {categoryTools.map((tool, index) => (
                      <Link
                        key={tool.id}
                        href={tool.href}
                        className={cn(
                          "block p-4 hover:bg-accent hover:text-accent-foreground transition-colors group/item",
                          index % 2 === 0 ? "border-r border-border/50" : "",
                          index < categoryTools.length - 2
                            ? "border-b border-border/50"
                            : ""
                        )}
                        title={tool.description}
                      >
                        <div className="flex items-start justify-between gap-2 mb-1">
                          <div className="flex items-center gap-2 min-w-0">
                            <tool.icon className="h-3.5 w-3.5 shrink-0 text-muted-foreground group-hover/item:text-accent-foreground/80" />
                            <span className="text-sm font-medium text-foreground group-hover/item:text-accent-foreground truncate">
                              {tool.label}
                            </span>
                          </div>
                          {tool.badge && (
                            <Badge
                              variant="outline"
                              className="shrink-0 text-[10px] px-1 py-0 h-auto border-amber-200 bg-amber-50 text-amber-700"
                            >
                              {tool.badge}
                            </Badge>
                          )}
                        </div>
                        <div className="text-xs text-muted-foreground group-hover/item:text-accent-foreground/70 line-clamp-1 pl-5">
                          {tool.description}
                        </div>
                      </Link>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="mt-12 text-center">
          <Link
            href="/"
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            返回首页 <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </main>
  );
}