import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "工具集 - IPcesu 工具站",
  description:
    "IPcesu 工具站提供 IP 查询、Ping 测试、DNS 查询、SSL 检测、Whois 查询、路由追踪等网络检测与网站分析工具。",
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
