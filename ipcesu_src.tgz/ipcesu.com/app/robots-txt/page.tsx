"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { FileSearch } from "lucide-react";

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "合规", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "注意", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "风险", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="Robots 检测"
      description="爬虫规则分析"
      icon={FileSearch}
      tips={[
        "将 robots.txt 内容粘贴到输入框中进行分析。",
        "关注是否误屏蔽了重要页面或整站。",
        "建议配合 Sitemap 路径检查抓取策略。",
      ]}
      inputs={[
        { id: "content", label: "robots.txt 内容", type: "textarea", placeholder: "User-agent: *\nDisallow: /admin/\nSitemap: https://example.com/sitemap.xml", rows: 6 },
      ]}
      onRun={async (values) => {
        await new Promise((r) => setTimeout(r, 600 + Math.floor(Math.random() * 400)));
        const lines = values.content.split("\n").filter((l) => l.trim());
        const userAgents = lines.filter((l) => l.trim().toLowerCase().startsWith("user-agent")).length;
        const disallows = lines.filter((l) => l.trim().toLowerCase().startsWith("disallow")).length;
        const allows = lines.filter((l) => l.trim().toLowerCase().startsWith("allow")).length;
        const sitemaps = lines.filter((l) => l.trim().toLowerCase().startsWith("sitemap")).length;
        const hasWildcardDisallow = lines.some((l) => l.toLowerCase().includes("disallow: /"));
        return { userAgents, disallows, allows, sitemaps, hasWildcardDisallow };
      }}
      renderResult={(result) => {
        const data = result as { userAgents: number; disallows: number; allows: number; sitemaps: number; hasWildcardDisallow: boolean };
        const checks: { name: string; status: "pass" | "warn" | "risk"; detail: string }[] = [
          { name: "User-agent 声明", status: data.userAgents > 0 ? "pass" : "warn", detail: `发现 ${data.userAgents} 个 User-agent` },
          { name: "Sitemap 配置", status: data.sitemaps > 0 ? "pass" : "warn", detail: data.sitemaps > 0 ? "已配置 Sitemap" : "未配置 Sitemap" },
          { name: "Disallow 规则", status: data.disallows > 0 ? "pass" : "warn", detail: `共 ${data.disallows} 条 Disallow 规则` },
          { name: "全站屏蔽检查", status: data.hasWildcardDisallow ? "risk" : "pass", detail: data.hasWildcardDisallow ? "存在 Disallow: / 规则" : "未全站屏蔽" },
        ];
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">User-agent</div><div className="text-2xl font-semibold">{data.userAgents}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">Disallow</div><div className="text-2xl font-semibold">{data.disallows}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">Allow</div><div className="text-2xl font-semibold">{data.allows}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">Sitemap</div><div className="text-2xl font-semibold">{data.sitemaps}</div></CardContent></Card>
            </div>
            <Card>
              <CardHeader>
                <CardTitle>规则分析</CardTitle>
                <CardDescription>robots.txt 配置检查</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>检查项</TableHead>
                      <TableHead>状态</TableHead>
                      <TableHead>说明</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {checks.map((c) => (
                      <TableRow key={c.name}>
                        <TableCell>{c.name}</TableCell>
                        <TableCell>{statusBadge(c.status)}</TableCell>
                        <TableCell className="whitespace-normal">{c.detail}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}