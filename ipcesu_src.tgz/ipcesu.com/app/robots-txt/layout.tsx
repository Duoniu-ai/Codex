import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "Robots 检测",
  "爬虫规则分析",
  "seo",
  "/robots-txt",
);

export default function RobotsTxtLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
