import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "邮件安全检测",
  "SPF/DKIM/DMARC 检测",
  "security",
  "/email-security",
);

export default function EmailSecurityLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
