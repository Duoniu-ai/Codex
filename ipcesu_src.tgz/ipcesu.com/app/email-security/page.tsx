"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { MailCheck } from "lucide-react";

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "通过", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "建议", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "缺失", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="邮件安全检测"
      description="检测域名 SPF、DKIM、DMARC 邮件安全记录"
      icon={MailCheck}
      tips={[
        "输入域名即可模拟检测邮件安全记录。",
        "SPF 可防止伪造发件人，DMARC 提供策略与报告。",
        "建议同时配置 DKIM 签名提升邮件可信度。",
      ]}
      inputs={[
        { id: "domain", label: "目标域名", type: "text", placeholder: "example.com" },
      ]}
      onRun={async () => {
        await new Promise((r) => setTimeout(r, 700 + Math.floor(Math.random() * 400)));
        return {
          records: [
            { name: "SPF", value: "v=spf1 include:_spf.example.com ~all", status: Math.random() > 0.1 ? "pass" : "warn" },
            { name: "DKIM", value: "v=DKIM1; k=rsa; p=MIGfMA0G...", status: Math.random() > 0.2 ? "pass" : "warn" },
            { name: "DMARC", value: "v=DMARC1; p=quarantine; rua=mailto:dmarc@example.com", status: Math.random() > 0.15 ? "pass" : "risk" },
          ],
        };
      }}
      renderResult={(result) => {
        const data = result as { records: { name: string; value: string; status: "pass" | "warn" | "risk" }[] };
        const passed = data.records.filter((r) => r.status === "pass").length;
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">记录总数</div><div className="text-2xl font-semibold">{data.records.length}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">已配置</div><div className="text-2xl font-semibold text-green-700">{passed}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">待完善</div><div className="text-2xl font-semibold text-amber-700">{data.records.length - passed}</div></CardContent></Card>
            </div>
            <Card>
              <CardHeader>
                <CardTitle>邮件安全记录</CardTitle>
                <CardDescription>SPF / DKIM / DMARC 检查结果</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>记录</TableHead>
                      <TableHead>值</TableHead>
                      <TableHead>状态</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.records.map((r) => (
                      <TableRow key={r.name}>
                        <TableCell>{r.name}</TableCell>
                        <TableCell className="whitespace-normal max-w-xs break-all">{r.value}</TableCell>
                        <TableCell>{statusBadge(r.status)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}