import type { Metadata } from "next";
import { createMetadata } from "@/lib/seo";

export const metadata: Metadata = createMetadata({
  title: "网站监控服务 - 7×24 小时可用性监控",
  description:
    "IPcesu 提供 7×24 小时网站监控服务，实时监控网站可用性、响应时间、SSL 证书、HTTP 状态码，支持多渠道告警。",
  keywords:
    "网站监控, 可用性监控, SSL 监控, HTTP 监控, Ping 监控, TCP 监控, 告警通知, 响应时间监控",
  path: "/monitor",
});

export default function MonitorLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
