"use client";

import Link from "next/link";
import { Activity, ArrowRight, BarChart3, Bell, Globe, Shield, Zap } from "lucide-react";
import { buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";

const features = [
  {
    icon: Globe,
    title: "HTTP 监控",
    description: "监控网站状态码、响应时间和内容变化，异常即时告警。",
  },
  {
    icon: Activity,
    title: "Ping 监控",
    description: "检测服务器网络连通性与延迟，覆盖全球多个节点。",
  },
  {
    icon: Zap,
    title: "TCP 端口监控",
    description: "监控关键端口开放状态，服务异常第一时间发现。",
  },
  {
    icon: Shield,
    title: "SSL 证书监控",
    description: "自动检测 SSL 证书到期时间，提前提醒续期。",
  },
  {
    icon: Bell,
    title: "多渠道告警",
    description: "支持邮件、微信、钉钉、Webhook 等多种告警方式。",
  },
  {
    icon: BarChart3,
    title: "可视化报表",
    description: "查看可用率趋势、响应时间分布与历史告警记录。",
  },
];

const stats = [
  { label: "全球监控节点", value: "30+" },
  { label: "最小监控频率", value: "1 分钟" },
  { label: "告警渠道", value: "5+" },
  { label: "SLA 保障", value: "99.9%" },
];

export default function MonitorLandingPage() {
  return (
    <main className="bg-background min-h-screen">
      {/* Hero */}
      <section className="bg-slate-900 text-white py-16">
        <div className="container mx-auto px-4">
          <nav className="flex items-center gap-2 text-sm text-slate-300 mb-6">
            <Link href="/" className="hover:text-white">
              首页
            </Link>
            <span>/</span>
            <span className="text-white">监控服务</span>
          </nav>
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10">
              <Activity className="h-5 w-5" />
            </div>
            <span className="text-sm text-slate-300">监控服务</span>
          </div>
          <h1 className="text-3xl md:text-5xl font-bold mb-5">
            7×24 小时网站可用性监控
          </h1>
          <p className="text-slate-300 max-w-2xl text-lg mb-8">
            实时监控网站可用性、响应时间、SSL 证书、HTTP 状态码，异常时通过邮件、微信、钉钉多渠道告警。
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link
              href="/monitor/dashboard"
              className={cn(
                buttonVariants(),
                "bg-white text-slate-900 hover:bg-white/90 h-11 px-6"
              )}
            >
              进入监控控制台
              <ArrowRight className="h-4 w-4 ml-2" />
            </Link>
            <Link
              href="/user/vip"
              className={cn(
                buttonVariants({ variant: "outline" }),
                "border-white/30 text-white hover:bg-white/10 h-11 px-6"
              )}
            >
              查看 VIP 套餐
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 border-b border-border/50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {stats.map((s) => (
              <Card key={s.label} className="border-border bg-card shadow-sm text-center">
                <CardContent className="p-6">
                  <div className="text-2xl md:text-3xl font-bold text-foreground mb-1">{s.value}</div>
                  <div className="text-sm text-muted-foreground">{s.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-3">全方位监控能力</h2>
            <p className="text-muted-foreground">覆盖网站、服务器、证书、端口等多种监控场景，助你第一时间发现异常。</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f) => (
              <Card key={f.title} className="border-border bg-card shadow-sm">
                <CardHeader>
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 mb-3">
                    <f.icon className="h-5 w-5 text-primary" />
                  </div>
                  <CardTitle className="text-base text-foreground">{f.title}</CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-sm text-muted-foreground">{f.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="rounded-2xl bg-slate-900 text-white p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold mb-2">立即开始监控你的网站</h2>
              <p className="text-slate-300">免费版支持 5 个监控任务，1 分钟级频率，快速上手。</p>
            </div>
            <Link
              href="/monitor/dashboard"
              className={cn(
                buttonVariants(),
                "bg-white text-slate-900 hover:bg-white/90 h-11 px-6 shrink-0"
              )}
            >
              免费使用
              <ArrowRight className="h-4 w-4 ml-2" />
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}
