"use client";

import Link from "next/link";
import { Activity } from "lucide-react";
import { MonitorDashboard } from "@/components/monitor/monitor-dashboard";

export default function MonitorDashboardPage() {
  return (
    <main className="bg-background min-h-screen">
      {/* Hero */}
      <section className="bg-slate-900 text-white py-12">
        <div className="container mx-auto px-4">
          <nav className="flex items-center gap-2 text-sm text-slate-300 mb-6">
            <Link href="/" className="hover:text-white">
              首页
            </Link>
            <span>/</span>
            <Link href="/monitor" className="hover:text-white">
              监控服务
            </Link>
            <span>/</span>
            <span className="text-white">监控控制台</span>
          </nav>
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10">
              <Activity className="h-5 w-5" />
            </div>
            <span className="text-sm text-slate-300">监控控制台</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-3">
            管理你的监控任务
          </h1>
          <p className="text-slate-300 max-w-2xl">
            添加、暂停、删除监控任务，实时查看可用性与响应时间。
          </p>
        </div>
      </section>

      <MonitorDashboard />
    </main>
  );
}
