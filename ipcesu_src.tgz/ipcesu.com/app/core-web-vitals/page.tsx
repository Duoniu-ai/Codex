"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Gauge } from "lucide-react";

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "良好", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "待改进", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "较差", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="Core Web Vitals"
      description="检测网页核心性能指标"
      icon={Gauge}
      tips={[
        "输入目标 URL 即可模拟检测 LCP、INP、CLS 等指标。",
        "LCP 建议控制在 2.5 秒以内。",
        "CLS 越低越好，建议小于 0.1。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      onRun={async () => {
        await new Promise((r) => setTimeout(r, 900 + Math.floor(Math.random() * 300)));
        const lcp = parseFloat((1.2 + Math.random() * 3).toFixed(2));
        const inp = Math.floor(60 + Math.random() * 400);
        const cls = parseFloat((Math.random() * 0.35).toFixed(3));
        const lcpStatus: "pass" | "warn" | "risk" = lcp <= 2.5 ? "pass" : lcp <= 4 ? "warn" : "risk";
        const inpStatus: "pass" | "warn" | "risk" = inp <= 200 ? "pass" : inp <= 500 ? "warn" : "risk";
        const clsStatus: "pass" | "warn" | "risk" = cls <= 0.1 ? "pass" : cls <= 0.25 ? "warn" : "risk";
        return { lcp, inp, cls, lcpStatus, inpStatus, clsStatus };
      }}
      renderResult={(result) => {
        const data = result as { lcp: number; inp: number; cls: number; lcpStatus: "pass" | "warn" | "risk"; inpStatus: "pass" | "warn" | "risk"; clsStatus: "pass" | "warn" | "risk" };
        const metrics = [
          { name: "LCP（最大内容绘制）", value: `${data.lcp}s`, status: data.lcpStatus, threshold: "≤ 2.5s" },
          { name: "INP（交互到绘制延迟）", value: `${data.inp}ms`, status: data.inpStatus, threshold: "≤ 200ms" },
          { name: "CLS（累积布局偏移）", value: `${data.cls}`, status: data.clsStatus, threshold: "≤ 0.1" },
        ];
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {metrics.map((m) => (
                <Card key={m.name}>
                  <CardContent className="pt-6">
                    <div className="text-sm text-muted-foreground">{m.name}</div>
                    <div className="flex items-center justify-between mt-1">
                      <span className="text-2xl font-semibold">{m.value}</span>
                      {statusBadge(m.status)}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">目标：{m.threshold}</div>
                  </CardContent>
                </Card>
              ))}
            </div>
            <Card>
              <CardHeader>
                <CardTitle>指标详情</CardTitle>
                <CardDescription>Core Web Vitals 评级</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>指标</TableHead>
                      <TableHead>实测值</TableHead>
                      <TableHead>目标值</TableHead>
                      <TableHead>评级</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {metrics.map((m) => (
                      <TableRow key={m.name}>
                        <TableCell>{m.name}</TableCell>
                        <TableCell>{m.value}</TableCell>
                        <TableCell>{m.threshold}</TableCell>
                        <TableCell>{statusBadge(m.status)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}