import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "Core Web Vitals",
  "核心网页指标检测",
  "seo",
  "/core-web-vitals",
);

export default function CoreWebVitalsLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
