"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Search } from "lucide-react";

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "通过", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "提示", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "风险", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="SEO 检测"
      description="SEO 基础配置检测"
      icon={Search}
      tips={[
        "输入目标 URL 即可检测基础 SEO 配置。",
        "覆盖标题、描述、视口、规范化等关键标签。",
        "演示结果随机生成，正式使用请接入真实爬虫数据。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      onRun={async () => {
        await new Promise((r) => setTimeout(r, 600 + Math.floor(Math.random() * 500)));
        return {
          score: Math.floor(65 + Math.random() * 31),
          checks: [
            { name: "Title 标签", status: Math.random() > 0.1 ? "pass" : "warn", detail: "页面包含 title 标签" },
            { name: "Meta Description", status: Math.random() > 0.2 ? "pass" : "warn", detail: "描述标签存在" },
            { name: "Viewport", status: Math.random() > 0.1 ? "pass" : "risk", detail: "移动端 viewport 已设置" },
            { name: "Canonical", status: Math.random() > 0.2 ? "pass" : "warn", detail: "已设置 rel=canonical" },
            { name: "Robots Meta", status: Math.random() > 0.1 ? "pass" : "risk", detail: "未阻止搜索引擎抓取" },
            { name: "Html Lang", status: Math.random() > 0.1 ? "pass" : "warn", detail: "html 标签已声明语言" },
          ],
        };
      }}
      renderResult={(result) => {
        const data = result as {
          score: number;
          checks: { name: string; status: "pass" | "warn" | "risk"; detail: string }[];
        };
        return (
          <div className="space-y-4">
            <Card className="border-l-4 border-l-foreground">
              <CardContent className="pt-6">
                <div className="text-sm text-muted-foreground">基础 SEO 评分</div>
                <div className="text-3xl font-bold">{data.score}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>配置检查</CardTitle>
                <CardDescription>页面级 SEO 标签检测结果</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>检查项</TableHead>
                      <TableHead>状态</TableHead>
                      <TableHead>说明</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.checks.map((c) => (
                      <TableRow key={c.name}>
                        <TableCell>{c.name}</TableCell>
                        <TableCell>{statusBadge(c.status)}</TableCell>
                        <TableCell className="whitespace-normal">{c.detail}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}