"use client";

import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import { Globe, Server, Gauge, Percent, Activity, Clock, Signal } from "lucide-react";

interface PingIpv6Result {
  target: string;
  resolvedIp: string;
  status: "success" | "timeout" | "error";
  avgLatency: number;
  minLatency: number;
  maxLatency: number;
  packetLoss: number;
  ttl: number;
  node: string;
}

export default function PingIpv6Page() {
  return (
    <Suspense fallback={<PingIpv6PageSkeleton />}>
      <PingIpv6PageForm />
    </Suspense>
  );
}

function PingIpv6PageSkeleton() {
  return (
    <ToolPageLayout
      title="Ping IPv6"
      description="IPv6 网络延迟检测"
      icon={Globe}
      tips={[
        "输入支持 IPv6 的域名或 IPv6 地址进行延迟检测。",
        "结果包含解析 IPv6、平均/最小/最大延迟及 TTL。",
        "请确认本地网络环境支持 IPv6 协议栈。",
        "不同地区的 IPv6 路由可能存在差异。",
      ]}
    >
      <div className="space-y-3">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
      </div>
    </ToolPageLayout>
  );
}

function PingIpv6PageForm() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get("q") || "";

  const [target, setTarget] = useState(initialQuery);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<PingIpv6Result | null>(null);
  const [error, setError] = useState("");

  const handleTest = async () => {
    if (!target.trim()) {
      setError("请输入目标地址");
      return;
    }

    setLoading(true);
    setError("");
    setResult(null);

    try {
      await new Promise((r) => setTimeout(r, 700 + Math.random() * 600));
      const isSuccess = Math.random() > 0.2;
      const baseLatency = isSuccess ? 20 + Math.random() * 60 : 0;
      const data: PingIpv6Result = {
        target: target.trim(),
        resolvedIp: `2400:da00:${Math.floor(Math.random() * 9999).toString(16)}::${Math.floor(Math.random() * 9999).toString(16)}`,
        status: isSuccess ? "success" : "timeout",
        avgLatency: baseLatency,
        minLatency: isSuccess ? baseLatency * 0.7 : 0,
        maxLatency: isSuccess ? baseLatency * 1.3 : 0,
        packetLoss: isSuccess ? Math.random() * 5 : 100,
        ttl: isSuccess ? 55 + Math.floor(Math.random() * 10) : 0,
        node: "模拟节点-华东 IPv6",
      };
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "测试失败");
    } finally {
      setLoading(false);
    }
  };

  const statusConfig = {
    success: { label: "正常", color: "bg-green-500/15 text-green-600" },
    timeout: { label: "超时", color: "bg-red-500/15 text-red-600" },
    error: { label: "错误", color: "bg-amber-500/15 text-amber-600" },
  };

  return (
    <ToolPageLayout
      title="Ping IPv6"
      description="IPv6 网络延迟检测"
      icon={Globe}
      tips={[
        "输入支持 IPv6 的域名或 IPv6 地址进行延迟检测。",
        "结果包含解析 IPv6、平均/最小/最大延迟及 TTL。",
        "请确认本地网络环境支持 IPv6 协议栈。",
        "不同地区的 IPv6 路由可能存在差异。",
      ]}
    >
      <Card className="border-border/40 bg-card shadow-sm">
        <CardContent className="p-5 space-y-5">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex-1 space-y-2">
              <label className="text-sm font-medium text-foreground">目标地址（IPv6）</label>
              <Input
                value={target}
                onChange={(e) => setTarget(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleTest()}
                placeholder="例如：ipv6.baidu.com 或 2400:da00::1"
                className="bg-secondary/50 border-border/50"
              />
            </div>
            <div className="flex items-end">
              <Button
                onClick={handleTest}
                disabled={loading}
                className="bg-foreground hover:bg-foreground/90 text-background"
              >
                {loading ? "测试中..." : "开始测试"}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {error && (
        <div className="p-4 rounded-lg bg-destructive/10 text-destructive text-sm">
          {error}
        </div>
      )}

      {loading && (
        <Card className="border-border/40 bg-card shadow-sm">
          <CardContent className="p-5 space-y-3">
            <Skeleton className="h-12 w-full" />
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
            </div>
          </CardContent>
        </Card>
      )}

      {result && !loading && (
        <div className="space-y-4 animate-fade-in-up">
          <div className="flex flex-wrap items-center gap-3">
            <Badge variant="outline" className={statusConfig[result.status].color}>
              {statusConfig[result.status].label}
            </Badge>
            <span className="text-sm text-muted-foreground flex items-center gap-1">
              <Signal className="h-3.5 w-3.5" />
              测试节点：{result.node}
            </span>
          </div>

          <Card className="border-0 bg-gradient-to-br from-slate-900 to-slate-800 text-white">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-3 text-white/70 text-sm">
                <Server className="h-4 w-4" />
                解析 IPv6
              </div>
              <div className="text-lg font-medium font-mono break-all">
                {result.resolvedIp}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Gauge className="h-4 w-4 text-foreground" />
                  平均延迟
                </div>
                <div className="font-medium text-foreground">
                  {result.status === "success" ? `${result.avgLatency.toFixed(2)} ms` : "--"}
                </div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Activity className="h-4 w-4 text-foreground" />
                  最小延迟
                </div>
                <div className="font-medium text-foreground">
                  {result.status === "success" ? `${result.minLatency.toFixed(2)} ms` : "--"}
                </div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Clock className="h-4 w-4 text-foreground" />
                  最大延迟
                </div>
                <div className="font-medium text-foreground">
                  {result.status === "success" ? `${result.maxLatency.toFixed(2)} ms` : "--"}
                </div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Percent className="h-4 w-4 text-foreground" />
                  丢包率
                </div>
                <div className="font-medium text-foreground">
                  {result.packetLoss.toFixed(0)} %
                </div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Server className="h-4 w-4 text-foreground" />
                  TTL
                </div>
                <div className="font-medium text-foreground">{result.ttl || "--"}</div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Globe className="h-4 w-4 text-foreground" />
                  检测目标
                </div>
                <div className="font-medium text-foreground break-all">{result.target}</div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </ToolPageLayout>
  );
}
