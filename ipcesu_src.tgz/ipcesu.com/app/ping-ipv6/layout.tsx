import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "Ping IPv6",
  "IPv6 网络延迟检测",
  "network",
  "/ping-ipv6",
);

export default function PingIpv6Layout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
