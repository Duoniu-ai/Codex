"use client";

import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import { Clock, Gauge, Zap, Globe, Server, ArrowRight } from "lucide-react";

interface SpeedResult {
  url: string;
  finalUrl: string;
  statusCode: number;
  statusText: string;
  contentType: string | null;
  contentLength: number | null;
  size: number;
  redirectCount: number;
  totalTime: number;
  dnsTime: number;
  connectTime: number;
  ttfb: number;
  downloadTime: number;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export default function SpeedPage() {
  return (
    <Suspense fallback={<SpeedPageSkeleton />}>
      <SpeedPageForm />
    </Suspense>
  );
}

function SpeedPageSkeleton() {
  return (
    <ToolPageLayout
      title="网站测速"
      description="测试网页加载性能，分析 DNS、连接、首字节和下载耗时"
      icon={Gauge}
      tips={[
        "输入 URL 或域名即可测试网页加载速度",
        "支持自动跟随 301/302 跳转",
        "测量 DNS 解析、TCP 连接、TLS 握手、首字节和下载时间",
        "显示页面大小、状态码和最终响应地址",
      ]}
    >
      <div className="space-y-3">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
      </div>
    </ToolPageLayout>
  );
}

function SpeedPageForm() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get("q") || "";

  const [target, setTarget] = useState(initialQuery);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<SpeedResult | null>(null);
  const [error, setError] = useState("");

  const handleTest = async () => {
    if (!target.trim()) return;

    setLoading(true);
    setError("");
    setResult(null);

    try {
      const res = await fetch("/api/speed", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ target: target.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "测速失败");
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "测速失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ToolPageLayout
      title="网站测速"
      description="测试网页加载性能，分析 DNS、连接、首字节和下载耗时"
      icon={Gauge}
      tips={[
        "输入 URL 或域名即可测试网页加载速度",
        "支持自动跟随 301/302 跳转",
        "测量 DNS 解析、TCP 连接、TLS 握手、首字节和下载时间",
        "显示页面大小、状态码和最终响应地址",
      ]}
    >
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <Input
          value={target}
          onChange={(e) => setTarget(e.target.value)}
          placeholder="例如：baidu.com 或 https://example.com"
          className="flex-1 bg-secondary/50 border-border/50"
        />
        <Button
          onClick={handleTest}
          disabled={loading}
          className="bg-foreground hover:bg-foreground/90 text-background"
        >
          {loading ? "测速中..." : "开始测速"}
        </Button>
      </div>

      {error && (
        <div className="p-4 rounded-lg bg-destructive/10 text-destructive text-sm mb-6">
          {error}
        </div>
      )}

      {loading && (
        <div className="space-y-3">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
        </div>
      )}

      {result && !loading && (
        <div className="space-y-4 animate-fade-in-up">
          <div className="flex flex-wrap items-center gap-3 mb-4">
            <Badge
              variant={result.statusCode < 400 ? "default" : "destructive"}
              className={
                result.statusCode < 400
                  ? "bg-green-500/15 text-green-600 hover:bg-green-500/20 border-0"
                  : ""
              }
            >
              {result.statusCode} {result.statusText}
            </Badge>
            <span className="text-sm text-muted-foreground flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" />
              总耗时 {result.totalTime} ms
            </span>
            {result.redirectCount > 0 && (
              <span className="text-sm text-muted-foreground flex items-center gap-1">
                <ArrowRight className="h-3.5 w-3.5" />
                跳转 {result.redirectCount} 次
              </span>
            )}
          </div>

          <Card className="border-0 bg-foreground text-background">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-3 text-background/70 text-sm">
                <Globe className="h-4 w-4" />
                最终请求地址
              </div>
              <div className="text-lg font-medium font-mono break-all">
                {result.finalUrl}
              </div>
              <div className="text-sm text-background/60 mt-2">
                原始地址：{result.url}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Server className="h-4 w-4 text-foreground" />
                  页面大小
                </div>
                <div className="font-medium text-foreground">
                  {formatBytes(result.size)}
                </div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Clock className="h-4 w-4 text-foreground" />
                  DNS 解析
                </div>
                <div className="font-medium text-foreground">
                  {result.dnsTime} ms
                </div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Zap className="h-4 w-4 text-foreground" />
                  建立连接
                </div>
                <div className="font-medium text-foreground">
                  {result.connectTime} ms
                </div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Gauge className="h-4 w-4 text-foreground" />
                  首字节时间
                </div>
                <div className="font-medium text-foreground">
                  {result.ttfb} ms
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Clock className="h-4 w-4 text-foreground" />
                  下载耗时
                </div>
                <div className="font-medium text-foreground">
                  {result.downloadTime} ms
                </div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Server className="h-4 w-4 text-foreground" />
                  Content-Type
                </div>
                <div className="font-medium text-foreground break-all">
                  {result.contentType || "--"}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </ToolPageLayout>
  );
}