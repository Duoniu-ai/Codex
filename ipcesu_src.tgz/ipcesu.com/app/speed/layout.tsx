import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "网站测速",
  "网页性能分析",
  "speed",
  "/speed",
);

export default function SpeedLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
