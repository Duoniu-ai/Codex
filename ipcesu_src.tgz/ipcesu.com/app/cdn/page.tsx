"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Server, Globe, MapPin, Clock, Link } from "lucide-react";

interface CdnResult {
  domain: string;
  vendor: string;
  cname: string;
  edgeCount: number;
  responseTime: number;
  headers: Record<string, string>;
  edgeNodes: string[];
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="CDN 检测"
      description="CDN 厂商识别"
      icon={Server}
      tips={[
        "输入域名即可识别是否使用 CDN 及厂商信息。",
        "通过 CNAME 链路和响应头判断 CDN 服务商。",
        "可查看边缘节点分布与典型响应头。",
        "检测结果为模拟数据，真实厂商请以实际解析为准。",
      ]}
      inputs={[
        {
          id: "domain",
          label: "域名",
          type: "text",
          placeholder: "例如：baidu.com",
        },
      ]}
      onRun={async (values) => {
        await new Promise((r) => setTimeout(r, 600 + Math.random() * 600));
        const domain = values.domain.trim().replace(/^https?:\/\//i, "");
        const vendors = [
          { name: "Cloudflare", cname: "cdn.cloudflare.net" },
          { name: "阿里云 CDN", cname: "alikunlun.com" },
          { name: "腾讯云 CDN", cname: "qcloudcdn.com" },
          { name: "百度云加速", cname: "yunjiasu-cdn.net" },
          { name: "AWS CloudFront", cname: "cloudfront.net" },
        ];
        const vendor = vendors[Math.floor(Math.random() * vendors.length)];
        const edgeCount = 3 + Math.floor(Math.random() * 6);
        const edgeNodes = Array.from({ length: edgeCount }, () => {
          const cities = ["北京", "上海", "广州", "深圳", "杭州", "成都", "武汉", "西安"];
          return cities[Math.floor(Math.random() * cities.length)];
        });
        const result: CdnResult = {
          domain,
          vendor: vendor.name,
          cname: `${domain}.${vendor.cname}`,
          edgeCount,
          responseTime: 20 + Math.random() * 100,
          headers: {
            "Cache-Control": "max-age=3600",
            "X-Cache": "HIT",
            "CF-RAY": `8a1b2c3d4e5f${Math.floor(Math.random() * 1000)}-NRT`,
            "Server": "cloudflare",
          },
          edgeNodes,
        };
        return result;
      }}
      renderResult={(result) => {
        const data = result as CdnResult;
        return (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-3">
              <Badge
                variant="secondary"
                className="bg-foreground text-background hover:bg-foreground/90 border-0"
              >
                {data.vendor}
              </Badge>
              <span className="text-sm text-muted-foreground flex items-center gap-1">
                <Clock className="h-3.5 w-3.5" />
                边缘响应时间：{data.responseTime.toFixed(0)} ms
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                    <Globe className="h-4 w-4 text-foreground" />
                    检测域名
                  </div>
                  <div className="font-medium font-mono text-foreground break-all">
                    {data.domain}
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                    <Server className="h-4 w-4 text-foreground" />
                    CDN 厂商
                  </div>
                  <div className="font-medium text-foreground break-all">
                    {data.vendor}
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                    <Link className="h-4 w-4 text-foreground" />
                    CNAME
                  </div>
                  <div className="font-medium font-mono text-foreground break-all">
                    {data.cname}
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                    <MapPin className="h-4 w-4 text-foreground" />
                    边缘节点数
                  </div>
                  <div className="font-medium text-foreground">{data.edgeCount}</div>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-3 text-muted-foreground text-sm">
                    <MapPin className="h-4 w-4 text-foreground" />
                    边缘节点分布
                  </div>
                  <div className="border rounded-lg overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-16">序号</TableHead>
                          <TableHead>城市</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {data.edgeNodes.map((node, index) => (
                          <TableRow key={index}>
                            <TableCell className="font-mono">{index + 1}</TableCell>
                            <TableCell className="text-foreground">{node}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-3 text-muted-foreground text-sm">
                    <Server className="h-4 w-4 text-foreground" />
                    响应头
                  </div>
                  <div className="border rounded-lg overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-1/3">名称</TableHead>
                          <TableHead>值</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {Object.entries(data.headers).map(([key, value]) => (
                          <TableRow key={key}>
                            <TableCell className="font-medium font-mono text-xs break-all">
                              {key}
                            </TableCell>
                            <TableCell className="font-mono text-xs break-all text-foreground">
                              {value}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        );
      }}
    />
  );
}