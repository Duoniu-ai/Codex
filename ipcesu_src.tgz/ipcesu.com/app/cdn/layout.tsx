import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "CDN 检测",
  "CDN 厂商识别",
  "domain",
  "/cdn",
);

export default function CdnLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
