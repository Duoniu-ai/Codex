"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AppWindow } from "lucide-react";

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "已设置", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "建议", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "缺失", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="Open Graph 检测"
      description="检测网页 Open Graph 社交分享标签"
      icon={AppWindow}
      tips={[
        "输入目标 URL 即可解析 Open Graph 标签。",
        "og:title、og:image、og:description 是必备项。",
        "完善的 OG 标签可提升社交分享效果。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      onRun={async () => {
        await new Promise((r) => setTimeout(r, 700 + Math.floor(Math.random() * 400)));
        return {
          tags: [
            { name: "og:title", value: "示例页面标题", status: Math.random() > 0.1 ? "pass" : "risk" },
            { name: "og:description", value: "页面描述示例", status: Math.random() > 0.2 ? "pass" : "warn" },
            { name: "og:image", value: "https://example.com/og.png", status: Math.random() > 0.3 ? "pass" : "risk" },
            { name: "og:type", value: "website", status: Math.random() > 0.2 ? "pass" : "warn" },
            { name: "twitter:card", value: "summary_large_image", status: Math.random() > 0.3 ? "pass" : "warn" },
          ],
        };
      }}
      renderResult={(result) => {
        const data = result as { tags: { name: string; value: string; status: "pass" | "warn" | "risk" }[] };
        const present = data.tags.filter((t) => t.status === "pass").length;
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">已设置</div><div className="text-2xl font-semibold text-green-700">{present}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">缺失/建议</div><div className="text-2xl font-semibold text-amber-700">{data.tags.length - present}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">标签总数</div><div className="text-2xl font-semibold">{data.tags.length}</div></CardContent></Card>
            </div>
            <Card>
              <CardHeader>
                <CardTitle>Open Graph 标签</CardTitle>
                <CardDescription>社交分享元信息检测结果</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>标签</TableHead>
                      <TableHead>内容</TableHead>
                      <TableHead>状态</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.tags.map((t) => (
                      <TableRow key={t.name}>
                        <TableCell>{t.name}</TableCell>
                        <TableCell className="whitespace-normal max-w-xs break-all">{t.value || "未设置"}</TableCell>
                        <TableCell>{statusBadge(t.status)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}