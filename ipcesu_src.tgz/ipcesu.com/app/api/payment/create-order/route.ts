import { NextRequest, NextResponse } from "next/server";
import { getTokenFromRequest, verifyToken } from "@/lib/auth";
import { createCreditsOrder, createVipOrder, vipPlans, creditPacks } from "@/lib/payment";

export async function POST(req: NextRequest) {
  try {
    const token = getTokenFromRequest(req);
    if (!token) {
      return NextResponse.json({ error: "请先登录" }, { status: 401 });
    }

    const payload = verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: "登录已过期" }, { status: 401 });
    }

    const body = await req.json();
    const { type, planId, packId } = body;

    if (!type || (type !== "vip" && type !== "credits")) {
      return NextResponse.json({ error: "订单类型错误" }, { status: 400 });
    }

    let order;
    if (type === "vip") {
      if (!planId || !vipPlans.some((p) => p.id === planId)) {
        return NextResponse.json({ error: "套餐不存在" }, { status: 400 });
      }
      order = createVipOrder(payload.userId, planId);
    } else {
      if (!packId || !creditPacks.some((p) => p.id === packId)) {
        return NextResponse.json({ error: "充值包不存在" }, { status: 400 });
      }
      order = createCreditsOrder(payload.userId, packId);
    }

    return NextResponse.json({ order });
  } catch (err) {
    const message = err instanceof Error ? err.message : "创建订单失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
