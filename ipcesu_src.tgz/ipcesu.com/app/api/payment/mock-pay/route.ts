import { NextRequest, NextResponse } from "next/server";
import { getTokenFromRequest, verifyToken } from "@/lib/auth";
import { getOrderById, processOrderPayment } from "@/lib/payment";

export async function POST(req: NextRequest) {
  try {
    const token = getTokenFromRequest(req);
    if (!token) {
      return NextResponse.json({ error: "请先登录" }, { status: 401 });
    }

    const payload = verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: "登录已过期" }, { status: 401 });
    }

    const body = await req.json();
    const { orderId } = body;

    if (!orderId) {
      return NextResponse.json({ error: "订单 ID 不能为空" }, { status: 400 });
    }

    const order = getOrderById(orderId);
    if (!order || order.userId !== payload.userId) {
      return NextResponse.json({ error: "订单不存在" }, { status: 404 });
    }

    const paidOrder = processOrderPayment(orderId);
    return NextResponse.json({ success: true, order: paidOrder });
  } catch (err) {
    const message = err instanceof Error ? err.message : "支付处理失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
