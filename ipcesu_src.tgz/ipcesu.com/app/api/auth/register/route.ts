import { NextRequest, NextResponse } from "next/server";
import {
  createUser,
  createToken,
  toSafeUser,
  setAuthCookie,
} from "@/lib/auth";

interface RegisterRequest {
  email: string;
  password: string;
}

export async function POST(req: NextRequest) {
  try {
    const body: RegisterRequest = await req.json();
    const { email, password } = body;

    if (
      !email ||
      !password ||
      typeof email !== "string" ||
      typeof password !== "string"
    ) {
      return NextResponse.json(
        { error: "请填写邮箱和密码" },
        { status: 400 }
      );
    }

    if (!email.includes("@")) {
      return NextResponse.json(
        { error: "请输入有效的邮箱地址" },
        { status: 400 }
      );
    }

    if (password.length < 6) {
      return NextResponse.json(
        { error: "密码长度至少为 6 位" },
        { status: 400 }
      );
    }

    const user = await createUser({ email, password });
    const token = createToken(user);

    const response = NextResponse.json({
      user: toSafeUser(user),
    });
    setAuthCookie(response, token);

    return response;
  } catch (err) {
    const message = err instanceof Error ? err.message : "注册失败";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
