import { NextRequest, NextResponse } from "next/server";
import { lookup } from "dns/promises";
import { checkAndDeductCredits } from "@/lib/auth";
import { getEnhancedIpInfo } from "@/lib/ip-data";

interface IpQueryRequest {
  target: string;
}

function isValidIp(ip: string): boolean {
  const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
  const ipv6Regex = /^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  if (ipv4Regex.test(ip)) {
    return ip.split(".").every((octet) => parseInt(octet, 10) <= 255);
  }
  return ipv6Regex.test(ip);
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: IpQueryRequest = await req.json();
    const { target } = body;

    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入有效的 IP 地址或域名" },
        { status: 400 }
      );
    }

    const trimmedTarget = target.trim();
    let ip = trimmedTarget;

    if (!isValidIp(trimmedTarget)) {
      try {
        const addresses = await lookup(trimmedTarget);
        ip = addresses.address;
      } catch {
        return NextResponse.json(
          { error: "无法解析该域名，请检查输入" },
          { status: 400 }
        );
      }
    }

    const info = getEnhancedIpInfo(ip);
    return NextResponse.json({
      ...info,
      queriedTarget: trimmedTarget,
    });
  } catch {
    return NextResponse.json({ error: "查询失败，请稍后重试" }, { status: 500 });
  }
}
