import { NextRequest, NextResponse } from "next/server";
import { performance } from "perf_hooks";
import { checkAndDeductCredits } from "@/lib/auth";

interface HttpRequest {
  target: string;
}

interface RedirectHop {
  url: string;
  status: number;
  statusText: string;
  location?: string;
}

function normalizeUrl(target: string): string {
  const trimmed = target.trim();
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  return `https://${trimmed}`;
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: HttpRequest = await req.json();
    const { target } = body;

    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入有效的 URL 或域名" },
        { status: 400 }
      );
    }

    const urlStr = normalizeUrl(target);
    try {
      new URL(urlStr);
    } catch {
      return NextResponse.json({ error: "URL 格式不正确" }, { status: 400 });
    }

    const start = performance.now();
    const redirectChain: RedirectHop[] = [];
    let currentUrl = urlStr;
    let finalRes: Response | null = null;
    const maxRedirects = 5;

    for (let i = 0; i <= maxRedirects; i++) {
      const res = await fetch(currentUrl, {
        method: "GET",
        redirect: "manual",
        signal: AbortSignal.timeout(15000),
      });

      redirectChain.push({
        url: currentUrl,
        status: res.status,
        statusText: res.statusText,
        location: res.headers.get("location") || undefined,
      });

      if (
        res.status >= 300 &&
        res.status < 400 &&
        res.headers.get("location") &&
        i < maxRedirects
      ) {
        currentUrl = new URL(
          res.headers.get("location")!,
          currentUrl
        ).toString();
        continue;
      }

      finalRes = res;
      break;
    }

    if (!finalRes) {
      return NextResponse.json(
        { error: "重定向次数过多" },
        { status: 500 }
      );
    }

    const bodyText = await finalRes.text();
    const totalTime = performance.now() - start;
    const headers = Object.fromEntries(finalRes.headers.entries());

    return NextResponse.json({
      url: urlStr,
      finalUrl: currentUrl,
      statusCode: finalRes.status,
      statusText: finalRes.statusText,
      headers,
      redirectChain,
      redirectCount: redirectChain.length - 1,
      bodyPreview: bodyText.slice(0, 2000),
      contentType: headers["content-type"] || null,
      contentLength: headers["content-length"]
        ? parseInt(headers["content-length"], 10)
        : null,
      totalTime: Number(totalTime.toFixed(2)),
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "HTTP 检测失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
