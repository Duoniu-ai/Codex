import { NextRequest, NextResponse } from "next/server";
import { exec } from "child_process";
import { promisify } from "util";
import { checkAndDeductCredits } from "@/lib/auth";

const execAsync = promisify(exec);

interface WhoisRequest {
  domain: string;
}

function parseWhois(output: string) {
  const lines = output.split("\n");
  const info: Record<string, string> = {};

  for (const line of lines) {
    const match = line.match(/^([^:]+):\s*(.+)$/);
    if (match) {
      const key = match[1].trim().toLowerCase();
      const value = match[2].trim();
      if (!info[key]) {
        info[key] = value;
      } else if (Array.isArray(info[key])) {
        (info[key] as unknown as string[]).push(value);
      }
    }
  }

  return info;
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: WhoisRequest = await req.json();
    const { domain } = body;

    if (!domain || typeof domain !== "string") {
      return NextResponse.json(
        { error: "请输入有效的域名" },
        { status: 400 }
      );
    }

    const trimmedDomain = domain.trim().toLowerCase();

    try {
      const { stdout } = await execAsync(`whois ${trimmedDomain}`, {
        timeout: 15000,
      });
      const info = parseWhois(stdout);

      return NextResponse.json({
        domain: trimmedDomain,
        registrar: info.registrar || "--",
        creationDate: info.creationdate || info.created || "--",
        expirationDate:
          info.registryexpirydate || info.expirationdate || info.expires || "--",
        nameServers: info.nameserver
          ? Array.isArray(info.nameserver)
            ? info.nameserver
            : [info.nameserver]
          : [],
        status: info.domainstatus
          ? Array.isArray(info.domainstatus)
            ? info.domainstatus
            : [info.domainstatus]
          : [],
        raw: stdout.slice(0, 2000),
      });
    } catch {
      return NextResponse.json(
        { error: "Whois 查询失败，请检查域名或系统是否安装 whois" },
        { status: 500 }
      );
    }
  } catch {
    return NextResponse.json({ error: "查询失败" }, { status: 500 });
  }
}
