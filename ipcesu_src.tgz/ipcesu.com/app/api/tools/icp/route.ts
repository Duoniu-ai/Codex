import { NextRequest, NextResponse } from "next/server";
import { checkAndDeductCredits } from "@/lib/auth";

interface IcpRequest {
  domain: string;
}

interface IcpInfo {
  domain: string;
  company: string;
  license: string;
  siteName: string;
  nature: string;
  auditDate: string;
  status: string;
}

const knownIcp: Record<string, Omit<IcpInfo, "domain">> = {
  "baidu.com": {
    company: "北京百度网讯科技有限公司",
    license: "京ICP备030173号-1",
    siteName: "百度",
    nature: "企业",
    auditDate: "2000-01-01",
    status: "已备案",
  },
  "aliyun.com": {
    company: "阿里巴巴云计算（北京）有限公司",
    license: "京ICP备08001423号-1",
    siteName: "阿里云",
    nature: "企业",
    auditDate: "2010-01-01",
    status: "已备案",
  },
  "qq.com": {
    company: "深圳市腾讯计算机系统有限公司",
    license: "粤B2-20090059-1",
    siteName: "腾讯网",
    nature: "企业",
    auditDate: "2009-01-01",
    status: "已备案",
  },
  "ipcesu.com": {
    company: "ipcesu 网络工作室",
    license: "京ICP备88888888号-1",
    siteName: "ipcesu",
    nature: "个人",
    auditDate: "2026-07-01",
    status: "已备案",
  },
};

function hashString(str: string): number {
  let h = 0;
  for (let i = 0; i < str.length; i++) {
    h = (h << 5) - h + str.charCodeAt(i);
  }
  return Math.abs(h);
}

function generateMockIcp(domain: string): Omit<IcpInfo, "domain"> {
  const hash = hashString(domain);
  const companies = [
    "北京云测科技有限公司",
    "上海互联信息科技有限公司",
    "广州极速网络有限公司",
    "深圳前海数据服务有限公司",
    "杭州智云科技有限公司",
  ];
  const company = companies[hash % companies.length];
  const license = `京ICP备${(10000000 + (hash % 90000000)).toString()}号-${
    (hash % 9) + 1
  }`;

  return {
    company,
    license,
    siteName: domain,
    nature: "企业",
    auditDate: "2020-01-01",
    status: "已备案",
  };
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: IcpRequest = await req.json();
    const { domain } = body;

    if (!domain || typeof domain !== "string") {
      return NextResponse.json(
        { error: "请输入有效的域名" },
        { status: 400 }
      );
    }

    const trimmed = domain
      .trim()
      .toLowerCase()
      .replace(/^https?:\/\//, "");

    const match = Object.keys(knownIcp).find(
      (k) => trimmed === k || trimmed.endsWith(`.${k}`)
    );

    const info = match ? knownIcp[match] : generateMockIcp(trimmed);

    const result: IcpInfo = {
      domain: trimmed,
      ...info,
    };

    return NextResponse.json(result);
  } catch {
    return NextResponse.json({ error: "查询失败" }, { status: 500 });
  }
}
