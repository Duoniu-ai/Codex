import { NextRequest, NextResponse } from "next/server";
import { exec } from "child_process";
import { promisify } from "util";
import { lookup } from "dns/promises";
import { checkAndDeductCredits } from "@/lib/auth";

const execAsync = promisify(exec);

interface PingRequest {
  target: string;
  node?: string;
}

function parsePingOutput(output: string) {
  const lines = output.split("\n");
  let resolvedIp = "";
  let avgLatency = 0;
  let packetLoss = 0;

  for (const line of lines) {
    const ipMatch = line.match(/\((\d+\.\d+\.\d+\.\d+)\)/) ||
      line.match(/from\s+(\d+\.\d+\.\d+\.\d+)/);
    if (ipMatch) {
      resolvedIp = ipMatch[1];
    }

    const lossMatch = line.match(/(\d+(?:\.\d+)?)% packet loss/);
    if (lossMatch) {
      packetLoss = parseFloat(lossMatch[1]);
    }

    const avgMatch = line.match(/(?:rtt|round-trip)[^=]*=\s*[\d.\/]+\/(\d+\.\d+)\/[\d.\/]+\/[\d.]+/);
    if (avgMatch) {
      avgLatency = parseFloat(avgMatch[1]);
    }
  }

  return { resolvedIp, avgLatency, packetLoss };
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: PingRequest = await req.json();
    const { target, node = "default" } = body;

    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入有效的域名或 IP" },
        { status: 400 }
      );
    }

    const trimmedTarget = target.trim();
    let resolvedIp = trimmedTarget;

    const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
    if (!ipRegex.test(trimmedTarget)) {
      try {
        const addresses = await lookup(trimmedTarget);
        resolvedIp = addresses.address;
      } catch {
        return NextResponse.json(
          { error: "无法解析该域名" },
          { status: 400 }
        );
      }
    }

    try {
      const { stdout } = await execAsync(`ping -c 4 -W 2 ${resolvedIp}`);
      const result = parsePingOutput(stdout);

      return NextResponse.json({
        resolvedIp: result.resolvedIp || resolvedIp,
        avgLatency: result.avgLatency,
        packetLoss: result.packetLoss,
        status: result.packetLoss >= 100 ? "timeout" : "success",
        node,
      });
    } catch (execError) {
      const errorOutput = (execError as { stdout?: string }).stdout || "";
      const result = parsePingOutput(errorOutput);

      return NextResponse.json({
        resolvedIp: result.resolvedIp || resolvedIp,
        avgLatency: result.avgLatency || 0,
        packetLoss: result.packetLoss || 100,
        status: "timeout",
        node,
      });
    }
  } catch {
    return NextResponse.json({ error: "测试失败，请稍后重试" }, { status: 500 });
  }
}
