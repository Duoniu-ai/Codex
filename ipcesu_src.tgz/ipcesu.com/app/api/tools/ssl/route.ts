import { NextRequest, NextResponse } from "next/server";
import tls from "tls";
import { checkAndDeductCredits } from "@/lib/auth";

interface SslRequest {
  domain: string;
}

function getCertificateInfo(domain: string): Promise<{
  valid: boolean;
  issuer: string;
  validFrom: string;
  validTo: string;
  daysRemaining: number;
  subject: string;
  san: string[];
}> {
  return new Promise((resolve, reject) => {
    const socket = tls.connect(443, domain, { servername: domain }, () => {
      const cert = socket.getPeerCertificate(true);
      socket.end();

      if (!cert || Object.keys(cert).length === 0) {
        reject(new Error("无法获取证书信息"));
        return;
      }

      const now = new Date();
      const validTo = new Date(cert.valid_to);
      const daysRemaining = Math.ceil(
        (validTo.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
      );

      resolve({
        valid: daysRemaining > 0,
        issuer: String((Array.isArray(cert.issuer?.O) ? cert.issuer.O[0] : cert.issuer?.O) || cert.issuer?.CN || "Unknown"),
        validFrom: cert.valid_from,
        validTo: cert.valid_to,
        daysRemaining,
        subject: String(Array.isArray(cert.subject?.CN) ? cert.subject.CN[0] : cert.subject?.CN || domain),
        san: cert.subjectaltname
          ? String(cert.subjectaltname).split(", ").map((s: string) => s.replace("DNS:", ""))
          : [],
      });
    });

    socket.on("error", (err) => {
      reject(err);
    });

    socket.setTimeout(10000, () => {
      socket.destroy();
      reject(new Error("连接超时"));
    });
  });
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: SslRequest = await req.json();
    const { domain } = body;

    if (!domain || typeof domain !== "string") {
      return NextResponse.json(
        { error: "请输入有效的域名" },
        { status: 400 }
      );
    }

    const trimmedDomain = domain.trim().replace(/^https?:\/\//, "");
    const info = await getCertificateInfo(trimmedDomain);

    return NextResponse.json({
      domain: trimmedDomain,
      ...info,
    });
  } catch {
    return NextResponse.json(
      { error: "SSL 检测失败，请检查域名是否正确或是否支持 HTTPS" },
      { status: 500 }
    );
  }
}
