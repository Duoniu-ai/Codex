import { NextRequest, NextResponse } from "next/server";
import { Resolver } from "dns/promises";
import { checkAndDeductCredits } from "@/lib/auth";

interface DnsRequest {
  domain: string;
  type?: string;
}

const dnsServers = [
  { address: "223.5.5.5", name: "阿里云 DNS" },
  { address: "119.29.29.29", name: "腾讯 DNS" },
  { address: "114.114.114.114", name: "114 DNS" },
  { address: "8.8.8.8", name: "Google DNS" },
  { address: "1.1.1.1", name: "Cloudflare DNS" },
];

const validTypes = ["A", "AAAA", "CNAME", "MX", "NS", "TXT", "SOA"];

async function queryDnsServer(
  domain: string,
  type: string,
  server: { address: string; name: string }
) {
  const resolver = new Resolver();
  resolver.setServers([server.address]);

  const start = Date.now();
  try {
    const records = await resolver.resolve(domain, type as any);
    const responseTime = Date.now() - start;

    const formatted = records.map((record: any) => {
      if (typeof record === "string") return record;
      if (record.exchange) return `${record.exchange} (priority: ${record.priority})`;
      if (record.nsname) return record.nsname;
      if (record.mname) {
        return `${record.mname} / ${record.rname} (serial: ${record.serial})`;
      }
      return JSON.stringify(record);
    });

    return {
      server: server.address,
      serverName: server.name,
      records: formatted,
      responseTime,
    };
  } catch {
    return {
      server: server.address,
      serverName: server.name,
      records: [],
      responseTime: Date.now() - start,
    };
  }
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: DnsRequest = await req.json();
    const { domain, type = "A" } = body;

    if (!domain || typeof domain !== "string") {
      return NextResponse.json(
        { error: "请输入有效的域名" },
        { status: 400 }
      );
    }

    const upperType = type.toUpperCase();
    if (!validTypes.includes(upperType)) {
      return NextResponse.json(
        { error: "不支持的记录类型" },
        { status: 400 }
      );
    }

    const trimmedDomain = domain.trim();
    const results = await Promise.all(
      dnsServers.map((server) => queryDnsServer(trimmedDomain, upperType, server))
    );

    return NextResponse.json({
      domain: trimmedDomain,
      type: upperType,
      results,
    });
  } catch {
    return NextResponse.json({ error: "查询失败" }, { status: 500 });
  }
}
