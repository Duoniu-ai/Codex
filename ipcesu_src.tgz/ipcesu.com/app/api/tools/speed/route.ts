import { NextRequest, NextResponse } from "next/server";
import http from "http";
import https from "https";
import { performance } from "perf_hooks";
import { checkAndDeductCredits } from "@/lib/auth";

interface SpeedRequest {
  target: string;
}

interface Timings {
  dns: number;
  connect: number;
  secureConnect: number;
  ttfb: number;
}

function normalizeUrl(target: string): string {
  const trimmed = target.trim();
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  return `https://${trimmed}`;
}

function requestWithTiming(
  urlStr: string,
  maxRedirects = 5
): Promise<{
  finalUrl: string;
  statusCode: number;
  statusText: string;
  headers: http.IncomingHttpHeaders;
  size: number;
  redirectCount: number;
  timings: Timings;
  totalTime: number;
}> {
  return new Promise((resolve, reject) => {
    const start = performance.now();
    const timings: Timings = { dns: 0, connect: 0, secureConnect: 0, ttfb: 0 };
    let redirectCount = 0;

    const follow = (currentUrl: string) => {
      const parsed = new URL(currentUrl);
      const lib = parsed.protocol === "https:" ? https : http;

      const req = lib.get(currentUrl, (res) => {
        timings.ttfb = performance.now() - start;

        if (
          res.statusCode &&
          res.statusCode >= 300 &&
          res.statusCode < 400 &&
          res.headers.location &&
          redirectCount < maxRedirects
        ) {
          redirectCount++;
          const nextUrl = new URL(res.headers.location, currentUrl).toString();
          res.resume();
          follow(nextUrl);
          return;
        }

        const chunks: Buffer[] = [];
        res.on("data", (chunk) => chunks.push(chunk));
        res.on("end", () => {
          const body = Buffer.concat(chunks);
          resolve({
            finalUrl: currentUrl,
            statusCode: res.statusCode || 0,
            statusText: res.statusMessage || "",
            headers: res.headers,
            size: body.length,
            redirectCount,
            timings,
            totalTime: performance.now() - start,
          });
        });
      });

      req.on("socket", (socket) => {
        socket.on("lookup", () => {
          if (!timings.dns) timings.dns = performance.now() - start;
        });
        socket.on("connect", () => {
          if (!timings.connect) timings.connect = performance.now() - start;
        });
        socket.on("secureConnect", () => {
          if (!timings.secureConnect)
            timings.secureConnect = performance.now() - start;
        });
      });

      req.on("error", reject);
      req.setTimeout(15000, () => {
        req.destroy();
        reject(new Error("请求超时"));
      });
    };

    follow(urlStr);
  });
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: SpeedRequest = await req.json();
    const { target } = body;

    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入有效的 URL 或域名" },
        { status: 400 }
      );
    }

    const urlStr = normalizeUrl(target);
    try {
      new URL(urlStr);
    } catch {
      return NextResponse.json({ error: "URL 格式不正确" }, { status: 400 });
    }

    const result = await requestWithTiming(urlStr);
    const contentType = result.headers["content-type"] || null;
    const contentLength = result.headers["content-length"]
      ? parseInt(result.headers["content-length"] as string, 10)
      : null;

    return NextResponse.json({
      url: urlStr,
      finalUrl: result.finalUrl,
      statusCode: result.statusCode,
      statusText: result.statusText,
      contentType,
      contentLength,
      size: result.size,
      redirectCount: result.redirectCount,
      totalTime: Number(result.totalTime.toFixed(2)),
      dnsTime: Number(result.timings.dns.toFixed(2)),
      connectTime: Number(
        (result.timings.secureConnect || result.timings.connect).toFixed(2)
      ),
      ttfb: Number(result.timings.ttfb.toFixed(2)),
      downloadTime: Number(
        (result.totalTime - result.timings.ttfb).toFixed(2)
      ),
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "测速失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
