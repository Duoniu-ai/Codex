import { NextRequest, NextResponse } from "next/server";
import {
  getCurrentUser,
  verifyPassword,
  hashPassword,
  saveUser,
} from "@/lib/auth";

interface PasswordRequest {
  currentPassword: string;
  newPassword: string;
}

export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "未登录" }, { status: 401 });
    }

    const body: PasswordRequest = await req.json();
    const { currentPassword, newPassword } = body;

    if (
      !currentPassword ||
      !newPassword ||
      typeof currentPassword !== "string" ||
      typeof newPassword !== "string"
    ) {
      return NextResponse.json(
        { error: "请填写当前密码和新密码" },
        { status: 400 }
      );
    }

    if (newPassword.length < 6) {
      return NextResponse.json(
        { error: "新密码长度至少为 6 位" },
        { status: 400 }
      );
    }

    const valid = await verifyPassword(currentPassword, user.passwordHash);
    if (!valid) {
      return NextResponse.json({ error: "当前密码错误" }, { status: 400 });
    }

    user.passwordHash = await hashPassword(newPassword);
    saveUser(user);

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "修改密码失败" }, { status: 500 });
  }
}
