import { NextRequest, NextResponse } from "next/server";
import { getTokenFromRequest, verifyToken } from "@/lib/auth";
import { getOrdersByUser } from "@/lib/payment";

export async function GET(req: NextRequest) {
  try {
    const token = getTokenFromRequest(req);
    if (!token) {
      return NextResponse.json({ error: "请先登录" }, { status: 401 });
    }

    const payload = verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: "登录已过期" }, { status: 401 });
    }

    const orders = getOrdersByUser(payload.userId);
    return NextResponse.json({ orders });
  } catch (err) {
    const message = err instanceof Error ? err.message : "获取订单失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
