import { NextRequest, NextResponse } from "next/server";
import { getEnhancedIpInfo } from "@/lib/ip-data";

function getClientIp(req: NextRequest): string {
  const forwarded = req.headers.get("x-forwarded-for");
  if (forwarded) {
    return forwarded.split(",")[0].trim();
  }
  const realIp = req.headers.get("x-real-ip");
  if (realIp) return realIp;
  return "127.0.0.1";
}

export async function GET(req: NextRequest) {
  const ip = getClientIp(req);
  const info = getEnhancedIpInfo(ip);
  return NextResponse.json(info);
}
