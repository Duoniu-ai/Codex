"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Search } from "lucide-react";

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "通过", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "提示", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "风险", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="SEO 诊断"
      description="网站 SEO 问题诊断"
      icon={Search}
      tips={[
        "输入目标 URL 即可诊断常见 SEO 问题。",
        "重点关注标题、描述、 headings 与链接结构。",
        "模拟结果仅作参考，真实环境请结合专业工具复核。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      onRun={async () => {
        await new Promise((r) => setTimeout(r, 700 + Math.floor(Math.random() * 500)));
        return {
          score: Math.floor(60 + Math.random() * 36),
          checks: [
            { name: "Title 长度", status: Math.random() > 0.3 ? "pass" : "warn", detail: "标题长度适中，包含核心关键词" },
            { name: "Meta Description", status: Math.random() > 0.3 ? "pass" : "warn", detail: "描述存在且长度合理" },
            { name: "H1 唯一性", status: Math.random() > 0.4 ? "pass" : "risk", detail: "页面应仅包含一个 H1 标签" },
            { name: "图片 Alt 属性", status: Math.random() > 0.4 ? "pass" : "warn", detail: "所有图片建议添加 alt 文本" },
            { name: "Canonical 标签", status: Math.random() > 0.2 ? "pass" : "warn", detail: "指定规范 URL 避免重复内容" },
            { name: "Robots Meta", status: Math.random() > 0.1 ? "pass" : "risk", detail: "确保未误屏蔽重要页面" },
          ],
        };
      }}
      renderResult={(result) => {
        const data = result as {
          score: number;
          checks: { name: string; status: "pass" | "warn" | "risk"; detail: string }[];
        };
        return (
          <div className="space-y-4">
            <Card className="border-l-4 border-l-foreground">
              <CardContent className="pt-6">
                <div className="text-sm text-muted-foreground">SEO 健康分</div>
                <div className="text-3xl font-bold">{data.score}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>诊断结果</CardTitle>
                <CardDescription>站点 SEO 配置检查清单</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>检查项</TableHead>
                      <TableHead>状态</TableHead>
                      <TableHead>说明</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.checks.map((c) => (
                      <TableRow key={c.name}>
                        <TableCell>{c.name}</TableCell>
                        <TableCell>{statusBadge(c.status)}</TableCell>
                        <TableCell className="whitespace-normal">{c.detail}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}