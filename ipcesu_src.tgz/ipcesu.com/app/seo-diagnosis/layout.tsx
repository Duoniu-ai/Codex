import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "SEO 诊断",
  "网站 SEO 问题诊断",
  "analysis",
  "/seo-diagnosis",
);

export default function SeoDiagnosisLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
