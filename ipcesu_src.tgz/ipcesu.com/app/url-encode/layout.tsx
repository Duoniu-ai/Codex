import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "URL 编解码",
  "URL 编码解码工具",
  "dev",
  "/url-encode",
);

export default function UrlEncodeLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
