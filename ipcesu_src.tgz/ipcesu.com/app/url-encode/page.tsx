"use client";

import { useState } from "react";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link, ArrowRightLeft, RotateCcw, Copy, Check } from "lucide-react";

export default function Page() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [mode, setMode] = useState<"encode" | "decode">("encode");
  const [copied, setCopied] = useState(false);

  const handleConvert = () => {
    try {
      if (mode === "encode") {
        setOutput(encodeURIComponent(input));
      } else {
        setOutput(decodeURIComponent(input));
      }
    } catch (e) {
      setOutput("转换失败：输入内容格式不正确");
    }
  };

  const handleCopy = async () => {
    if (!output) return;
    await navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const handleSwap = () => {
    setMode(mode === "encode" ? "decode" : "encode");
    setInput(output);
    setOutput(input);
  };

  const handleReset = () => {
    setInput("");
    setOutput("");
  };

  return (
    <ToolPageLayout
      title="URL 编解码"
      description="URL 编码与解码工具，支持中文、特殊字符快速转换"
      icon={Link}
      tips={[
        "URL 编码会将特殊字符转换为 %XX 格式，便于在网址中传输。",
        "解码可将 %XX 还原为原始字符。",
        "支持中文、空格、&、= 等常见特殊字符。",
        "结果可直接复制使用。",
      ]}
    >
      <Card className="border-border/50 bg-card">
        <CardContent className="p-5 space-y-5">
          <div className="flex items-center gap-2">
            <Button
              variant={mode === "encode" ? "default" : "outline"}
              size="sm"
              onClick={() => setMode("encode")}
            >
              编码
            </Button>
            <Button
              variant={mode === "decode" ? "default" : "outline"}
              size="sm"
              onClick={() => setMode("decode")}
            >
              解码
            </Button>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">输入</label>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={mode === "encode" ? "输入需要编码的文本，例如：你好 world!" : "输入需要解码的 URL，例如：%E4%BD%A0%E5%A5%BD"}
              className="w-full min-h-[120px] rounded-lg border border-input bg-transparent px-3 py-2 text-sm placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 outline-none resize-y"
            />
          </div>

          <div className="flex flex-wrap gap-2">
            <Button onClick={handleConvert}>立即转换</Button>
            <Button variant="outline" onClick={handleSwap}>
              <ArrowRightLeft className="h-4 w-4 mr-1.5" />
              交换
            </Button>
            <Button variant="outline" onClick={handleReset}>
              <RotateCcw className="h-4 w-4 mr-1.5" />
              清空
            </Button>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">结果</label>
              {output && (
                <Button variant="ghost" size="sm" onClick={handleCopy}>
                  {copied ? (
                    <Check className="h-4 w-4 mr-1.5" />
                  ) : (
                    <Copy className="h-4 w-4 mr-1.5" />
                  )}
                  {copied ? "已复制" : "复制"}
                </Button>
              )}
            </div>
            <div className="min-h-[80px] rounded-lg border border-border/50 bg-muted/30 px-3 py-2 text-sm break-all">
              {output || <span className="text-muted-foreground">转换结果将显示在这里</span>}
            </div>
          </div>
        </CardContent>
      </Card>
    </ToolPageLayout>
  );
}