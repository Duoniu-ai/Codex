import type { Metadata } from "next";
import { createMetadata } from "@/lib/seo";

export const metadata: Metadata = createMetadata({
  title: "API 文档 - RESTful 网络检测接口",
  description:
    "IPcesu 开放 API 提供标准化 RESTful 接口，支持 Ping 测试、DNS 查询、SSL 检测、Whois 查询、IP 查询等核心网络检测能力，轻松集成到业务系统。",
  keywords:
    "API 文档, RESTful API, Ping API, DNS API, SSL API, Whois API, IP API, 网络检测接口, 开发者 API",
  path: "/api-docs",
});

export default function ApiDocsLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
