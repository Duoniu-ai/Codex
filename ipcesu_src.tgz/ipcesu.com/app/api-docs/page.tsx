"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Code2, Lock, Zap } from "lucide-react";

const plans = [
  {
    name: "免费版",
    price: "¥0",
    period: "/月",
    features: ["1,000 积分/月", "5 QPS", "基础接口", "注册即送 100 积分"],
    recommended: false,
  },
  {
    name: "专业版",
    price: "¥99",
    period: "/月",
    features: ["50,000 积分/月", "20 QPS", "全部接口", "优先工单支持"],
    recommended: true,
  },
  {
    name: "企业版",
    price: "¥999",
    period: "/月",
    features: ["不限调用次数", "不限 QPS", "全部接口", "专属技术支持", "定制开发"],
    recommended: false,
  },
];

interface Endpoint {
  method: string;
  path: string;
  desc: string;
  auth: boolean;
  body?: string;
  response?: string;
}

const endpoints: Endpoint[] = [
  {
    method: "GET",
    path: "/api/ip-info",
    desc: "获取当前访问 IP 的地理位置信息",
    auth: false,
    response: '{ "ip": "...", "country": "...", "region": "..." }',
  },
  {
    method: "POST",
    path: "/api/auth/register",
    desc: "用户注册，注册成功后自动登录并设置 Cookie",
    auth: false,
    body: '{ "email": "user@example.com", "password": "123456" }',
    response: '{ "user": { "id": "...", "email": "...", "credits": 100 } }',
  },
  {
    method: "POST",
    path: "/api/auth/login",
    desc: "用户登录，成功后设置 httpOnly Cookie",
    auth: false,
    body: '{ "email": "user@example.com", "password": "123456" }',
    response: '{ "user": { "id": "...", "email": "...", "credits": 100 } }',
  },
  {
    method: "GET",
    path: "/api/auth/me",
    desc: "获取当前登录用户信息",
    auth: true,
    response: '{ "user": { "id": "...", "email": "...", "credits": 100, "plan": "free" } }',
  },
  {
    method: "POST",
    path: "/api/ip",
    desc: "查询指定 IP 或域名的归属地信息",
    auth: true,
    body: '{ "target": "baidu.com" }',
  },
  {
    method: "POST",
    path: "/api/ping",
    desc: "对目标域名或 IP 执行 Ping 测试",
    auth: true,
    body: '{ "target": "baidu.com" }',
  },
  {
    method: "POST",
    path: "/api/dns",
    desc: "查询域名的 DNS 解析记录",
    auth: true,
    body: '{ "domain": "baidu.com", "type": "A" }',
  },
  {
    method: "POST",
    path: "/api/ssl",
    desc: "检测域名的 SSL 证书信息",
    auth: true,
    body: '{ "domain": "baidu.com" }',
  },
  {
    method: "POST",
    path: "/api/whois",
    desc: "查询域名的 Whois 注册信息",
    auth: true,
    body: '{ "domain": "baidu.com" }',
  },
  {
    method: "POST",
    path: "/api/speed",
    desc: "测试网页加载性能，返回 DNS、连接、首字节、下载耗时",
    auth: true,
    body: '{ "target": "baidu.com" }',
  },
  {
    method: "POST",
    path: "/api/http",
    desc: "检测网站 HTTP 状态码、响应头、跳转链和响应体预览",
    auth: true,
    body: '{ "target": "baidu.com" }',
  },
  {
    method: "POST",
    path: "/api/icp",
    desc: "查询域名 ICP 备案信息",
    auth: true,
    body: '{ "domain": "baidu.com" }',
  },
  {
    method: "POST",
    path: "/api/traceroute",
    desc: "追踪数据包到目标地址经过的路由节点",
    auth: true,
    body: '{ "target": "baidu.com" }',
  },
  {
    method: "POST",
    path: "/api/payment/create-order",
    desc: "创建 VIP 或积分充值订单",
    auth: true,
    body: '{ "type": "vip", "planId": "pro" }',
  },
  {
    method: "POST",
    path: "/api/payment/mock-pay",
    desc: "模拟支付回调，完成订单并更新账户（生产环境替换为真实支付回调）",
    auth: true,
    body: '{ "orderId": "..." }',
  },
  {
    method: "GET",
    path: "/api/user/orders",
    desc: "获取当前登录用户的订单记录",
    auth: true,
  },
];

const loginExample = `curl -X POST https://ipcesu.com/api/auth/login \\\n  -H "Content-Type: application/json" \\\n  -d '{"email":"user@example.com","password":"123456"}' \\\n  -c cookie.txt`;

const apiExample = `curl -X POST https://ipcesu.com/api/ip \\\n  -H "Content-Type: application/json" \\\n  -b cookie.txt \\\n  -d '{"target": "baidu.com"}'`;

export default function ApiDocsPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-secondary text-foreground text-sm mb-4">
            <Code2 className="h-4 w-4" />
            RESTful API
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">
            API 文档中心
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            开放的 RESTful API 接口，轻松集成到您的业务系统
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          {plans.map((plan) => (
            <Card
              key={plan.name}
              className={`border-border/50 bg-card ${
                plan.recommended
                  ? "border-foreground/20 shadow-lg shadow-foreground/5"
                  : ""
              }`}
            >
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg text-foreground">
                    {plan.name}
                  </CardTitle>
                  {plan.recommended && (
                    <Badge className="bg-foreground text-background hover:bg-foreground/90 border-0">
                      推荐
                    </Badge>
                  )}
                </div>
                <div className="flex items-baseline gap-1 mt-2">
                  <span className="text-3xl font-bold">{plan.price}</span>
                  <span className="text-muted-foreground">{plan.period}</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature) => (
                    <li
                      key={feature}
                      className="flex items-center gap-2 text-sm text-foreground"
                    >
                      <Check className="h-4 w-4 text-foreground shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button
                  className={`w-full ${
                    plan.recommended
                      ? "bg-foreground hover:bg-foreground/90 text-background"
                      : ""
                  }`}
                  variant={plan.recommended ? "default" : "outline"}
                >
                  选择套餐
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="border-border/50 bg-card mb-8">
          <CardHeader>
            <CardTitle className="text-base text-foreground flex items-center gap-2">
              <Lock className="h-4 w-4" />
              认证与积分
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-3 text-sm text-muted-foreground">
            <p>
              本站采用 Cookie 会话认证。调用需要登录的接口前，请先调用{" "}
              <code className="font-mono text-foreground">/api/auth/login</code>{" "}
              完成登录，后续请求携带 Cookie 即可。
            </p>
            <p>
              已登录用户每次调用工具接口会扣除 1 积分；未登录用户可免费使用但受浏览器速率限制。企业版用户不扣除积分。
            </p>
            <p>
              可通过{" "}
              <code className="font-mono text-foreground">/api/payment/create-order</code>{" "}
              创建 VIP 或积分充值订单，再调用支付回调完成购买。生产环境请将{" "}
              <code className="font-mono text-foreground">/api/payment/mock-pay</code>{" "}
              替换为支付宝/微信等真实支付渠道回调。
            </p>
            <div className="flex items-center gap-2 text-foreground">
              <Zap className="h-4 w-4" />
              积分不足时会返回 HTTP 403，提示充值或升级 VIP。
            </div>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-2xl font-bold mb-6 text-foreground">接口列表</h2>
            <div className="space-y-3">
              {endpoints.map((endpoint) => (
                <Card
                  key={endpoint.path}
                  className="border-border/50 bg-card"
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <Badge
                        variant="secondary"
                        className={`${
                          endpoint.method === "GET"
                            ? "bg-green-500/10 text-green-600 border-0"
                            : "bg-foreground text-background border-0"
                        }`}
                      >
                        {endpoint.method}
                      </Badge>
                      <code className="text-sm font-mono text-foreground">
                        {endpoint.path}
                      </code>
                      {endpoint.auth && (
                        <Badge
                          variant="outline"
                          className="text-xs border-border/50 text-muted-foreground"
                        >
                          需登录
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">
                      {endpoint.desc}
                    </p>
                    {endpoint.body && (
                      <div className="text-xs font-mono p-2 rounded bg-secondary/50 text-foreground break-all">
                        Body: {endpoint.body}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-6 text-foreground">调用示例</h2>
            <Card className="border-border/50 bg-secondary/50 mb-4">
              <CardContent className="p-4">
                <div className="text-xs text-muted-foreground mb-2">1. 登录获取会话</div>
                <pre className="text-sm overflow-x-auto">
                  <code className="font-mono text-muted-foreground whitespace-pre-wrap">
                    {loginExample}
                  </code>
                </pre>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-secondary/50">
              <CardContent className="p-4">
                <div className="text-xs text-muted-foreground mb-2">2. 调用工具接口</div>
                <pre className="text-sm overflow-x-auto">
                  <code className="font-mono text-muted-foreground whitespace-pre-wrap">
                    {apiExample}
                  </code>
                </pre>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
