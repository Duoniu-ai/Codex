import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "批量 TCPing",
  "多目标批量 TCPing 检测",
  "batch",
  "/batch-tcping",
);

export default function BatchTcpingLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
