"use client";

import { useState, Suspense } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Copy, Network, CheckCircle, XCircle, Gauge } from "lucide-react";

interface TcpingItem {
  target: string;
  port: number;
  resolvedIp: string;
  status: "open" | "closed" | "timeout";
  avgLatency: number;
}

interface BatchTcpingResult {
  total: number;
  open: number;
  closed: number;
  items: TcpingItem[];
}

const commonPorts = [
  { port: 80, label: "HTTP" },
  { port: 443, label: "HTTPS" },
  { port: 22, label: "SSH" },
  { port: 3306, label: "MySQL" },
  { port: 3389, label: "RDP" },
  { port: 8080, label: "Proxy" },
];

export default function BatchTcpingPage() {
  return (
    <Suspense fallback={<BatchTcpingPageSkeleton />}>
      <BatchTcpingPageForm />
    </Suspense>
  );
}

function BatchTcpingPageSkeleton() {
  return (
    <ToolPageLayout
      title="批量 TCPing"
      description="多目标批量 TCPing 检测"
      icon={Copy}
      tips={[
        "每行输入一个目标域名或 IP 地址，统一使用下方端口。",
        "常用端口：80、443、22、3306、3389。",
        "结果包含每个目标的端口开放状态和延迟。",
        "批量检测为模拟并发，结果仅供演示参考。",
      ]}
    >
      <div className="space-y-3">
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    </ToolPageLayout>
  );
}

function BatchTcpingPageForm() {
  const [targets, setTargets] = useState("");
  const [port, setPort] = useState("443");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<BatchTcpingResult | null>(null);
  const [error, setError] = useState("");

  const handleTest = async () => {
    const lines = targets.split("\n").map((line) => line.trim()).filter(Boolean);
    if (lines.length === 0) {
      setError("请至少输入一个目标地址");
      return;
    }
    const portNum = parseInt(port, 10);
    if (!port || isNaN(portNum) || portNum < 1 || portNum > 65535) {
      setError("端口范围应为 1-65535");
      return;
    }

    setLoading(true);
    setError("");
    setResult(null);

    try {
      await new Promise((r) => setTimeout(r, 800 + Math.random() * 400));
      const items: TcpingItem[] = lines.slice(0, 20).map((target) => {
        const isOpen = Math.random() > 0.35;
        return {
          target,
          port: portNum,
          resolvedIp: `${Math.floor(Math.random() * 223) + 1}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`,
          status: isOpen ? "open" : Math.random() > 0.5 ? "closed" : "timeout",
          avgLatency: isOpen ? 15 + Math.random() * 70 : 0,
        };
      });
      const data: BatchTcpingResult = {
        total: items.length,
        open: items.filter((i) => i.status === "open").length,
        closed: items.filter((i) => i.status !== "open").length,
        items,
      };
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "检测失败");
    } finally {
      setLoading(false);
    }
  };

  const statusConfig = {
    open: { label: "开放", color: "bg-green-500/15 text-green-600" },
    closed: { label: "关闭", color: "bg-red-500/15 text-red-600" },
    timeout: { label: "超时", color: "bg-amber-500/15 text-amber-600" },
  };

  return (
    <ToolPageLayout
      title="批量 TCPing"
      description="多目标批量 TCPing 检测"
      icon={Copy}
      tips={[
        "每行输入一个目标域名或 IP 地址，统一使用下方端口。",
        "常用端口：80、443、22、3306、3389。",
        "结果包含每个目标的端口开放状态和延迟。",
        "批量检测为模拟并发，结果仅供演示参考。",
      ]}
    >
      <Card className="border-border/40 bg-card shadow-sm">
        <CardContent className="p-5 space-y-5">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">目标列表</label>
            <textarea
              value={targets}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setTargets(e.target.value)}
              placeholder="例如：&#10;baidu.com&#10;8.8.8.8&#10;qq.com"
              rows={5}
              className="w-full rounded-lg border border-input bg-secondary/50 px-3 py-2 text-sm placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 outline-none resize-none font-mono"
            />
            <p className="text-xs text-muted-foreground">
              每行一个目标，最多 20 个
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
            <div className="sm:col-span-4 space-y-2">
              <label className="text-sm font-medium text-foreground">统一端口</label>
              <Input
                type="number"
                min={1}
                max={65535}
                value={port}
                onChange={(e) => setPort(e.target.value)}
                placeholder="443"
                className="bg-secondary/50 border-border/50"
              />
            </div>
            <div className="sm:col-span-8 flex flex-wrap items-end gap-2">
              <span className="text-xs text-muted-foreground mb-2">常用端口：</span>
              {commonPorts.map((item) => (
                <button
                  key={item.port}
                  onClick={() => setPort(String(item.port))}
                  className="text-xs px-2 py-1 rounded-md border border-border/50 bg-secondary/30 text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors mb-1.5"
                >
                  {item.port} {item.label}
                </button>
              ))}
            </div>
          </div>

          <Button
            onClick={handleTest}
            disabled={loading}
            className="bg-foreground hover:bg-foreground/90 text-background"
          >
            {loading ? "检测中..." : "开始批量检测"}
          </Button>
        </CardContent>
      </Card>

      {error && (
        <div className="p-4 rounded-lg bg-destructive/10 text-destructive text-sm">
          {error}
        </div>
      )}

      {loading && (
        <Card className="border-border/40 bg-card shadow-sm">
          <CardContent className="p-5 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
            </div>
            <Skeleton className="h-48 w-full" />
          </CardContent>
        </Card>
      )}

      {result && !loading && (
        <div className="space-y-4 animate-fade-in-up">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Copy className="h-4 w-4 text-foreground" />
                  检测总数
                </div>
                <div className="font-medium text-foreground">{result.total}</div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  开放
                </div>
                <div className="font-medium text-foreground">{result.open}</div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <XCircle className="h-4 w-4 text-red-600" />
                  关闭 / 超时
                </div>
                <div className="font-medium text-foreground">{result.closed}</div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-3 text-muted-foreground text-sm">
                <Network className="h-4 w-4 text-foreground" />
                检测结果
              </div>
              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>目标</TableHead>
                      <TableHead>解析 IP</TableHead>
                      <TableHead>端口</TableHead>
                      <TableHead>状态</TableHead>
                      <TableHead>延迟</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {result.items.map((item, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium text-foreground break-all">
                          {item.target}
                        </TableCell>
                        <TableCell className="font-mono text-foreground break-all">
                          {item.resolvedIp}
                        </TableCell>
                        <TableCell className="font-mono text-foreground">
                          {item.port}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={statusConfig[item.status].color}
                          >
                            {statusConfig[item.status].label}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-foreground">
                          {item.status === "open"
                            ? `${item.avgLatency.toFixed(2)} ms`
                            : "--"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </ToolPageLayout>
  );
}
