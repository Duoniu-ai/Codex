"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Type } from "lucide-react";

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "通过", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "提示", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "风险", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="TDK 检测"
      description="标题、描述、关键词检测"
      icon={Type}
      tips={[
        "输入目标 URL 即可分析 Title、Description、Keywords。",
        "标题长度建议控制在 30 个汉字以内。",
        "避免不同页面使用重复的 TDK 内容。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      onRun={async () => {
        await new Promise((r) => setTimeout(r, 600 + Math.floor(Math.random() * 500)));
        return {
          title: "示例页面标题 - 品牌词",
          titleLength: 14,
          description: "这是一个示例描述，用于演示 TDK 检测结果。",
          descriptionLength: 24,
          keywords: "示例, 关键词, 演示",
          duplicate: Math.random() > 0.8,
        };
      }}
      renderResult={(result) => {
        const data = result as {
          title: string;
          titleLength: number;
          description: string;
          descriptionLength: number;
          keywords: string;
          duplicate: boolean;
        };
        const checks: { name: string; status: "pass" | "warn" | "risk"; detail: string }[] = [
          { name: "Title 长度", status: data.titleLength <= 30 ? "pass" : "warn", detail: `${data.titleLength} 个字符` },
          { name: "Description 长度", status: data.descriptionLength >= 20 && data.descriptionLength <= 120 ? "pass" : "warn", detail: `${data.descriptionLength} 个字符` },
          { name: "Keywords 存在", status: data.keywords ? "pass" : "risk", detail: data.keywords || "未设置" },
          { name: "TDK 重复", status: data.duplicate ? "risk" : "pass", detail: data.duplicate ? "检测到重复 TDK" : "未发现重复" },
        ];
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="text-sm text-muted-foreground">Title 长度</div>
                  <div className="text-2xl font-semibold">{data.titleLength}</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="text-sm text-muted-foreground">Description 长度</div>
                  <div className="text-2xl font-semibold">{data.descriptionLength}</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="text-sm text-muted-foreground">重复风险</div>
                  <div className="text-2xl font-semibold">{data.duplicate ? "有" : "无"}</div>
                </CardContent>
              </Card>
            </div>
            <Card>
              <CardHeader>
                <CardTitle>TDK 内容</CardTitle>
                <CardDescription>页面标题与元信息摘要</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div><span className="font-medium">Title：</span>{data.title}</div>
                <div><span className="font-medium">Description：</span>{data.description}</div>
                <div><span className="font-medium">Keywords：</span>{data.keywords || "未设置"}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>检查结论</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>项目</TableHead>
                      <TableHead>状态</TableHead>
                      <TableHead>说明</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {checks.map((c) => (
                      <TableRow key={c.name}>
                        <TableCell>{c.name}</TableCell>
                        <TableCell>{statusBadge(c.status)}</TableCell>
                        <TableCell className="whitespace-normal">{c.detail}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}