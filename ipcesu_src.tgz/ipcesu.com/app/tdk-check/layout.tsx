import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "TDK 检测",
  "标题、描述、关键词检测",
  "analysis",
  "/tdk-check",
);

export default function TdkCheckLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
