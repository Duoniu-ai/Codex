"use client";

import { useState } from "react";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Fingerprint, Copy, Check, RefreshCw } from "lucide-react";

function generateUUID(): string {
  if (typeof crypto !== "undefined" && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

export default function Page() {
  const [count, setCount] = useState(5);
  const [uuids, setUuids] = useState<string[]>(Array.from({ length: 5 }, generateUUID));
  const [copiedId, setCopiedId] = useState<number | null>(null);
  const [copiedAll, setCopiedAll] = useState(false);

  const handleGenerate = () => {
    const next = Array.from({ length: Math.min(Math.max(count, 1), 100) }, generateUUID);
    setUuids(next);
  };

  const handleCopy = async (uuid: string, index: number) => {
    await navigator.clipboard.writeText(uuid);
    setCopiedId(index);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const handleCopyAll = async () => {
    await navigator.clipboard.writeText(uuids.join("\n"));
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 1500);
  };

  return (
    <ToolPageLayout
      title="UUID 生成器"
      description="批量生成标准 UUID v4，支持一键复制"
      icon={Fingerprint}
      tips={[
        "一键批量生成 UUID v4 全球唯一标识符。",
        "支持单次生成最多 100 个。",
        "可单独复制某一条，也可一键复制全部。",
        "所有生成在浏览器本地完成。",
      ]}
    >
      <Card className="border-border/50 bg-card">
        <CardContent className="p-5 space-y-5">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex items-center gap-2">
              <label className="text-sm font-medium whitespace-nowrap">生成数量</label>
              <Input
                type="number"
                min={1}
                max={100}
                value={count}
                onChange={(e) => setCount(Number(e.target.value))}
                className="w-24"
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleGenerate}>
                <RefreshCw className="h-4 w-4 mr-1.5" />
                重新生成
              </Button>
              <Button variant="outline" onClick={handleCopyAll}>
                {copiedAll ? <Check className="h-4 w-4 mr-1.5" /> : <Copy className="h-4 w-4 mr-1.5" />}
                {copiedAll ? "已复制全部" : "复制全部"}
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            {uuids.map((uuid, index) => (
              <div
                key={index}
                className="flex items-center gap-2 rounded-lg border border-border/50 bg-muted/30 px-3 py-2"
              >
                <code className="flex-1 text-xs break-all text-foreground">{uuid}</code>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleCopy(uuid, index)}
                >
                  {copiedId === index ? (
                    <Check className="h-4 w-4" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </ToolPageLayout>
  );
}