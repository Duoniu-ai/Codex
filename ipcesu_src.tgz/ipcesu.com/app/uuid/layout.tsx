import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "UUID 生成器",
  "批量生成 UUID",
  "dev",
  "/uuid",
);

export default function UuidLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
