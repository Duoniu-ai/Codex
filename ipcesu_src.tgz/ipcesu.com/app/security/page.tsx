"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Shield } from "lucide-react";

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "安全", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "建议", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "风险", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="网站安全检测"
      description="安全配置分析"
      icon={Shield}
      tips={[
        "输入目标 URL 即可模拟安全基线检查。",
        "关注 HTTPS、HSTS、CSP 等关键响应头。",
        "安全检测仅作参考，建议定期渗透测试。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      onRun={async () => {
        await new Promise((r) => setTimeout(r, 800 + Math.floor(Math.random() * 400)));
        return {
          score: Math.floor(60 + Math.random() * 36),
          checks: [
            { name: "HTTPS 强制跳转", status: Math.random() > 0.2 ? "pass" : "warn", detail: "HTTP 请求应 301 跳转至 HTTPS" },
            { name: "HSTS 响应头", status: Math.random() > 0.3 ? "pass" : "warn", detail: "Strict-Transport-Security 强化 HTTPS" },
            { name: "X-Frame-Options", status: Math.random() > 0.2 ? "pass" : "risk", detail: "防止页面被恶意 iframe 嵌入" },
            { name: "Content-Security-Policy", status: Math.random() > 0.4 ? "pass" : "warn", detail: "限制外部资源加载，降低 XSS 风险" },
            { name: "X-Content-Type-Options", status: Math.random() > 0.2 ? "pass" : "warn", detail: "nosniff 防止 MIME 嗅探" },
            { name: "WAF 识别", status: Math.random() > 0.5 ? "pass" : "warn", detail: "是否部署 Web 应用防火墙" },
          ],
        };
      }}
      renderResult={(result) => {
        const data = result as {
          score: number;
          checks: { name: string; status: "pass" | "warn" | "risk"; detail: string }[];
        };
        return (
          <div className="space-y-4">
            <Card className="border-l-4 border-l-foreground">
              <CardContent className="pt-6">
                <div className="text-sm text-muted-foreground">安全评分</div>
                <div className="text-3xl font-bold">{data.score}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>安全基线检查</CardTitle>
                <CardDescription>常见安全配置项检测结果</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>检查项</TableHead>
                      <TableHead>状态</TableHead>
                      <TableHead>说明</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.checks.map((c) => (
                      <TableRow key={c.name}>
                        <TableCell>{c.name}</TableCell>
                        <TableCell>{statusBadge(c.status)}</TableCell>
                        <TableCell className="whitespace-normal">{c.detail}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}