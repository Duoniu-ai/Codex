"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Bug } from "lucide-react";

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "允许", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "受限", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "禁止", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="蜘蛛抓取"
      description="模拟搜索引擎蜘蛛抓取"
      icon={Bug}
      tips={[
        "输入目标 URL 模拟搜索引擎蜘蛛抓取过程。",
        "关注 Robots 规则是否误屏蔽重要页面。",
        "抓取结果可帮助优化收录与索引策略。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      onRun={async () => {
        await new Promise((r) => setTimeout(r, 800 + Math.floor(Math.random() * 400)));
        const pages = ["/", "/about", "/products", "/blog", "/contact"];
        const results = pages.map((path) => ({
          path,
          status: Math.random() > 0.8 ? 403 : 200,
          allowed: Math.random() > 0.2,
          indexable: Math.random() > 0.15,
        }));
        return {
          robotStatus: Math.random() > 0.1 ? "pass" : "warn",
          sitemapFound: Math.random() > 0.3,
          pagesDiscovered: results.length,
          results,
        };
      }}
      renderResult={(result) => {
        const data = result as {
          robotStatus: "pass" | "warn";
          sitemapFound: boolean;
          pagesDiscovered: number;
          results: { path: string; status: number; allowed: boolean; indexable: boolean }[];
        };
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">Robots 规则</div><div className="mt-1">{statusBadge(data.robotStatus)}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">Sitemap</div><div className="text-2xl font-semibold">{data.sitemapFound ? "已发现" : "未发现"}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">抓取页面</div><div className="text-2xl font-semibold">{data.pagesDiscovered}</div></CardContent></Card>
            </div>
            <Card>
              <CardHeader>
                <CardTitle>抓取结果</CardTitle>
                <CardDescription>模拟蜘蛛访问的页面状态</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>路径</TableHead>
                      <TableHead>状态码</TableHead>
                      <TableHead>允许抓取</TableHead>
                      <TableHead>可索引</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.results.map((item) => (
                      <TableRow key={item.path}>
                        <TableCell>{item.path}</TableCell>
                        <TableCell>{item.status}</TableCell>
                        <TableCell>{statusBadge(item.allowed ? "pass" : "risk")}</TableCell>
                        <TableCell>{statusBadge(item.indexable ? "pass" : "warn")}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}