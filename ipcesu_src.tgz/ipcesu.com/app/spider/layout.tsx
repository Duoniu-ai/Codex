import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "蜘蛛抓取",
  "模拟搜索引擎蜘蛛抓取",
  "analysis",
  "/spider",
);

export default function SpiderLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
