"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Lock } from "lucide-react";

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "可达", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "不稳定", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "被墙", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="被墙检测"
      description="检测网站或 IP 是否在中国大陆被屏蔽"
      icon={Lock}
      tips={[
        "输入目标域名或 IP 即可模拟多地区探测。",
        "结果仅供参考，实际访问可能因运营商而异。",
        "建议结合多个节点和时段综合判断。",
      ]}
      inputs={[
        { id: "target", label: "域名或 IP", type: "text", placeholder: "example.com" },
      ]}
      onRun={async () => {
        await new Promise((r) => setTimeout(r, 900 + Math.floor(Math.random() * 300)));
        const nodes = [
          { region: "北京", status: Math.random() > 0.2 ? "pass" : "risk" as "pass" | "warn" | "risk", latency: Math.floor(20 + Math.random() * 80) },
          { region: "上海", status: Math.random() > 0.2 ? "pass" : "risk", latency: Math.floor(20 + Math.random() * 80) },
          { region: "广州", status: Math.random() > 0.25 ? "pass" : "warn", latency: Math.floor(25 + Math.random() * 90) },
          { region: "海外（新加坡）", status: Math.random() > 0.1 ? "pass" : "risk", latency: Math.floor(40 + Math.random() * 100) },
        ];
        const blockedCount = nodes.filter((n) => n.status === "risk").length;
        const overall: "pass" | "warn" | "risk" = blockedCount === 0 ? "pass" : blockedCount >= 2 ? "risk" : "warn";
        return { overall, nodes };
      }}
      renderResult={(result) => {
        const data = result as { overall: "pass" | "warn" | "risk"; nodes: { region: string; status: "pass" | "warn" | "risk"; latency: number }[] };
        return (
          <div className="space-y-4">
            <Card className="border-l-4 border-l-foreground">
              <CardContent className="pt-6 flex items-center justify-between">
                <div>
                  <div className="text-sm text-muted-foreground">综合判断</div>
                  <div className="text-3xl font-bold">{statusBadge(data.overall)}</div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>节点探测结果</CardTitle>
                <CardDescription>不同地区可达性与延迟</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>地区</TableHead>
                      <TableHead>延迟</TableHead>
                      <TableHead>结果</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.nodes.map((n) => (
                      <TableRow key={n.region}>
                        <TableCell>{n.region}</TableCell>
                        <TableCell>{n.latency} ms</TableCell>
                        <TableCell>{statusBadge(n.status)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}