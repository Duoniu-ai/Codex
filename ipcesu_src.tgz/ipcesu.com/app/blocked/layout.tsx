import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "被墙检测",
  "检测网站或 IP 是否被墙",
  "network",
  "/blocked",
);

export default function BlockedLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
