import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "HTTP IPv6",
  "IPv6 网站测速",
  "speed",
  "/http-ipv6",
);

export default function HttpIpv6Layout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
