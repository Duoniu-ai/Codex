import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "注册 - IPcesu 工具站",
  description: "注册 IPcesu 工具站账号，获取免费积分，使用网络检测与网站分析工具。",
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
