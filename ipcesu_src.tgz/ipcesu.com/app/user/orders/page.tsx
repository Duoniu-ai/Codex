"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { UserSidebar } from "@/components/user/user-sidebar";
import { Receipt, ArrowLeft, Loader2 } from "lucide-react";

interface Order {
  id: string;
  type: "vip" | "credits";
  planId?: "free" | "pro" | "enterprise";
  creditAmount?: number;
  amount: number;
  status: "pending" | "paid" | "cancelled";
  createdAt: string;
  paidAt: string | null;
}

const planLabels: Record<string, string> = {
  pro: "专业版 VIP",
  enterprise: "企业版 VIP",
};

const statusLabels: Record<string, string> = {
  pending: "待支付",
  paid: "已支付",
  cancelled: "已取消",
};

export default function OrdersPage() {
  const [mounted, setMounted] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    setMounted(true);
    setLoading(true);
    fetch("/api/user/orders", { credentials: "include" })
      .then((res) => {
        if (!res.ok) throw new Error("获取订单失败");
        return res.json();
      })
      .then((data) => {
        setOrders(data.orders || []);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message || "获取订单失败");
        setLoading(false);
      });
  }, []);

  const formatDate = (iso: string) =>
    new Date(iso).toLocaleString("zh-CN", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });

  if (!mounted || loading) {
    return (
      <div className="container mx-auto px-4 py-16 text-center text-muted-foreground">
        <Loader2 className="h-6 w-6 animate-spin mx-auto" />
        <div className="mt-2">加载中...</div>
      </div>
    );
  }

  if (error === "获取订单失败" || error === "未登录") {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-md mx-auto text-center">
          <Card className="border-border/40 bg-card">
            <CardContent className="p-8 space-y-4">
              <Receipt className="h-12 w-12 mx-auto text-muted-foreground" />
              <h1 className="text-xl font-bold text-foreground">请先登录</h1>
              <p className="text-sm text-muted-foreground">
                登录后即可查看订单记录
              </p>
              <Link
                href="/user/login"
                className="inline-flex items-center justify-center rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background transition-colors hover:bg-foreground/90 w-full"
              >
                立即登录
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-10">
      <div className="mx-auto max-w-6xl">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-foreground">订单记录</h1>
          <p className="text-sm text-muted-foreground">
            查看积分充值与 VIP 购买历史
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-[240px_1fr]">
          <aside className="hidden lg:block">
            <UserSidebar className="sticky top-24" />
          </aside>

          <div className="space-y-6">
            <Card className="border-border/40 bg-card">
              <CardHeader>
                <CardTitle className="text-base text-foreground flex items-center gap-2">
                  <Receipt className="h-4 w-4" />
                  全部订单
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                {error && (
                  <div className="p-3 rounded-lg bg-destructive/10 text-destructive text-sm mb-6">
                    {error}
                  </div>
                )}

                {orders.length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground text-sm">
                    暂无订单记录
                  </div>
                ) : (
                  <div className="divide-y divide-border">
                    {orders.map((order) => (
                      <div
                        key={order.id}
                        className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                      >
                        <div>
                          <div className="font-medium text-foreground">
                            {order.type === "vip"
                              ? planLabels[order.planId || ""] || "VIP 套餐"
                              : `${order.creditAmount || 0} 积分充值`}
                          </div>
                          <div className="text-xs text-muted-foreground mt-1">
                            订单号：{order.id}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            创建时间：{formatDate(order.createdAt)}
                          </div>
                        </div>
                        <div className="flex items-center gap-4 sm:flex-col sm:items-end sm:gap-1">
                          <div className="font-bold text-foreground">
                            ¥{order.amount}
                          </div>
                          <Badge
                            variant="secondary"
                            className={`border-0 ${
                              order.status === "paid"
                                ? "bg-green-500/10 text-green-600"
                                : order.status === "pending"
                                ? "bg-yellow-500/10 text-yellow-600"
                                : "bg-muted text-muted-foreground"
                            }`}
                          >
                            {statusLabels[order.status]}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="flex items-center gap-4">
              <Link
                href="/user/credits"
                className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                <ArrowLeft className="h-4 w-4" />
                返回账户
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
