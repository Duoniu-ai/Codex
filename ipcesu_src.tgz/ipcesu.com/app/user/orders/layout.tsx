import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "订单记录 - IPcesu 工具站",
  description: "查看积分充值、VIP 购买等订单记录与支付状态。",
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
