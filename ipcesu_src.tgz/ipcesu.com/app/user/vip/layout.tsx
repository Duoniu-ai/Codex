import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "VIP 套餐 - IPcesu 工具站",
  description: "查看并升级 IPcesu VIP 套餐，获取更高 QPS、更多调用额度与专属支持。",
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
