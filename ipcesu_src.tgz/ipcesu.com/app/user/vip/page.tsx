"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { UserSidebar } from "@/components/user/user-sidebar";
import { UserHeader } from "@/components/user/user-header";
import { Check, Crown, Loader2, Zap, ArrowRight } from "lucide-react";
import { vipPlans, formatPrice } from "@/lib/plans";
import type { UserPlan } from "@/lib/user";

interface UserInfo {
  id: string;
  email: string;
  credits: number;
  plan: UserPlan;
  vipExpiresAt: string | null;
}

const planLabels: Record<UserPlan, string> = {
  free: "免费版",
  pro: "专业版",
  enterprise: "企业版",
};

export default function VipPage() {
  const router = useRouter();
  const [mounted, setMounted] = useState(false);
  const [user, setUser] = useState<UserInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [paying, setPaying] = useState<UserPlan | null>(null);
  const [message, setMessage] = useState("");

  useEffect(() => {
    setMounted(true);
    setLoading(true);
    fetch("/api/auth/me", { credentials: "include" })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data?.user) setUser(data.user);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const handlePurchase = async (planId: UserPlan) => {
    if (!user) {
      router.push("/user/login");
      return;
    }
    setPaying(planId);
    setMessage("");

    try {
      const createRes = await fetch("/api/payment/create-order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ type: "vip", planId }),
      });
      const createData = await createRes.json();
      if (!createRes.ok) {
        setMessage(createData.error || "创建订单失败");
        return;
      }

      const payRes = await fetch("/api/payment/mock-pay", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ orderId: createData.order.id }),
      });
      const payData = await payRes.json();
      if (!payRes.ok) {
        setMessage(payData.error || "支付失败");
        return;
      }

      setUser((prev) =>
        prev
          ? {
              ...prev,
              plan: planId,
              vipExpiresAt: payData.order.paidAt
                ? new Date(
                    Date.now() + 30 * 24 * 60 * 60 * 1000
                  ).toISOString()
                : prev.vipExpiresAt,
            }
          : prev
      );
      setMessage("支付成功，VIP 已开通");
      router.refresh();
    } catch {
      setMessage("网络错误，请稍后重试");
    } finally {
      setPaying(null);
    }
  };

  if (!mounted || loading) {
    return (
      <div className="container mx-auto px-4 py-16 text-center text-muted-foreground">
        <Loader2 className="h-6 w-6 animate-spin mx-auto" />
        <div className="mt-2">加载中...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-md mx-auto text-center">
          <Card className="border-border/40 bg-card">
            <CardContent className="p-8 space-y-4">
              <Crown className="h-12 w-12 mx-auto text-muted-foreground" />
              <h1 className="text-xl font-bold text-foreground">请先登录</h1>
              <p className="text-sm text-muted-foreground">
                登录后即可查看和购买 VIP 套餐
              </p>
              <Link
                href="/user/login"
                className="inline-flex items-center justify-center rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background transition-colors hover:bg-foreground/90 w-full"
              >
                立即登录
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-10">
      <div className="mx-auto max-w-6xl">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-foreground">VIP 会员</h1>
          <p className="text-sm text-muted-foreground">
            选择适合您的套餐，提升调用额度与服务质量
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-[240px_1fr]">
          <aside className="hidden lg:block">
            <UserSidebar className="sticky top-24" />
          </aside>

          <div className="space-y-6">
            <UserHeader user={{ ...user, createdAt: "" }} />

            <Card className="border-border/40 bg-card">
              <CardContent className="p-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">
                      当前套餐
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-lg font-bold text-foreground">
                        {planLabels[user.plan]}
                      </span>
                      {user.plan !== "free" && user.vipExpiresAt && (
                        <Badge
                          variant="secondary"
                          className="bg-foreground text-background border-0"
                        >
                          有效期至{" "}
                          {new Date(user.vipExpiresAt).toLocaleDateString("zh-CN")}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Zap className="h-4 w-4" />
                    积分余额：{user.credits}
                  </div>
                </div>
              </CardContent>
            </Card>

            {message && (
              <div
                className={`p-3 rounded-lg text-sm ${
                  message.includes("成功")
                    ? "bg-green-500/10 text-green-600"
                    : "bg-destructive/10 text-destructive"
                }`}
              >
                {message}
              </div>
            )}

            <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
              {vipPlans.map((plan) => (
                <Card
                  key={plan.id}
                  className={`border-border/40 bg-card ${
                    plan.recommended
                      ? "border-foreground/20 shadow-lg shadow-foreground/5"
                      : ""
                  }`}
                >
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg text-foreground">
                        {plan.name}
                      </CardTitle>
                      {plan.recommended && (
                        <Badge className="bg-foreground text-background hover:bg-foreground/90 border-0">
                          推荐
                        </Badge>
                      )}
                      {user.plan === plan.id && (
                        <Badge
                          variant="outline"
                          className="border-border/40 text-muted-foreground"
                        >
                          当前套餐
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-baseline gap-1 mt-2">
                      <span className="text-3xl font-bold">
                        {formatPrice(plan.price)}
                      </span>
                      <span className="text-muted-foreground">
                        /{plan.periodDays} 天
                      </span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3 mb-6">
                      <li className="flex items-center gap-2 text-sm text-foreground">
                        <Check className="h-4 w-4 text-foreground shrink-0" />
                        QPS：{plan.qps}
                      </li>
                      <li className="flex items-center gap-2 text-sm text-foreground">
                        <Check className="h-4 w-4 text-foreground shrink-0" />
                        调用额度：
                        {plan.monthlyCredits > 0
                          ? `${plan.monthlyCredits.toLocaleString()} 次/月`
                          : "不限"}
                      </li>
                      {plan.features.slice(2).map((feature) => (
                        <li
                          key={feature}
                          className="flex items-center gap-2 text-sm text-foreground"
                        >
                          <Check className="h-4 w-4 text-foreground shrink-0" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <Button
                      className={`w-full ${
                        plan.recommended
                          ? "bg-foreground hover:bg-foreground/90 text-background"
                          : ""
                      }`}
                      variant={plan.recommended ? "default" : "outline"}
                      disabled={paying === plan.id || user.plan === plan.id}
                      onClick={() => handlePurchase(plan.id)}
                    >
                      {paying === plan.id ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          处理中...
                        </>
                      ) : user.plan === plan.id ? (
                        "当前套餐"
                      ) : (
                        "立即开通"
                      )}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 rounded-xl border border-border/40 bg-card p-5">
              <div>
                <div className="text-sm font-medium text-foreground">
                  需要更多积分？
                </div>
                <div className="text-xs text-muted-foreground">
                  购买积分包可在 VIP 额度之外继续使用
                </div>
              </div>
              <Link
                href="/user/credits"
                className="inline-flex items-center justify-center rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background transition-colors hover:bg-foreground/90 gap-2"
              >
                充值积分
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>

            <div className="text-center text-sm text-muted-foreground">
              当前为演示环境，点击"立即开通"将使用模拟支付直接完成购买。
              生产环境可对接支付宝、微信支付等真实渠道。
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
