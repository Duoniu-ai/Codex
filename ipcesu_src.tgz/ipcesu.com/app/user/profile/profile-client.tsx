"use client";

import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { UserSidebar } from "@/components/user/user-sidebar";
import { UserHeader } from "@/components/user/user-header";
import {
  Zap,
  Crown,
  Settings,
  Receipt,
  ArrowRight,
  Activity,
} from "lucide-react";
import { planBenefits } from "@/lib/plans";
import type { SafeUser } from "@/lib/user";

function getPlanName(plan: SafeUser["plan"]) {
  switch (plan) {
    case "enterprise":
      return "企业版";
    case "pro":
      return "专业版";
    default:
      return "免费版";
  }
}

interface ProfileClientProps {
  initialUser: SafeUser | null;
}

export function ProfileClient({ initialUser }: ProfileClientProps) {
  if (!initialUser) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-md mx-auto text-center">
          <Card className="border-border/40 bg-card">
            <CardContent className="p-8 space-y-4">
              <UserIcon className="h-12 w-12 mx-auto text-muted-foreground" />
              <h1 className="text-xl font-bold text-foreground">请先登录</h1>
              <p className="text-sm text-muted-foreground">
                登录后即可查看个人中心
              </p>
              <Link
                href="/user/login"
                className="inline-flex items-center justify-center rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background transition-colors hover:bg-foreground/90 w-full"
              >
                立即登录
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const user = initialUser;
  const benefits = planBenefits(user.plan);

  return (
    <div className="container mx-auto px-4 py-10">
      <div className="mx-auto max-w-6xl">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-foreground">个人中心</h1>
          <p className="text-sm text-muted-foreground">
            查看账户概况，快速管理积分、VIP 与设置
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-[240px_1fr]">
          <aside className="hidden lg:block">
            <UserSidebar className="sticky top-24" />
          </aside>

          <div className="space-y-6">
            <UserHeader user={user} />

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <Card className="border-border/40 bg-card">
                <CardContent className="p-5">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                    <Zap className="h-4 w-4" />
                    积分余额
                  </div>
                  <div className="text-2xl font-bold text-foreground">
                    {user.credits}
                  </div>
                  <div className="mt-3">
                    <Link
                      href="/user/credits"
                      className="inline-flex items-center text-sm font-medium text-primary hover:underline"
                    >
                      去充值
                      <ArrowRight className="ml-1 h-3.5 w-3.5" />
                    </Link>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/40 bg-card">
                <CardContent className="p-5">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                    <Crown className="h-4 w-4" />
                    当前套餐
                  </div>
                  <div className="text-lg font-bold text-foreground">
                    {getPlanName(user.plan)}
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground">
                    {user.vipExpiresAt
                      ? `有效期至 ${new Date(
                          user.vipExpiresAt
                        ).toLocaleDateString("zh-CN")}`
                      : "未开通 VIP"}
                  </div>
                  <div className="mt-3">
                    <Link
                      href="/user/vip"
                      className="inline-flex items-center text-sm font-medium text-primary hover:underline"
                    >
                      {user.plan === "free" ? "开通 VIP" : "升级/续费"}
                      <ArrowRight className="ml-1 h-3.5 w-3.5" />
                    </Link>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/40 bg-card sm:col-span-2 lg:col-span-1">
                <CardContent className="p-5">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                    <Activity className="h-4 w-4" />
                    本月调用
                  </div>
                  <div className="text-2xl font-bold text-foreground">
                    {benefits.monthlyCredits}
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground">
                    QPS 限制：{benefits.qps}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="border-border/40 bg-card">
              <CardHeader>
                <CardTitle className="text-base text-foreground">
                  快捷入口
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <Link
                    href="/user/credits"
                    className="flex items-center justify-between rounded-lg border border-border/40 p-4 transition-colors hover:bg-accent"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
                        <Zap className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-foreground">
                          积分管理
                        </div>
                        <div className="text-xs text-muted-foreground">
                          充值积分，查看余额
                        </div>
                      </div>
                    </div>
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  </Link>

                  <Link
                    href="/user/vip"
                    className="flex items-center justify-between rounded-lg border border-border/40 p-4 transition-colors hover:bg-accent"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-500/10 text-amber-600">
                        <Crown className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-foreground">
                          VIP 会员
                        </div>
                        <div className="text-xs text-muted-foreground">
                          开通套餐，提升额度
                        </div>
                      </div>
                    </div>
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  </Link>

                  <Link
                    href="/user/orders"
                    className="flex items-center justify-between rounded-lg border border-border/40 p-4 transition-colors hover:bg-accent"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-secondary text-foreground">
                        <Receipt className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-foreground">
                          订单记录
                        </div>
                        <div className="text-xs text-muted-foreground">
                          查看历史购买记录
                        </div>
                      </div>
                    </div>
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  </Link>

                  <Link
                    href="/user/settings"
                    className="flex items-center justify-between rounded-lg border border-border/40 p-4 transition-colors hover:bg-accent"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-secondary text-foreground">
                        <Settings className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-foreground">
                          账户设置
                        </div>
                        <div className="text-xs text-muted-foreground">
                          修改昵称与偏好
                        </div>
                      </div>
                    </div>
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

function UserIcon({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  );
}
