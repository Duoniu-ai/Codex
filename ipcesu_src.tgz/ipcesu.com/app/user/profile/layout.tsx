import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "个人中心 - IPcesu 工具站",
  description: "查看和管理您的个人账户信息、套餐状态与使用概况。",
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
