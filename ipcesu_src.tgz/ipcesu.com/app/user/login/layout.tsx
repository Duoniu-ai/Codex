import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "登录 - IPcesu 工具站",
  description: "登录 IPcesu 工具站，使用历史记录、监控服务与 API 调用额度管理。",
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
