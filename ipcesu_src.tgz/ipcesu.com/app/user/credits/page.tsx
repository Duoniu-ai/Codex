"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { UserSidebar } from "@/components/user/user-sidebar";
import { UserHeader } from "@/components/user/user-header";
import {
  Zap,
  Crown,
  Calendar,
  ArrowRight,
  Loader2,
  Receipt,
  Coins,
} from "lucide-react";
import { creditPacks, formatPrice } from "@/lib/plans";
import type { UserPlan } from "@/lib/user";

interface UserInfo {
  id: string;
  email: string;
  credits: number;
  plan: UserPlan;
  vipExpiresAt: string | null;
  createdAt: string;
}

const planLabels: Record<string, string> = {
  free: "免费版",
  pro: "专业版",
  enterprise: "企业版",
};

export default function CreditsPage() {
  const [mounted, setMounted] = useState(false);
  const [user, setUser] = useState<UserInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [payingPack, setPayingPack] = useState<string | null>(null);
  const [message, setMessage] = useState("");

  useEffect(() => {
    setMounted(true);
    setLoading(true);
    fetch("/api/auth/me", { credentials: "include" })
      .then((res) => {
        if (!res.ok) throw new Error("未登录");
        return res.json();
      })
      .then((data) => {
        setUser(data.user);
        setLoading(false);
      })
      .catch(() => {
        setLoading(false);
      });
  }, []);

  const handleRecharge = async (packId: string) => {
    setPayingPack(packId);
    setMessage("");

    try {
      const createRes = await fetch("/api/payment/create-order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ type: "credits", packId }),
      });
      const createData = await createRes.json();
      if (!createRes.ok) {
        setMessage(createData.error || "创建订单失败");
        return;
      }

      const payRes = await fetch("/api/payment/mock-pay", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ orderId: createData.order.id }),
      });
      const payData = await payRes.json();
      if (!payRes.ok) {
        setMessage(payData.error || "支付失败");
        return;
      }

      setUser((prev) =>
        prev
          ? { ...prev, credits: prev.credits + (payData.order.creditAmount || 0) }
          : prev
      );
      setMessage("充值成功，积分已到账");
    } catch {
      setMessage("网络错误，请稍后重试");
    } finally {
      setPayingPack(null);
    }
  };

  if (!mounted || loading) {
    return (
      <div className="container mx-auto px-4 py-16 text-center text-muted-foreground">
        <Loader2 className="h-6 w-6 animate-spin mx-auto" />
        <div className="mt-2">加载中...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-md mx-auto text-center">
          <Card className="border-border/40 bg-card">
            <CardContent className="p-8 space-y-4">
              <Coins className="h-12 w-12 mx-auto text-muted-foreground" />
              <h1 className="text-xl font-bold text-foreground">请先登录</h1>
              <p className="text-sm text-muted-foreground">
                登录后即可查看积分余额、套餐信息和使用记录
              </p>
              <Link
                href="/user/login"
                className="inline-flex items-center justify-center rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background transition-colors hover:bg-foreground/90 w-full"
              >
                立即登录
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-10">
      <div className="mx-auto max-w-6xl">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-foreground">积分管理</h1>
          <p className="text-sm text-muted-foreground">
            查看积分余额、充值积分与管理套餐
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-[240px_1fr]">
          <aside className="hidden lg:block">
            <UserSidebar className="sticky top-24" />
          </aside>

          <div className="space-y-6">
            <UserHeader user={user} />

            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
              <Card className="border-border/40 bg-card">
                <CardContent className="p-5">
                  <div className="flex items-center gap-2 text-muted-foreground text-sm mb-2">
                    <Zap className="h-4 w-4" />
                    积分余额
                  </div>
                  <div className="text-3xl font-bold text-foreground">
                    {user.credits}
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/40 bg-card">
                <CardContent className="p-5">
                  <div className="flex items-center gap-2 text-muted-foreground text-sm mb-2">
                    <Crown className="h-4 w-4" />
                    当前套餐
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-foreground">
                      {planLabels[user.plan]}
                    </span>
                    <Badge variant="secondary" className="bg-foreground text-background border-0">
                      {user.plan === "enterprise"
                        ? "不限"
                        : user.plan === "pro"
                        ? "50,000 次/月"
                        : "1,000 次/月"}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/40 bg-card">
                <CardContent className="p-5">
                  <div className="flex items-center gap-2 text-muted-foreground text-sm mb-2">
                    <Calendar className="h-4 w-4" />
                    VIP 到期
                  </div>
                  <div className="font-medium text-foreground">
                    {user.vipExpiresAt
                      ? new Date(user.vipExpiresAt).toLocaleDateString("zh-CN")
                      : "未开通"}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="border-border/40 bg-card">
              <CardHeader>
                <CardTitle className="text-base text-foreground">
                  积分充值
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                {message && (
                  <div
                    className={`p-3 rounded-lg text-sm mb-4 ${
                      message.includes("成功")
                        ? "bg-green-500/10 text-green-600"
                        : "bg-destructive/10 text-destructive"
                    }`}
                  >
                    {message}
                  </div>
                )}
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                  {creditPacks.map((item) => (
                    <Card
                      key={item.id}
                      className="border-border/40 bg-secondary/30 hover:bg-secondary/50 transition-colors"
                    >
                      <CardContent className="p-4 flex flex-col items-center text-center gap-2">
                        <div className="text-lg font-bold text-foreground">
                          {item.amount} 积分
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {formatPrice(item.price)}
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          className="w-full"
                          disabled={payingPack === item.id}
                          onClick={() => handleRecharge(item.id)}
                        >
                          {payingPack === item.id ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            "充值"
                          )}
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Separator />

            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="text-sm text-muted-foreground">
                升级 VIP 可获得更高 QPS 和更多调用额度
              </div>
              <div className="flex items-center gap-2">
                <Link
                  href="/user/orders"
                  className="inline-flex items-center justify-center rounded-lg border border-border bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-muted gap-2"
                >
                  <Receipt className="h-4 w-4" />
                  订单记录
                </Link>
                <Link
                  href="/user/vip"
                  className="inline-flex items-center justify-center rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background transition-colors hover:bg-foreground/90 gap-2"
                >
                  查看 VIP 套餐
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
