import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "个人中心 - IPcesu 工具站",
  description: "查看账户信息、积分余额、套餐状态，进行积分充值与订单管理。",
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
