import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "账户设置 - IPcesu 工具站",
  description: "管理您的账户昵称、密码与其他偏好设置。",
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
