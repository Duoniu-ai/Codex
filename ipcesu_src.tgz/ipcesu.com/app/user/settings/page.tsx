"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { UserSidebar } from "@/components/user/user-sidebar";
import { UserHeader } from "@/components/user/user-header";
import { Loader2, User, Lock, Bell, Shield, Save } from "lucide-react";
import type { UserPlan } from "@/lib/user";

interface UserInfo {
  id: string;
  email: string;
  credits: number;
  plan: UserPlan;
  vipExpiresAt: string | null;
  createdAt: string;
}

export default function SettingsPage() {
  const router = useRouter();
  const [mounted, setMounted] = useState(false);
  const [user, setUser] = useState<UserInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [nickname, setNickname] = useState("");
  const [savingNickname, setSavingNickname] = useState(false);
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [savingPassword, setSavingPassword] = useState(false);
  const [message, setMessage] = useState<{ text: string; type: "success" | "error" }>({
    text: "",
    type: "success",
  });

  useEffect(() => {
    setMounted(true);
    setLoading(true);
    fetch("/api/auth/me", { credentials: "include" })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data?.user) {
          setUser(data.user);
          const stored = localStorage.getItem(`ipcesu:nickname:${data.user.email}`);
          setNickname(stored || data.user.email.split("@")[0]);
        }
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const showMessage = (text: string, type: "success" | "error") => {
    setMessage({ text, type });
    setTimeout(() => setMessage({ text: "", type }), 4000);
  };

  const handleSaveNickname = async () => {
    if (!user) return;
    if (!nickname.trim()) {
      showMessage("昵称不能为空", "error");
      return;
    }
    setSavingNickname(true);
    localStorage.setItem(`ipcesu:nickname:${user.email}`, nickname.trim());
    setTimeout(() => {
      setSavingNickname(false);
      showMessage("昵称已保存", "success");
      router.refresh();
    }, 400);
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    if (passwordForm.newPassword.length < 6) {
      showMessage("新密码长度至少为 6 位", "error");
      return;
    }
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      showMessage("两次输入的新密码不一致", "error");
      return;
    }

    setSavingPassword(true);
    try {
      const res = await fetch("/api/user/password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          currentPassword: passwordForm.currentPassword,
          newPassword: passwordForm.newPassword,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        showMessage(data.error || "密码修改失败", "error");
      } else {
        showMessage("密码已修改，请使用新密码登录", "success");
        setPasswordForm({ currentPassword: "", newPassword: "", confirmPassword: "" });
      }
    } catch {
      showMessage("网络错误，请稍后重试", "error");
    } finally {
      setSavingPassword(false);
    }
  };

  if (!mounted || loading) {
    return (
      <div className="container mx-auto px-4 py-16 text-center text-muted-foreground">
        <Loader2 className="h-6 w-6 animate-spin mx-auto" />
        <div className="mt-2">加载中...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-md mx-auto text-center">
          <Card className="border-border/40 bg-card">
            <CardContent className="p-8 space-y-4">
              <UserIcon className="h-12 w-12 mx-auto text-muted-foreground" />
              <h1 className="text-xl font-bold text-foreground">请先登录</h1>
              <p className="text-sm text-muted-foreground">
                登录后即可管理账户设置
              </p>
              <Link
                href="/user/login"
                className="inline-flex items-center justify-center rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background transition-colors hover:bg-foreground/90 w-full"
              >
                立即登录
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-10">
      <div className="mx-auto max-w-6xl">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-foreground">账户设置</h1>
          <p className="text-sm text-muted-foreground">
            管理昵称、密码与账户安全
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-[240px_1fr]">
          <aside className="hidden lg:block">
            <UserSidebar className="sticky top-24" />
          </aside>

          <div className="space-y-6">
            <UserHeader user={user} />

            {message.text && (
              <div
                className={`rounded-lg p-3 text-sm ${
                  message.type === "success"
                    ? "bg-green-500/10 text-green-600"
                    : "bg-destructive/10 text-destructive"
                }`}
              >
                {message.text}
              </div>
            )}

            <Card className="border-border/40 bg-card">
              <CardHeader>
                <CardTitle className="text-base text-foreground flex items-center gap-2">
                  <UserIcon className="h-4 w-4" />
                  基本资料
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0 space-y-4">
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="email">邮箱</Label>
                    <Input
                      id="email"
                      value={user.email}
                      disabled
                      className="bg-secondary/50 border-border/50"
                    />
                    <p className="text-xs text-muted-foreground">
                      邮箱地址不可修改
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="nickname">昵称</Label>
                    <div className="flex gap-2">
                      <Input
                        id="nickname"
                        value={nickname}
                        onChange={(e) => setNickname(e.target.value)}
                        placeholder="设置您的昵称"
                        className="bg-secondary/50 border-border/50"
                      />
                      <Button
                        onClick={handleSaveNickname}
                        disabled={savingNickname}
                        className="shrink-0"
                      >
                        {savingNickname ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <>
                            <Save className="h-4 w-4 mr-1.5" />
                            保存
                          </>
                        )}
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      昵称将显示在导航栏与个人中心
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border/40 bg-card">
              <CardHeader>
                <CardTitle className="text-base text-foreground flex items-center gap-2">
                  <Lock className="h-4 w-4" />
                  修改密码
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <form onSubmit={handleChangePassword} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="currentPassword">当前密码</Label>
                    <Input
                      id="currentPassword"
                      type="password"
                      value={passwordForm.currentPassword}
                      onChange={(e) =>
                        setPasswordForm((prev) => ({
                          ...prev,
                          currentPassword: e.target.value,
                        }))
                      }
                      placeholder="请输入当前密码"
                      className="bg-secondary/50 border-border/50"
                    />
                  </div>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="newPassword">新密码</Label>
                      <Input
                        id="newPassword"
                        type="password"
                        value={passwordForm.newPassword}
                        onChange={(e) =>
                          setPasswordForm((prev) => ({
                            ...prev,
                            newPassword: e.target.value,
                          }))
                        }
                        placeholder="至少 6 位"
                        className="bg-secondary/50 border-border/50"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword">确认新密码</Label>
                      <Input
                        id="confirmPassword"
                        type="password"
                        value={passwordForm.confirmPassword}
                        onChange={(e) =>
                          setPasswordForm((prev) => ({
                            ...prev,
                            confirmPassword: e.target.value,
                          }))
                        }
                        placeholder="再次输入新密码"
                        className="bg-secondary/50 border-border/50"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end">
                    <Button
                      type="submit"
                      disabled={savingPassword}
                      className="bg-foreground hover:bg-foreground/90 text-background"
                    >
                      {savingPassword ? (
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      ) : (
                        <Lock className="h-4 w-4 mr-2" />
                      )}
                      {savingPassword ? "修改中..." : "修改密码"}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>

            <Card className="border-border/40 bg-card">
              <CardHeader>
                <CardTitle className="text-base text-foreground flex items-center gap-2">
                  <Shield className="h-4 w-4" />
                  账户安全
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-3">
                  <div className="flex items-center justify-between rounded-lg border border-border/40 p-4">
                    <div className="flex items-center gap-3">
                      <Bell className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <div className="text-sm font-medium text-foreground">
                          登录通知
                        </div>
                        <div className="text-xs text-muted-foreground">
                          新设备登录时发送邮件提醒
                        </div>
                      </div>
                    </div>
                    <span className="text-xs text-muted-foreground">即将上线</span>
                  </div>
                  <div className="flex items-center justify-between rounded-lg border border-border/40 p-4">
                    <div className="flex items-center gap-3">
                      <Shield className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <div className="text-sm font-medium text-foreground">
                          两步验证
                        </div>
                        <div className="text-xs text-muted-foreground">
                          通过 Authenticator 增强账户安全
                        </div>
                      </div>
                    </div>
                    <span className="text-xs text-muted-foreground">即将上线</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

function UserIcon({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  );
}
