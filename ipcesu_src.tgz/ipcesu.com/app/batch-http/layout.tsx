import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "批量 HTTP(S)",
  "多目标批量 HTTP(S) 可用性检测",
  "batch",
  "/batch-http",
);

export default function BatchHttpLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
