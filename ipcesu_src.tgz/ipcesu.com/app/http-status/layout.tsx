import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "HTTP 状态检测",
  "批量 URL 状态码检测",
  "analysis",
  "/http-status",
);

export default function HttpStatusLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
