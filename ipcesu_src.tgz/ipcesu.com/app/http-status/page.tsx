"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { CheckCircle } from "lucide-react";

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "正常", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "跳转", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "异常", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="HTTP 状态检测"
      description="批量 URL 状态码检测"
      icon={CheckCircle}
      tips={[
        "每行输入一个 URL，支持同时检测多个链接。",
        "可识别 200、301、404、500 等常见状态码。",
        "演示数据随机生成，仅用于功能展示。",
      ]}
      inputs={[
        { id: "urls", label: "URL 列表（每行一个）", type: "textarea", placeholder: "https://example.com\nhttps://example.com/about", rows: 5 },
      ]}
      onRun={async (values) => {
        await new Promise((r) => setTimeout(r, 700 + Math.floor(Math.random() * 500)));
        const list = values.urls.split("\n").map((u) => u.trim()).filter(Boolean);
        const statuses = [200, 200, 301, 404, 500];
        const results = list.map((url) => {
          const code = statuses[Math.floor(Math.random() * statuses.length)];
          const time = (50 + Math.random() * 300).toFixed(0);
          return { url, code, time };
        });
        const ok = results.filter((r) => r.code === 200).length;
        const error = results.filter((r) => r.code >= 400).length;
        const redirect = results.filter((r) => r.code >= 300 && r.code < 400).length;
        return { total: results.length, ok, redirect, error, results };
      }}
      renderResult={(result) => {
        const data = result as {
          total: number;
          ok: number;
          redirect: number;
          error: number;
          results: { url: string; code: number; time: string }[];
        };
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">总计</div><div className="text-2xl font-semibold">{data.total}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">正常</div><div className="text-2xl font-semibold text-green-700">{data.ok}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">跳转</div><div className="text-2xl font-semibold text-amber-700">{data.redirect}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">异常</div><div className="text-2xl font-semibold text-red-700">{data.error}</div></CardContent></Card>
            </div>
            <Card>
              <CardHeader>
                <CardTitle>检测结果</CardTitle>
                <CardDescription>URL 状态码与响应时间</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>URL</TableHead>
                      <TableHead>状态码</TableHead>
                      <TableHead>响应时间</TableHead>
                      <TableHead>结果</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.results.map((item, idx) => {
                      const s = item.code === 200 ? "pass" : item.code >= 400 ? "risk" : "warn";
                      return (
                        <TableRow key={idx}>
                          <TableCell className="whitespace-normal max-w-xs break-all">{item.url}</TableCell>
                          <TableCell>{item.code}</TableCell>
                          <TableCell>{item.time} ms</TableCell>
                          <TableCell>{statusBadge(s)}</TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}