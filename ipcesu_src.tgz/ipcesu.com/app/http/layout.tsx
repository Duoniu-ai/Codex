import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "HTTP 检测",
  "网站状态码与响应头检测",
  "speed",
  "/http",
);

export default function HttpLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
