"use client";

import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Globe, ArrowRight, Code, Clock, Server } from "lucide-react";

interface RedirectHop {
  url: string;
  status: number;
  statusText: string;
  location?: string;
}

interface HttpResult {
  url: string;
  finalUrl: string;
  statusCode: number;
  statusText: string;
  headers: Record<string, string>;
  redirectChain: RedirectHop[];
  redirectCount: number;
  bodyPreview: string;
  contentType: string | null;
  contentLength: number | null;
  totalTime: number;
}

export default function HttpPage() {
  return (
    <Suspense fallback={<HttpPageSkeleton />}>
      <HttpPageForm />
    </Suspense>
  );
}

function HttpPageSkeleton() {
  return (
    <ToolPageLayout
      title="HTTP 检测"
      description="检测网站 HTTP 状态码、响应头、跳转链和响应内容预览"
      icon={Globe}
      tips={[
        "输入 URL 或域名即可检测 HTTP 响应信息",
        "自动追踪 301/302 跳转链",
        "展示完整响应头，便于排查服务器配置",
        "返回前 2000 字符的响应体预览",
      ]}
    >
      <div className="space-y-3">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
      </div>
    </ToolPageLayout>
  );
}

function HttpPageForm() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get("q") || "";

  const [target, setTarget] = useState(initialQuery);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<HttpResult | null>(null);
  const [error, setError] = useState("");

  const handleCheck = async () => {
    if (!target.trim()) return;

    setLoading(true);
    setError("");
    setResult(null);

    try {
      const res = await fetch("/api/http", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ target: target.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "检测失败");
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "检测失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ToolPageLayout
      title="HTTP 检测"
      description="检测网站 HTTP 状态码、响应头、跳转链和响应内容预览"
      icon={Globe}
      tips={[
        "输入 URL 或域名即可检测 HTTP 响应信息",
        "自动追踪 301/302 跳转链",
        "展示完整响应头，便于排查服务器配置",
        "返回前 2000 字符的响应体预览",
      ]}
    >
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <Input
          value={target}
          onChange={(e) => setTarget(e.target.value)}
          placeholder="例如：baidu.com 或 https://example.com"
          className="flex-1 bg-secondary/50 border-border/50"
        />
        <Button
          onClick={handleCheck}
          disabled={loading}
          className="bg-foreground hover:bg-foreground/90 text-background"
        >
          {loading ? "检测中..." : "开始检测"}
        </Button>
      </div>

      {error && (
        <div className="p-4 rounded-lg bg-destructive/10 text-destructive text-sm mb-6">
          {error}
        </div>
      )}

      {loading && (
        <div className="space-y-3">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
        </div>
      )}

      {result && !loading && (
        <div className="space-y-4 animate-fade-in-up">
          <div className="flex flex-wrap items-center gap-3 mb-4">
            <Badge
              variant={result.statusCode < 400 ? "default" : "destructive"}
              className={
                result.statusCode < 400
                  ? "bg-green-500/15 text-green-600 hover:bg-green-500/20 border-0"
                  : ""
              }
            >
              {result.statusCode} {result.statusText}
            </Badge>
            <span className="text-sm text-muted-foreground flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" />
              耗时 {result.totalTime} ms
            </span>
            <span className="text-sm text-muted-foreground flex items-center gap-1">
              <ArrowRight className="h-3.5 w-3.5" />
              跳转 {result.redirectCount} 次
            </span>
          </div>

          <Card className="border-0 bg-foreground text-background">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-3 text-background/70 text-sm">
                <Globe className="h-4 w-4" />
                最终地址
              </div>
              <div className="text-lg font-medium font-mono break-all">
                {result.finalUrl}
              </div>
              <div className="text-sm text-background/60 mt-2">
                原始地址：{result.url}
              </div>
            </CardContent>
          </Card>

          {result.redirectChain.length > 1 && (
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3 text-muted-foreground text-sm">
                  <ArrowRight className="h-4 w-4 text-foreground" />
                  跳转链
                </div>
                <div className="space-y-2">
                  {result.redirectChain.map((hop, index) => (
                    <div
                      key={index}
                      className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3 text-sm"
                    >
                      <Badge variant="secondary" className="w-fit">
                        {hop.status}
                      </Badge>
                      <span className="font-mono text-foreground break-all">
                        {hop.url}
                      </span>
                      {hop.location && (
                        <span className="text-muted-foreground text-xs font-mono break-all">
                          → {hop.location}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-3 text-muted-foreground text-sm">
                <Server className="h-4 w-4 text-foreground" />
                响应头
              </div>
              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-1/3">名称</TableHead>
                      <TableHead>值</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Object.entries(result.headers).map(([key, value]) => (
                      <TableRow key={key}>
                        <TableCell className="font-medium font-mono text-xs">
                          {key}
                        </TableCell>
                        <TableCell className="font-mono text-xs break-all">
                          {value}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-3 text-muted-foreground text-sm">
                <Code className="h-4 w-4 text-foreground" />
                响应体预览
              </div>
              <pre className="text-xs font-mono p-3 rounded-lg bg-secondary/50 overflow-auto max-h-80 text-foreground break-all whitespace-pre-wrap">
                {result.bodyPreview || "（无响应体）"}
              </pre>
            </CardContent>
          </Card>
        </div>
      )}
    </ToolPageLayout>
  );
}