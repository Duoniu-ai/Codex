import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "TCPing",
  "TCP 端口连通性检测",
  "network",
  "/tcping",
);

export default function TcpingLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
