import type { MetadataRoute } from "next";
import { tools, aiTools } from "@/lib/tools";
import { newsData } from "@/lib/news-data";
import { SITE_URL } from "@/lib/seo";

export default function sitemap(): MetadataRoute.Sitemap {
  const staticRoutes = [
    "",
    "/tools",
    "/ai-tools",
    "/article",
    "/monitor",
    "/api-docs",
    "/user/login",
    "/user/register",
  ];

  const staticEntries: MetadataRoute.Sitemap = staticRoutes.map((route) => ({
    url: `${SITE_URL}${route}`,
    lastModified: new Date(),
    changeFrequency: "daily",
    priority: route === "" ? 1 : 0.8,
  }));

  const toolEntries: MetadataRoute.Sitemap = tools.map((tool) => ({
    url: `${SITE_URL}${tool.href}`,
    lastModified: new Date(),
    changeFrequency: "weekly",
    priority: 0.7,
  }));

  const aiToolEntries: MetadataRoute.Sitemap = aiTools.map((tool) => ({
    url: `${SITE_URL}${tool.href}`,
    lastModified: new Date(),
    changeFrequency: "weekly",
    priority: 0.6,
  }));

  const articleEntries: MetadataRoute.Sitemap = newsData.map((item) => ({
    url: `${SITE_URL}/article/${item.id}`,
    lastModified: new Date(item.date),
    changeFrequency: "monthly",
    priority: 0.6,
  }));

  return [...staticEntries, ...toolEntries, ...aiToolEntries, ...articleEntries];
}
