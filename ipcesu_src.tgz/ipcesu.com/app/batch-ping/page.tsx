"use client";

import { useState, Suspense } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Layers, Server, CheckCircle, XCircle, Gauge, Percent } from "lucide-react";

interface PingItem {
  target: string;
  resolvedIp: string;
  status: "success" | "timeout";
  avgLatency: number;
  packetLoss: number;
}

interface BatchPingResult {
  total: number;
  success: number;
  failed: number;
  items: PingItem[];
}

export default function BatchPingPage() {
  return (
    <Suspense fallback={<BatchPingPageSkeleton />}>
      <BatchPingPageForm />
    </Suspense>
  );
}

function BatchPingPageSkeleton() {
  return (
    <ToolPageLayout
      title="批量 Ping"
      description="多目标批量 Ping 检测"
      icon={Layers}
      tips={[
        "每行输入一个目标域名或 IP 地址，支持批量检测。",
        "最多建议一次性检测 50 个目标。",
        "结果包含每个目标的解析 IP、延迟和丢包率。",
        "批量检测为模拟并发执行，结果仅供演示参考。",
      ]}
    >
      <div className="space-y-3">
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    </ToolPageLayout>
  );
}

function BatchPingPageForm() {
  const [targets, setTargets] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<BatchPingResult | null>(null);
  const [error, setError] = useState("");

  const handleTest = async () => {
    const lines = targets.split("\n").map((line) => line.trim()).filter(Boolean);
    if (lines.length === 0) {
      setError("请至少输入一个目标地址");
      return;
    }

    setLoading(true);
    setError("");
    setResult(null);

    try {
      await new Promise((r) => setTimeout(r, 800 + Math.random() * 400));
      const items: PingItem[] = lines.slice(0, 20).map((target) => {
        const isSuccess = Math.random() > 0.15;
        return {
          target,
          resolvedIp: isSuccess
            ? `${Math.floor(Math.random() * 223) + 1}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`
            : "--",
          status: isSuccess ? "success" : "timeout",
          avgLatency: isSuccess ? 15 + Math.random() * 80 : 0,
          packetLoss: isSuccess ? Math.random() * 5 : 100,
        };
      });
      const data: BatchPingResult = {
        total: items.length,
        success: items.filter((i) => i.status === "success").length,
        failed: items.filter((i) => i.status === "timeout").length,
        items,
      };
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "检测失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ToolPageLayout
      title="批量 Ping"
      description="多目标批量 Ping 检测"
      icon={Layers}
      tips={[
        "每行输入一个目标域名或 IP 地址，支持批量检测。",
        "最多建议一次性检测 50 个目标。",
        "结果包含每个目标的解析 IP、延迟和丢包率。",
        "批量检测为模拟并发执行，结果仅供演示参考。",
      ]}
    >
      <Card className="border-border/40 bg-card shadow-sm">
        <CardContent className="p-5 space-y-5">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">目标列表</label>
            <textarea
              value={targets}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setTargets(e.target.value)}
              placeholder="例如：&#10;baidu.com&#10;8.8.8.8&#10;qq.com"
              rows={6}
              className="w-full rounded-lg border border-input bg-secondary/50 px-3 py-2 text-sm placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 outline-none resize-none font-mono"
            />
            <p className="text-xs text-muted-foreground">
              每行一个目标，最多 20 个
            </p>
          </div>
          <Button
            onClick={handleTest}
            disabled={loading}
            className="bg-foreground hover:bg-foreground/90 text-background"
          >
            {loading ? "检测中..." : "开始批量检测"}
          </Button>
        </CardContent>
      </Card>

      {error && (
        <div className="p-4 rounded-lg bg-destructive/10 text-destructive text-sm">
          {error}
        </div>
      )}

      {loading && (
        <Card className="border-border/40 bg-card shadow-sm">
          <CardContent className="p-5 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
            </div>
            <Skeleton className="h-48 w-full" />
          </CardContent>
        </Card>
      )}

      {result && !loading && (
        <div className="space-y-4 animate-fade-in-up">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Layers className="h-4 w-4 text-foreground" />
                  检测总数
                </div>
                <div className="font-medium text-foreground">{result.total}</div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  正常
                </div>
                <div className="font-medium text-foreground">{result.success}</div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <XCircle className="h-4 w-4 text-red-600" />
                  超时
                </div>
                <div className="font-medium text-foreground">{result.failed}</div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-3 text-muted-foreground text-sm">
                <Server className="h-4 w-4 text-foreground" />
                检测结果
              </div>
              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>目标</TableHead>
                      <TableHead>解析 IP</TableHead>
                      <TableHead>状态</TableHead>
                      <TableHead>平均延迟</TableHead>
                      <TableHead>丢包率</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {result.items.map((item, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium text-foreground break-all">
                          {item.target}
                        </TableCell>
                        <TableCell className="font-mono text-foreground break-all">
                          {item.resolvedIp}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={
                              item.status === "success"
                                ? "bg-green-500/15 text-green-600 border-0"
                                : "bg-red-500/15 text-red-600 border-0"
                            }
                          >
                            {item.status === "success" ? "正常" : "超时"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-foreground">
                          {item.status === "success"
                            ? `${item.avgLatency.toFixed(2)} ms`
                            : "--"}
                        </TableCell>
                        <TableCell className="text-foreground">
                          {item.packetLoss.toFixed(0)} %
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </ToolPageLayout>
  );
}
