import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "批量 Ping",
  "多目标批量 Ping 检测",
  "batch",
  "/batch-ping",
);

export default function BatchPingLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
