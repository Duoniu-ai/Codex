"use client";

import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { Button, buttonVariants } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Globe, MapPin, Radio, Clock, Building2, Copy, Check, Search, Shield, AlertTriangle, Activity, Server, Link2, History, Network, Clock3 } from "lucide-react";
import type { IpInfo } from "@/lib/ip-data";

const flagEmoji: Record<string, string> = {
  CN: "🇨🇳",
  US: "🇺🇸",
  SG: "🇸🇬",
  HK: "🇭🇰",
  JP: "🇯🇵",
  CA: "🇨🇦",
  DE: "🇩🇪",
  FR: "🇫🇷",
  LO: "🏠",
};

export default function IpQueryPage() {
  return (
    <Suspense fallback={<IpQuerySkeleton />}>
      <IpQueryForm />
    </Suspense>
  );
}

function IpQuerySkeleton() {
  return (
    <main className="container mx-auto px-4 py-10">
      <div className="max-w-6xl mx-auto">
        <header className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Globe className="h-7 w-7 text-foreground" />
            <h1 className="text-2xl font-bold text-foreground">IP 查询</h1>
          </div>
          <p className="text-muted-foreground text-sm">
            查询 IP 地址或域名的地理位置、运营商、时区、评分、风险等详细信息
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <Skeleton className="h-48 lg:col-span-2" />
          <Skeleton className="h-48" />
        </div>
        <div className="space-y-4">
          <Skeleton className="h-48 w-full" />
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Skeleton className="h-24" />
            <Skeleton className="h-24" />
            <Skeleton className="h-24" />
            <Skeleton className="h-24" />
          </div>
        </div>
      </div>
    </main>
  );
}

function IpQueryForm() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get("q") || "";

  const [target, setTarget] = useState(initialQuery);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<(IpInfo & { queriedTarget?: string }) | null>(null);
  const [error, setError] = useState("");

  const handleQuery = async (queryTarget?: string) => {
    const q = queryTarget ?? target;
    if (!q.trim()) return;

    setLoading(true);
    setError("");
    setResult(null);

    try {
      const res = await fetch("/api/tools/ip", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ target: q.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "查询失败");
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "查询失败");
    } finally {
      setLoading(false);
    }
  };

  const handleMyIp = async () => {
    setLoading(true);
    setError("");
    setResult(null);
    try {
      const res = await fetch("/api/ip-info");
      const data = await res.json();
      setTarget(data.ip);
      setResult({ ...data, queriedTarget: data.ip });
    } catch {
      setError("获取当前 IP 失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="container mx-auto px-4 py-10">
      <div className="max-w-6xl mx-auto">
        <header className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Globe className="h-7 w-7 text-foreground" />
            <h1 className="text-2xl font-bold text-foreground">IP 查询</h1>
          </div>
          <p className="text-muted-foreground text-sm">
            查询 IP 地址或域名的地理位置、运营商、时区、评分、风险等详细信息
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          {/* 左侧查询卡片 */}
          <Card className="lg:col-span-2 border-border bg-card shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-base text-foreground">IP地址 / 域名查询</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    value={target}
                    onChange={(e) => setTarget(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleQuery()}
                    placeholder="例如：8.8.8.8 或 google.com"
                    className="pl-9 h-11 bg-secondary/50 border-border/50"
                  />
                </div>
                <Button
                  onClick={() => handleQuery()}
                  disabled={loading}
                  className="bg-foreground hover:bg-foreground/90 text-background h-11"
                >
                  {loading ? "查询中..." : "查询"}
                </Button>
                <Button variant="outline" onClick={handleMyIp} disabled={loading} className="h-11">
                  我的 IP
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* 右侧最近查询 / 使用说明 */}
          <Card className="border-border bg-card shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-base text-foreground">使用说明</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <ul className="space-y-3">
                {[
                  "支持 IP 地址查询（IPv4 和 IPv6）",
                  "支持域名查询，自动解析域名获取 IP 地址",
                  "展示 IP 评分、ASN、运营商、风险指标等多维数据",
                  "全球主要地区延迟数据仅供参考",
                  "查询结果仅供参考，实际位置可能存在偏差",
                ].map((tip, index) => (
                  <li key={index} className="text-sm text-muted-foreground flex items-start gap-2">
                    <span className="text-foreground mt-0.5">•</span>
                    {tip}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>

        {error && (
          <div className="p-4 rounded-lg bg-destructive/10 text-destructive text-sm mb-6">
            {error}
          </div>
        )}

        {loading && (
          <div className="space-y-4">
            <Skeleton className="h-48 w-full" />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
            </div>
          </div>
        )}

        {result && !loading && <IpResult result={result} />}
      </div>
    </main>
  );
}

function IpResult({ result }: { result: IpInfo & { queriedTarget?: string } }) {
  const flag = flagEmoji[result.countryCode] || "🌐";

  return (
    <div className="space-y-5 animate-fade-in-up">
      {/* 顶部深色结果卡 */}
      <div className="rounded-xl overflow-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white shadow-lg p-6 md:p-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <span className="text-3xl">{flag}</span>
              <div>
                <div className="text-sm text-white/70">IP 地址</div>
                <div className="text-2xl md:text-3xl font-bold font-mono tracking-tight flex items-center gap-3">
                  {result.ip}
                  <CopyButton text={result.ip} />
                </div>
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-white/90">
                <MapPin className="h-4 w-4 text-white/70" />
                <span>{result.country} {result.region} {result.city}</span>
              </div>
              <div className="flex items-center gap-2 text-white/90">
                <Radio className="h-4 w-4 text-white/70" />
                <span>{result.isp}</span>
              </div>
            </div>
          </div>
          <div className="md:text-right space-y-3">
            <div>
              <div className="text-sm text-white/70">经纬度</div>
              <div className="font-mono">{result.lat.toFixed(5)}, {result.lng.toFixed(5)}</div>
            </div>
            <div>
              <div className="text-sm text-white/70">时区</div>
              <div className="flex items-center gap-2 md:justify-end">
                <Clock3 className="h-4 w-4 text-white/70" />
                {result.timezone}
              </div>
            </div>
            <a
              href={`https://map.baidu.com/search/${result.lat},${result.lng}`}
              target="_blank"
              rel="noopener noreferrer"
              className={cn(
                buttonVariants({ variant: "secondary" }),
                "mt-2 bg-white text-slate-900 hover:bg-white/90"
              )}
            >
              <MapPin className="h-4 w-4 mr-1" />
              在地图中查看
            </a>
          </div>
        </div>
      </div>

      {/* 四个关键信息卡 */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <KeyInfoCard label="国家/地区" value={`${flag} ${result.country}`} />
        <KeyInfoCard label="省/市" value={result.region} />
        <KeyInfoCard label="城市" value={result.city} />
        <KeyInfoCard label="运营商" value={result.isp} />
      </div>

      {/* 使用场景 + ASN */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <InfoCard title="使用场景 / 类型" icon={Activity}>
          <DetailRow label="IP 原生性" value={result.nativeIp}>
            {result.tags.map((tag, i) => (
              <Badge key={i} variant="secondary" className="ml-2 text-xs">{tag}</Badge>
            ))}
          </DetailRow>
          <DetailRow label="运营商类型" value={result.operatorType} />
          <DetailRow label="人机流量" value={result.trafficType} />
          <DetailRow label="ASN 归属" value={result.asnOrg} />
          <DetailRow label="企业信息" value={result.company} />
          <DetailRow label="服务商" value={result.provider} />
        </InfoCard>

        <InfoCard title="ASN / 运营商" icon={Server}>
          <DetailRow label="ASN" value={result.asn} />
          <DetailRow label="CIDR" value={result.cidr} />
          <DetailRow label="ASN 自报类型" value={result.asnType} />
          <DetailRow label="IP 范围" value={result.ipRange} />
          <DetailRow label="ASN IPv4 总量" value={result.asnIpv4Count} />
          <DetailRow label="预估带宽" value={result.bandwidth} />
          <DetailRow label="ASN 注册日期" value={result.asnRegistered} />
        </InfoCard>
      </div>

      {/* 技术指标 + IP情报 + 风险检测 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <InfoCard title="技术指标" icon={Radio}>
          <DetailRow label="Bogon / 广播" value={result.bogon} status="success" />
          <DetailRow label="反向 DNS" value={result.reverseDns || "-"} />
          <DetailRow label="开放端口" value={result.openPorts.length ? result.openPorts.join(", ") : "-"} />
        </InfoCard>

        <InfoCard title="IP 情报（威胁指标）" icon={AlertTriangle}>
          <DetailRow label="风险标记" value={result.riskFlag} status={result.riskFlag.includes("风险") ? "danger" : "success"} />
          <DetailRow label="滥用等级" value={result.abuseLevel} status={result.abuseLevelColor as "green" | "yellow" | "red"} />
          <DetailRow label="HTTP 蜜罐黑名单" value={result.blacklist} status={result.blacklist === "纯净" ? "success" : "danger"} />
          <DetailRow label="RPKI 状态" value={result.rpki} status="success" />
        </InfoCard>

        <InfoCard title="风险深度检测" icon={Shield}>
          <DetailRow label="VPN" value={result.vpn} status={result.vpn === "未检测到" ? "success" : "danger"} />
          <DetailRow label="代理 (Proxy)" value={result.proxy} status={result.proxy === "未检测到" ? "success" : "danger"} />
          <DetailRow label="Tor" value={result.tor} status={result.tor === "未检测到" ? "success" : "danger"} />
          <DetailRow label="爬虫 / 机器人" value={result.robot} status={result.robot === "未检测到" ? "success" : "danger"} />
        </InfoCard>
      </div>

      {/* 全球延迟 */}
      {result.globalPing.length > 0 && (
        <InfoCard title="全球主要地区延迟测试" icon={Clock} action={<Link href="/ping" className="text-xs text-primary hover:underline">全球Ping →</Link>}>
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
            {result.globalPing.map((item, i) => (
              <div key={i} className="text-center p-3 rounded-lg bg-muted/50">
                <div className="text-lg mb-1">{flagEmoji[item.countryCode] || "🌐"}</div>
                <div className="text-xs text-muted-foreground">{item.region}</div>
                <div className={`text-sm font-semibold ${latencyColor(item.color)}`}>{item.latency}</div>
              </div>
            ))}
          </div>
        </InfoCard>
      )}

      {/* 地理位置多源对比 */}
      {result.geoSources.length > 0 && (
        <InfoCard title="地理位置（多源对比）" icon={MapPin}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border/50 text-muted-foreground">
                  <th className="text-left font-medium py-2">数据源</th>
                  <th className="text-left font-medium py-2">国家/地区</th>
                  <th className="text-left font-medium py-2">城市</th>
                  <th className="text-left font-medium py-2">经纬度</th>
                </tr>
              </thead>
              <tbody>
                {result.geoSources.map((s, i) => (
                  <tr key={i} className="border-b border-border/30 last:border-0">
                    <td className="py-2">{s.source}</td>
                    <td className="py-2">{flagEmoji[s.countryCode] || "🌐"} {s.country}</td>
                    <td className="py-2">{s.region} {s.city}</td>
                    <td className="py-2 font-mono text-xs">{s.lat.toFixed(3)}, {s.lng.toFixed(3)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </InfoCard>
      )}

      {/* 关联域名 / 历史 / 邻居 */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <InfoCard title="关联域名" icon={Link2}>
          {result.relatedDomains.length > 0 ? (
            <div className="flex flex-wrap gap-2">
              {result.relatedDomains.map((d, i) => (
                <Badge key={i} variant="outline">{d}</Badge>
              ))}
            </div>
          ) : (
            <div className="text-sm text-muted-foreground">暂无数据</div>
          )}
        </InfoCard>

        <InfoCard title="位置历史" icon={History}>
          {result.locationHistory.length > 0 ? (
            <ul className="space-y-2 text-sm">
              {result.locationHistory.map((h, i) => (
                <li key={i} className="flex items-center justify-between">
                  <span className="text-muted-foreground">{h.date}</span>
                  <span>{flagEmoji[h.countryCode] || "🌐"} {h.country} {h.region} {h.city}</span>
                </li>
              ))}
            </ul>
          ) : (
            <div className="text-sm text-muted-foreground">暂无数据</div>
          )}
        </InfoCard>

        <InfoCard title="同机房 / 客户活跃" icon={Network}>
          {result.neighbors.length > 0 ? (
            <div className="flex flex-wrap gap-2">
              {result.neighbors.map((n, i) => (
                <Link key={i} href={`/ip?q=${encodeURIComponent(n)}`} className="text-sm font-mono text-primary hover:underline">{n}</Link>
              ))}
            </div>
          ) : (
            <div className="text-sm text-muted-foreground">暂无数据</div>
          )}
        </InfoCard>

        <InfoCard title="ASN 历史" icon={History}>
          {result.asnHistory.length > 0 ? (
            <ul className="space-y-2 text-sm">
              {result.asnHistory.map((h, i) => (
                <li key={i} className="flex items-center justify-between">
                  <span className="text-muted-foreground">{h.date}</span>
                  <span className="font-mono">{h.asn}</span>
                </li>
              ))}
            </ul>
          ) : (
            <div className="text-sm text-muted-foreground">暂无数据</div>
          )}
        </InfoCard>
      </div>

      {/* 企业历史 */}
      {result.companyHistory.length > 0 && (
        <InfoCard title="企业历史" icon={Building2}>
          <ul className="space-y-2 text-sm">
            {result.companyHistory.map((h, i) => (
              <li key={i} className="flex items-center justify-between">
                <span className="text-muted-foreground">{h.date}</span>
                <span>{h.company}</span>
              </li>
            ))}
          </ul>
        </InfoCard>
      )}
    </div>
  );
}

function KeyInfoCard({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <Card className="border-border bg-card shadow-sm">
      <CardContent className="p-4">
        <div className="text-sm text-muted-foreground mb-1">{label}</div>
        <div className="text-lg font-semibold text-foreground truncate">{value}</div>
      </CardContent>
    </Card>
  );
}

function InfoCard({ title, icon: Icon, children, action }: { title: string; icon: React.ElementType; children: React.ReactNode; action?: React.ReactNode }) {
  return (
    <Card className="border-border bg-card shadow-sm">
      <CardHeader className="pb-3 flex flex-row items-center justify-between">
        <CardTitle className="text-base text-foreground flex items-center gap-2">
          <Icon className="h-4 w-4 text-primary" />
          {title}
        </CardTitle>
        {action}
      </CardHeader>
      <CardContent className="pt-0">{children}</CardContent>
    </Card>
  );
}

function DetailRow({ label, value, status, children }: { label: string; value: React.ReactNode; status?: "success" | "danger" | "green" | "yellow" | "red"; children?: React.ReactNode }) {
  const statusClass =
    status === "success" || status === "green"
      ? "text-emerald-600 dark:text-emerald-400"
      : status === "danger" || status === "red"
      ? "text-red-600 dark:text-red-400"
      : status === "yellow"
      ? "text-amber-600 dark:text-amber-400"
      : "text-foreground";

  return (
    <div className="flex items-center justify-between py-2 border-b border-border/30 last:border-0">
      <span className="text-sm text-muted-foreground">{label}</span>
      <div className="text-sm font-medium text-right flex items-center">
        <span className={statusClass}>{value}</span>
        {children}
      </div>
    </div>
  );
}

function latencyColor(color: string) {
  if (color === "green") return "text-emerald-600 dark:text-emerald-400";
  if (color === "yellow") return "text-amber-600 dark:text-amber-400";
  if (color === "red") return "text-red-600 dark:text-red-400";
  return "text-foreground";
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // ignore
    }
  };

  return (
    <Button variant="ghost" size="icon" onClick={copy} className="shrink-0 text-white hover:bg-white/20 h-8 w-8">
      {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
    </Button>
  );
}
