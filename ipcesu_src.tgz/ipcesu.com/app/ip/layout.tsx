import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "IP 查询",
  "IP 归属地查询",
  "network",
  "/ip",
);

export default function IpLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
