"use client";

import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import { Server, Clock } from "lucide-react";

interface DnsRecord {
  server: string;
  serverName: string;
  records: string[];
  responseTime: number;
}

interface DnsResult {
  domain: string;
  type: string;
  results: DnsRecord[];
}

const recordTypes = ["A", "AAAA", "CNAME", "MX", "NS", "TXT", "SOA"];

export default function DnsPage() {
  return (
    <Suspense fallback={<DnsPageSkeleton />}>
      <DnsPageForm />
    </Suspense>
  );
}

function DnsPageSkeleton() {
  return (
    <ToolPageLayout
      title="DNS 查询"
      description="查询域名 DNS 解析记录，支持多种记录类型"
      icon={Server}
      tips={[
        "DNS 查询用于获取域名的 DNS 解析记录",
        "支持多种 DNS 记录类型：A、AAAA、CNAME、MX、NS、TXT、SOA",
        "同时查询多个 DNS 服务器，对比解析结果",
        "包含国内主流 DNS（阿里、腾讯、114）和国际 DNS（Google、Cloudflare）",
      ]}
    >
      <div className="space-y-3">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
      </div>
    </ToolPageLayout>
  );
}

function DnsPageForm() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get("q") || "";

  const [domain, setDomain] = useState(initialQuery);
  const [type, setType] = useState("A");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<DnsResult | null>(null);
  const [error, setError] = useState("");

  const handleQuery = async () => {
    if (!domain.trim()) return;

    setLoading(true);
    setError("");
    setResult(null);

    try {
      const res = await fetch("/api/dns", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ domain: domain.trim(), type }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "查询失败");
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "查询失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ToolPageLayout
      title="DNS 查询"
      description="查询域名 DNS 解析记录，支持多种记录类型"
      icon={Server}
      tips={[
        "DNS 查询用于获取域名的 DNS 解析记录",
        "支持多种 DNS 记录类型：A、AAAA、CNAME、MX、NS、TXT、SOA",
        "同时查询多个 DNS 服务器，对比解析结果",
        "包含国内主流 DNS（阿里、腾讯、114）和国际 DNS（Google、Cloudflare）",
      ]}
    >
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <Input
          value={domain}
          onChange={(e) => setDomain(e.target.value)}
          placeholder="输入域名，例如：baidu.com"
          className="flex-1 bg-secondary/50 border-border/50"
        />
        <Select value={type} onValueChange={(value) => value && setType(value)}>
          <SelectTrigger className="w-full sm:w-32 bg-secondary/50 border-border/50">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {recordTypes.map((t) => (
              <SelectItem key={t} value={t}>
                {t}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button
          onClick={handleQuery}
          disabled={loading}
          className="bg-foreground hover:bg-foreground/90 text-background"
        >
          {loading ? "查询中..." : "查询"}
        </Button>
      </div>

      {error && (
        <div className="p-4 rounded-lg bg-destructive/10 text-destructive text-sm mb-6">
          {error}
        </div>
      )}

      {loading && (
        <div className="space-y-3">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
        </div>
      )}

      {result && !loading && (
        <div className="space-y-4 animate-fade-in-up">
          <div className="flex items-center gap-3 mb-4">
            <Badge variant="secondary" className="bg-foreground text-background hover:bg-foreground/90 border-0">
              {result.type} 记录
            </Badge>
            <span className="text-sm text-muted-foreground">
              域名：{result.domain}
            </span>
          </div>

          {result.results.map((record) => (
            <Card
              key={record.server}
              className="border-border/50 bg-card"
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Server className="h-4 w-4 text-foreground" />
                    <span className="font-medium text-foreground">{record.serverName}</span>
                    <span className="text-sm text-muted-foreground font-mono">
                      {record.server}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    {record.responseTime}ms
                  </div>
                </div>
                {record.records.length > 0 ? (
                  <div className="space-y-1">
                    {record.records.map((r, i) => (
                      <div
                        key={i}
                        className="text-sm font-mono p-2 rounded bg-secondary/50 break-all text-foreground"
                      >
                        {r}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-sm text-muted-foreground">无记录</div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </ToolPageLayout>
  );
}