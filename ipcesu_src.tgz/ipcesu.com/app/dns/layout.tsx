import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "DNS 查询",
  "域名解析记录查询",
  "network",
  "/dns",
);

export default function DnsLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
