import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "网站分析",
  "SEO、性能、安全综合评估",
  "analysis",
  "/website-analysis",
);

export default function WebsiteAnalysisLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
