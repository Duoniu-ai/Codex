"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { BarChart3 } from "lucide-react";

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "通过", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "提示", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "风险", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="网站分析"
      description="SEO、性能、安全综合评估"
      icon={BarChart3}
      tips={[
        "输入目标 URL 即可获取综合评分。",
        "评分涵盖 SEO、性能、安全与可用性维度。",
        "结果由本地模拟生成，仅用于演示参考。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      onRun={async () => {
        await new Promise((r) => setTimeout(r, 800 + Math.floor(Math.random() * 400)));
        return {
          score: Math.floor(70 + Math.random() * 26),
          metrics: [
            { label: "SEO 得分", value: `${Math.floor(75 + Math.random() * 21)}/100`, status: "pass" },
            { label: "性能得分", value: `${Math.floor(70 + Math.random() * 26)}/100`, status: Math.random() > 0.7 ? "warn" : "pass" },
            { label: "安全得分", value: `${Math.floor(80 + Math.random() * 16)}/100`, status: "pass" },
            { label: "可用性得分", value: `${Math.floor(85 + Math.random() * 11)}/100`, status: "pass" },
          ],
          checks: [
            { name: "HTTPS 已启用", status: Math.random() > 0.1 ? "pass" : "risk", detail: "站点已使用 HTTPS 加密传输" },
            { name: "Viewport 配置", status: Math.random() > 0.1 ? "pass" : "warn", detail: "已设置适合移动端的 viewport" },
            { name: "Sitemap", status: Math.random() > 0.3 ? "pass" : "warn", detail: "存在 sitemap.xml 文件" },
            { name: "H1 标签", status: Math.random() > 0.2 ? "pass" : "warn", detail: "页面包含唯一 H1 标题" },
          ],
        };
      }}
      renderResult={(result) => {
        const data = result as {
          score: number;
          metrics: { label: string; value: string; status: "pass" | "warn" | "risk" }[];
          checks: { name: string; status: "pass" | "warn" | "risk"; detail: string }[];
        };
        return (
          <div className="space-y-4">
            <Card className="border-l-4 border-l-foreground">
              <CardContent className="pt-6">
                <div className="text-sm text-muted-foreground">综合评分</div>
                <div className="text-3xl font-bold">{data.score}</div>
              </CardContent>
            </Card>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {data.metrics.map((m) => (
                <Card key={m.label}>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">{m.label}</span>
                      {statusBadge(m.status)}
                    </div>
                    <div className="text-xl font-semibold mt-1">{m.value}</div>
                  </CardContent>
                </Card>
              ))}
            </div>
            <Card>
              <CardHeader>
                <CardTitle>检测明细</CardTitle>
                <CardDescription>关键项目检查结果</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>检查项</TableHead>
                      <TableHead>状态</TableHead>
                      <TableHead>说明</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.checks.map((c) => (
                      <TableRow key={c.name}>
                        <TableCell>{c.name}</TableCell>
                        <TableCell>{statusBadge(c.status)}</TableCell>
                        <TableCell className="whitespace-normal">{c.detail}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}