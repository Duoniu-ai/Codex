"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Scan, Network, Server, Shield, CheckCircle, Lock } from "lucide-react";

interface PortItem {
  port: number;
  service: string;
  status: "open" | "closed";
}

interface PortscanResult {
  target: string;
  resolvedIp: string;
  total: number;
  openCount: number;
  closedCount: number;
  ports: PortItem[];
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="端口扫描"
      description="主机端口检测"
      icon={Scan}
      tips={[
        "输入主机地址，扫描常见端口开放情况。",
        "默认扫描 80、443、22、21、25、3306、3389 等端口。",
        "端口开放意味着服务正在监听，但需结合安全策略判断。",
        "请仅对自有或授权主机进行扫描。",
      ]}
      inputs={[
        {
          id: "target",
          label: "目标主机",
          type: "text",
          placeholder: "例如：baidu.com 或 192.168.1.1",
        },
        {
          id: "ports",
          label: "端口列表",
          type: "text",
          placeholder: "例如：80,443,22,3306",
          defaultValue: "80,443,22,21,25,3306,3389",
        },
      ]}
      onRun={async (values) => {
        await new Promise((r) => setTimeout(r, 800 + Math.random() * 400));
        const target = values.target.trim();
        const portList = values.ports
          .split(/[,，\s]+/)
          .map((p) => parseInt(p.trim(), 10))
          .filter((p) => !isNaN(p) && p > 0 && p <= 65535);
        const serviceMap: Record<number, string> = {
          21: "FTP",
          22: "SSH",
          25: "SMTP",
          53: "DNS",
          80: "HTTP",
          110: "POP3",
          143: "IMAP",
          443: "HTTPS",
          3306: "MySQL",
          3389: "RDP",
          6379: "Redis",
          8080: "HTTP-Alt",
        };
        const ports: PortItem[] = portList.slice(0, 20).map((port) => {
          const isOpen = Math.random() > 0.6;
          return {
            port,
            service: serviceMap[port] || "未知服务",
            status: isOpen ? "open" : "closed",
          };
        });
        const result: PortscanResult = {
          target,
          resolvedIp: `${Math.floor(Math.random() * 223) + 1}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`,
          total: ports.length,
          openCount: ports.filter((p) => p.status === "open").length,
          closedCount: ports.filter((p) => p.status === "closed").length,
          ports,
        };
        return result;
      }}
      renderResult={(result) => {
        const data = result as PortscanResult;
        return (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-3">
              <Badge
                variant="secondary"
                className="bg-foreground text-background hover:bg-foreground/90 border-0"
              >
                {data.openCount} 个开放
              </Badge>
              <span className="text-sm text-muted-foreground flex items-center gap-1">
                <Server className="h-3.5 w-3.5" />
                解析 IP：{data.resolvedIp}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                    <Network className="h-4 w-4 text-foreground" />
                    扫描端口数
                  </div>
                  <div className="font-medium text-foreground">{data.total}</div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    开放
                  </div>
                  <div className="font-medium text-foreground">{data.openCount}</div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                    <Shield className="h-4 w-4 text-red-600" />
                    关闭
                  </div>
                  <div className="font-medium text-foreground">{data.closedCount}</div>
                </CardContent>
              </Card>
            </div>

            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3 text-muted-foreground text-sm">
                  <Lock className="h-4 w-4 text-foreground" />
                  端口详情
                </div>
                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-24">端口</TableHead>
                        <TableHead>服务</TableHead>
                        <TableHead className="w-24">状态</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {data.ports.map((item, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-mono text-foreground">
                            {item.port}
                          </TableCell>
                          <TableCell className="text-foreground">
                            {item.service}
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                item.status === "open" ? "default" : "secondary"
                              }
                              className={
                                item.status === "open"
                                  ? "bg-green-500/15 text-green-600 hover:bg-green-500/20 border-0"
                                  : ""
                              }
                            >
                              {item.status === "open" ? "开放" : "关闭"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}