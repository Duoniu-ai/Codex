import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "端口扫描",
  "主机端口检测",
  "security",
  "/portscan",
);

export default function PortscanLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
