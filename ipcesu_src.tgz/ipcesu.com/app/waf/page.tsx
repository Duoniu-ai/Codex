"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Fingerprint } from "lucide-react";

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "已识别", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "不确定", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "未识别", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="WAF 检测"
      description="防火墙识别"
      icon={Fingerprint}
      tips={[
        "输入目标 URL 即可模拟识别 WAF 厂商。",
        "通过响应头、状态码与特征指纹综合判断。",
        "结果仅供参考，真实环境可能更加复杂。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      onRun={async () => {
        await new Promise((r) => setTimeout(r, 700 + Math.floor(Math.random() * 500)));
        const vendors = ["Cloudflare", "阿里云 WAF", "腾讯云 WAF", "AWS WAF", "未识别"];
        const vendor = vendors[Math.floor(Math.random() * vendors.length)];
        const confidence = Math.floor(50 + Math.random() * 50);
        const status: "pass" | "warn" | "risk" = vendor === "未识别" ? "risk" : confidence > 80 ? "pass" : "warn";
        return {
          vendor,
          confidence,
          status,
          signals: [
            { name: "Set-Cookie 特征", value: Math.random() > 0.3 ? "匹配" : "未匹配", status: Math.random() > 0.3 ? "pass" : "warn" },
            { name: "响应头 Server", value: Math.random() > 0.3 ? "包含 WAF 标记" : "无特征", status: Math.random() > 0.3 ? "pass" : "warn" },
            { name: "拦截页特征", value: Math.random() > 0.4 ? "匹配" : "未触发", status: Math.random() > 0.4 ? "pass" : "warn" },
          ],
        };
      }}
      renderResult={(result) => {
        const data = result as {
          vendor: string;
          confidence: number;
          status: "pass" | "warn" | "risk";
          signals: { name: string; value: string; status: "pass" | "warn" | "risk" }[];
        };
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">识别厂商</div><div className="text-xl font-semibold">{data.vendor}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">置信度</div><div className="text-2xl font-semibold">{data.confidence}%</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">检测结果</div><div className="mt-1">{statusBadge(data.status)}</div></CardContent></Card>
            </div>
            <Card>
              <CardHeader>
                <CardTitle>识别信号</CardTitle>
                <CardDescription>WAF 指纹特征匹配情况</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>信号</TableHead>
                      <TableHead>结果</TableHead>
                      <TableHead>状态</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.signals.map((s) => (
                      <TableRow key={s.name}>
                        <TableCell>{s.name}</TableCell>
                        <TableCell>{s.value}</TableCell>
                        <TableCell>{statusBadge(s.status)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}