import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "WAF 检测",
  "防火墙识别",
  "security",
  "/waf",
);

export default function WafLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
