"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Hash } from "lucide-react";

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "适中", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "偏高", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "堆积", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="关键词密度"
      description="页面关键词分布分析"
      icon={Hash}
      tips={[
        "将页面正文粘贴到输入框中即可分析。",
        "关键词密度建议保持在 2% - 8% 之间。",
        "避免为优化而堆砌关键词，影响阅读体验。",
      ]}
      inputs={[
        { id: "content", label: "页面文本内容", type: "textarea", placeholder: "粘贴需要分析的页面文本...", rows: 6 },
      ]}
      onRun={async (values) => {
        await new Promise((r) => setTimeout(r, 600 + Math.floor(Math.random() * 400)));
        const tokens = values.content.match(/[\u4e00-\u9fa5]{2,}|[a-zA-Z0-9]{3,}/g) || [];
        const counts: Record<string, number> = {};
        tokens.forEach((t) => { counts[t] = (counts[t] || 0) + 1; });
        const total = tokens.length;
        const unique = Object.keys(counts).length;
        const top = Object.entries(counts)
          .sort((a, b) => b[1] - a[1])
          .slice(0, 8)
          .map(([word, count]) => ({
            word,
            count,
            density: total ? ((count / total) * 100).toFixed(2) + "%" : "0%",
            status: count / (total || 1) > 0.1 ? "risk" : count / (total || 1) > 0.05 ? "warn" : "pass" as "pass" | "warn" | "risk",
          }));
        return { total, unique, top };
      }}
      renderResult={(result) => {
        const data = result as {
          total: number;
          unique: number;
          top: { word: string; count: number; density: string; status: "pass" | "warn" | "risk" }[];
        };
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">总词数</div><div className="text-2xl font-semibold">{data.total}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">不重复词</div><div className="text-2xl font-semibold">{data.unique}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">高频词数</div><div className="text-2xl font-semibold">{data.top.length}</div></CardContent></Card>
            </div>
            <Card>
              <CardHeader>
                <CardTitle>关键词分布</CardTitle>
                <CardDescription>出现频率最高的关键词</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>关键词</TableHead>
                      <TableHead>出现次数</TableHead>
                      <TableHead>密度</TableHead>
                      <TableHead>评估</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.top.map((item) => (
                      <TableRow key={item.word}>
                        <TableCell>{item.word}</TableCell>
                        <TableCell>{item.count}</TableCell>
                        <TableCell>{item.density}</TableCell>
                        <TableCell>{statusBadge(item.status)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}