import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "关键词密度",
  "页面关键词分布分析",
  "analysis",
  "/keyword-density",
);

export default function KeywordDensityLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
