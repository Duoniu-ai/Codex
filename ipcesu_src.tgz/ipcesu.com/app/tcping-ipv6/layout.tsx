import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "TCPing IPv6",
  "IPv6 TCP 端口连通性检测",
  "network",
  "/tcping-ipv6",
);

export default function TcpingIpv6Layout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
