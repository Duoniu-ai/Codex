import Link from "next/link";
import type { Metadata } from "next";
import { newsData } from "@/lib/news-data";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Newspaper, ArrowRight, Calendar, Home } from "lucide-react";
import { createMetadata } from "@/lib/seo";

const categoryColors: Record<string, string> = {
  "AI 资讯": "bg-purple-500 text-white",
  "网安资讯": "bg-red-500 text-white",
  "行业动态": "bg-blue-500 text-white",
  "技术教程": "bg-orange-500 text-white",
  "帮助中心": "bg-emerald-500 text-white",
  "网站公告": "bg-blue-600 text-white",
  "VPS 教程": "bg-emerald-500 text-white",
  "线路对比": "bg-cyan-500 text-white",
};

const categoryOrder = ["技术教程", "帮助中心", "网站公告"];

export const metadata: Metadata = createMetadata({
  title: "热门资讯 - 网络工具技术教程与帮助中心",
  description:
    "IPcesu 热门资讯提供网络检测工具技术教程、帮助中心文档与网站公告，涵盖 Ping 测试、DNS 查询、SEO 优化、网站监控等实用内容。",
  keywords:
    "热门资讯, 技术教程, 帮助中心, 网站公告, 网络工具教程, Ping 测试教程, SEO 教程, 网站监控",
  path: "/article",
});

interface PageProps {
  searchParams: Promise<{ category?: string }>;
}

export default async function NewsPage({ searchParams }: PageProps) {
  const { category } = await searchParams;
  const activeCategory = category && categoryOrder.includes(category) ? category : null;

  const categoriesToShow = activeCategory ? [activeCategory] : categoryOrder;

  return (
    <main className="bg-background min-h-screen">
      <section className="bg-slate-900 text-white py-16">
        <div className="container mx-auto px-4">
          <nav className="flex items-center gap-2 text-sm text-slate-300 mb-6">
            <Link href="/" className="flex items-center gap-1 hover:text-white">
              <Home className="h-4 w-4" />
              首页
            </Link>
            <span>/</span>
            <span className="text-white">{activeCategory || "热门资讯"}</span>
          </nav>
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10">
              <Newspaper className="h-5 w-5" />
            </div>
            <span className="text-sm text-slate-300">资讯中心</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-3">
            {activeCategory || "热门资讯"}
          </h1>
          <p className="text-slate-300 max-w-2xl">
            汇集网络检测、域名安全、帮助文档与网站公告等实用内容，从主站迁移整理而来。
          </p>
        </div>
      </section>

      <div className="container mx-auto px-4 py-12">
        <div className="flex flex-wrap items-center gap-2 mb-8">
          <Link
            href="/article"
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              !activeCategory
                ? "bg-foreground text-background"
                : "bg-muted text-foreground hover:bg-muted/80"
            }`}
          >
            全部
          </Link>
          {categoryOrder.map((cat) => (
            <Link
              key={cat}
              href={`/article?category=${encodeURIComponent(cat)}`}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeCategory === cat
                  ? "bg-foreground text-background"
                  : "bg-muted text-foreground hover:bg-muted/80"
              }`}
            >
              {cat}
            </Link>
          ))}
        </div>

        {categoriesToShow.map((category) => {
          const items = newsData.filter((item) => item.category === category);
          if (items.length === 0) return null;
          return (
            <section key={category} className="mb-12">
              {!activeCategory && (
                <div className="flex items-center gap-3 mb-6">
                  <Badge
                    className={`text-sm px-3 py-1 ${categoryColors[category] || "bg-muted text-foreground"}`}
                  >
                    {category}
                  </Badge>
                  <span className="text-sm text-muted-foreground">共 {items.length} 篇</span>
                </div>
              )}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {items.map((item) => (
                  <Link key={item.id} href={`/article/${item.id}`}>
                    <Card className="h-full border border-border bg-card hover:shadow-md transition-shadow duration-300">
                      <CardContent className="p-5">
                        <Badge
                          className={`mb-3 ${categoryColors[item.category] || "bg-muted text-foreground"}`}
                        >
                          {item.category}
                        </Badge>
                        <h3 className="font-medium leading-snug text-foreground hover:text-primary transition-colors line-clamp-2 mb-2">
                          {item.title}
                        </h3>
                        <p className="text-xs text-muted-foreground line-clamp-2 mb-3">
                          {item.summary}
                        </p>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          <span>{item.date}</span>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            </section>
          );
        })}

        <div className="mt-12 text-center">
          <Link
            href="/"
            className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowRight className="h-4 w-4 rotate-180" />
            返回首页
          </Link>
        </div>
      </div>
    </main>
  );
}