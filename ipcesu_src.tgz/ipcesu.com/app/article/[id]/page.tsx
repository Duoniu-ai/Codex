import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { newsData } from "@/lib/news-data";
import { tools } from "@/lib/tools";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, ChevronRight, Home, Newspaper, Wrench } from "lucide-react";
import { createMetadata, SITE_NAME } from "@/lib/seo";

const categoryColors: Record<string, string> = {
  "技术教程": "bg-orange-500 text-white",
  "帮助中心": "bg-emerald-500 text-white",
  "网站公告": "bg-blue-600 text-white",
};

interface PageProps {
  params: Promise<{ id: string }>;
}

export async function generateStaticParams() {
  return newsData.map((item) => ({ id: String(item.id) }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params;
  const item = newsData.find((n) => n.id === Number(id));
  if (!item) {
    return createMetadata({
      title: "文章未找到",
      description: "您访问的资讯文章不存在或已被移除。",
      path: "/article",
      noIndex: true,
    });
  }

  return createMetadata({
    title: `${item.title} - ${item.category}`,
    description: item.summary,
    keywords: `${item.title}, ${item.category}, 技术教程, 帮助中心, 网站公告, ${SITE_NAME}`,
    path: `/article/${item.id}`,
  });
}

export default async function NewsDetailPage({ params }: PageProps) {
  const { id } = await params;
  const item = newsData.find((n) => n.id === Number(id));
  if (!item) notFound();

  const relatedTools = tools.filter((t) => item.relatedToolSlugs?.includes(t.id));
  const relatedArticles = newsData
    .filter((n) => n.id !== item.id)
    .slice(0, 5);

  return (
    <main className="bg-background min-h-screen">
      {/* Breadcrumb + Header */}
      <section className="border-b border-border bg-white">
        <div className="container mx-auto px-4 py-8">
          <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
            <Link href="/" className="flex items-center gap-1 hover:text-foreground">
              <Home className="h-4 w-4" />
              首页
            </Link>
            <ChevronRight className="h-4 w-4" />
            <Link href="/article" className="hover:text-foreground">
              资讯中心
            </Link>
            <ChevronRight className="h-4 w-4" />
            <span className="text-foreground">{item.title}</span>
          </nav>

          <Badge className={`mb-4 ${categoryColors[item.category] || "bg-muted text-foreground"}`}>
            {item.category}
          </Badge>
          <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
            {item.title}
          </h1>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Calendar className="h-4 w-4" />
            <span>{item.date}</span>
          </div>
        </div>
      </section>

      {/* Content */}
      <div className="container mx-auto px-4 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <main className="lg:col-span-2">
            <Card className="border border-border bg-white overflow-hidden">
              <CardContent className="p-6 md:p-8">
                <article
                  className="text-foreground [&_h2]:text-xl [&_h2]:font-bold [&_h2]:mt-8 [&_h2]:mb-4 [&_h3]:text-lg [&_h3]:font-semibold [&_h3]:mt-6 [&_h3]:mb-3 [&_h4]:font-semibold [&_h4]:mt-5 [&_h4]:mb-2 [&_p]:leading-7 [&_p]:mb-4 [&_ul]:list-disc [&_ul]:pl-6 [&_ul]:mb-4 [&_ol]:list-decimal [&_ol]:pl-6 [&_ol]:mb-4 [&_ol]:pl-6 [&_ol]:mb-4 [&_li]:mb-1 [&_a]:text-primary [&_a]:hover:underline [&_table]:w-full [&_table]:text-sm [&_table]:border-collapse [&_th]:border [&_th]:p-2 [&_th]:bg-muted [&_td]:border [&_td]:p-2 [&_pre]:bg-slate-900 [&_pre]:text-slate-100 [&_pre]:p-4 [&_pre]:rounded-lg [&_pre]:overflow-x-auto [&_pre]:text-sm [&_code]:bg-muted [&_code]:px-1 [&_code]:py-0.5 [&_code]:rounded [&_code]:text-sm [&_strong]:font-semibold [&_.tip-box]:bg-amber-50 [&_.tip-box]:border [&_.tip-box]:border-amber-200 [&_.tip-box]:p-4 [&_.tip-box]:rounded-lg [&_.tip-box]:mb-4 [&_.concept-box]:bg-muted [&_.concept-box]:p-4 [&_.concept-box]:rounded-lg [&_.concept-box]:mb-4 [&_.warning-box]:bg-red-50 [&_.warning-box]:border [&_.warning-box]:border-red-200 [&_.warning-box]:p-4 [&_.warning-box]:rounded-lg [&_.warning-box]:mb-4 [&_.result-box]:bg-slate-900 [&_.result-box]:text-slate-100 [&_.result-box]:p-4 [&_.result-box]:rounded-lg [&_.result-box]:font-mono [&_.result-box]:text-sm [&_.result-box]:mb-4 [&_.code-block]:bg-slate-900 [&_.code-block]:text-slate-100 [&_.code-block]:p-4 [&_.code-block]:rounded-lg [&_.code-block]:font-mono [&_.code-block]:text-sm [&_.code-block]:mb-4 [&_.diagram-box]:bg-muted [&_.diagram-box]:p-4 [&_.diagram-box]:rounded-lg [&_.diagram-box]:font-mono [&_.diagram-box]:text-sm [&_.diagram-box]:mb-4"
                  dangerouslySetInnerHTML={{ __html: item.content }}
                />
              </CardContent>
            </Card>
          </main>

          <aside className="space-y-6">
            {relatedTools.length > 0 && (
              <Card className="border border-border bg-white">
                <CardContent className="p-5">
                  <div className="flex items-center gap-2 mb-4">
                    <Wrench className="h-4 w-4 text-muted-foreground" />
                    <h3 className="font-semibold text-foreground">相关工具推荐</h3>
                  </div>
                  <div className="space-y-3">
                    {relatedTools.map((tool) => (
                      <Link
                        key={tool.id}
                        href={tool.href}
                        className="flex items-start gap-3 p-3 rounded-lg border border-border hover:border-primary/50 hover:bg-muted/50 transition-colors"
                      >
                        <tool.icon className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                        <div>
                          <p className="font-medium text-sm text-foreground">{tool.label}</p>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            {tool.description}
                          </p>
                        </div>
                      </Link>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            <Card className="border border-border bg-white">
              <CardContent className="p-5">
                <div className="flex items-center gap-2 mb-4">
                  <Newspaper className="h-4 w-4 text-muted-foreground" />
                  <h3 className="font-semibold text-foreground">相关文章</h3>
                </div>
                <div className="space-y-3">
                  {relatedArticles.map((article) => (
                    <Link
                      key={article.id}
                      href={`/article/${article.id}`}
                      className="block group"
                    >
                      <p className="text-sm text-foreground group-hover:text-primary transition-colors line-clamp-2">
                        {article.title}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">{article.date}</p>
                    </Link>
                  ))}
                </div>
              </CardContent>
            </Card>
          </aside>
        </div>
      </div>
    </main>
  );
}