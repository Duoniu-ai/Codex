import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "BGP 路由查询",
  "ASN 和路由信息查询",
  "network",
  "/bgp",
);

export default function BgpLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
