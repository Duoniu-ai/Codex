"use client";

import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Binary, Globe, Network, Server, MapPin } from "lucide-react";

interface BgpResult {
  query: string;
  asn: string;
  name: string;
  country: string;
  prefixCount: number;
  neighborCount: number;
  prefixes: string[];
}

export default function BgpPage() {
  return (
    <Suspense fallback={<BgpPageSkeleton />}>
      <BgpPageForm />
    </Suspense>
  );
}

function BgpPageSkeleton() {
  return (
    <ToolPageLayout
      title="BGP 路由查询"
      description="ASN 和路由信息查询"
      icon={Binary}
      tips={[
        "输入 IP 地址或 ASN 号（如 AS4538）查询 BGP 信息。",
        "可查看自治系统名称、所属国家及公告前缀。",
        "支持查询相邻 ASN 数量与路由前缀列表。",
        "数据为模拟展示，真实 BGP 信息请以 WHOIS/RIR 为准。",
      ]}
    >
      <div className="space-y-3">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    </ToolPageLayout>
  );
}

function BgpPageForm() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get("q") || "";

  const [query, setQuery] = useState(initialQuery);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<BgpResult | null>(null);
  const [error, setError] = useState("");

  const handleTest = async () => {
    if (!query.trim()) {
      setError("请输入 ASN 或 IP 地址");
      return;
    }

    setLoading(true);
    setError("");
    setResult(null);

    try {
      await new Promise((r) => setTimeout(r, 600 + Math.random() * 600));
      const isAsn = /^AS\d+$/i.test(query.trim());
      const asn = isAsn
        ? query.trim().toUpperCase()
        : `AS${10000 + Math.floor(Math.random() * 50000)}`;
      const prefixCount = 3 + Math.floor(Math.random() * 8);
      const prefixes = Array.from({ length: prefixCount }, () => {
        const a = Math.floor(Math.random() * 223) + 1;
        const b = Math.floor(Math.random() * 256);
        const c = Math.floor(Math.random() * 256);
        const len = 20 + Math.floor(Math.random() * 12);
        return `${a}.${b}.${c}.0/${len}`;
      });
      const data: BgpResult = {
        query: query.trim(),
        asn,
        name: ["CHINAEDU", "CHINATELECOM", "CHINAUNICOM", "CMNET", "Google LLC"][
          Math.floor(Math.random() * 5)
        ],
        country: ["CN", "US", "JP", "DE", "SG"][Math.floor(Math.random() * 5)],
        prefixCount,
        neighborCount: 5 + Math.floor(Math.random() * 20),
        prefixes,
      };
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "查询失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ToolPageLayout
      title="BGP 路由查询"
      description="ASN 和路由信息查询"
      icon={Binary}
      tips={[
        "输入 IP 地址或 ASN 号（如 AS4538）查询 BGP 信息。",
        "可查看自治系统名称、所属国家及公告前缀。",
        "支持查询相邻 ASN 数量与路由前缀列表。",
        "数据为模拟展示，真实 BGP 信息请以 WHOIS/RIR 为准。",
      ]}
    >
      <Card className="border-border/40 bg-card shadow-sm">
        <CardContent className="p-5 space-y-5">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex-1 space-y-2">
              <label className="text-sm font-medium text-foreground">ASN / IP</label>
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleTest()}
                placeholder="例如：AS4538 或 8.8.8.8"
                className="bg-secondary/50 border-border/50"
              />
            </div>
            <div className="flex items-end">
              <Button
                onClick={handleTest}
                disabled={loading}
                className="bg-foreground hover:bg-foreground/90 text-background"
              >
                {loading ? "查询中..." : "开始查询"}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {error && (
        <div className="p-4 rounded-lg bg-destructive/10 text-destructive text-sm">
          {error}
        </div>
      )}

      {loading && (
        <Card className="border-border/40 bg-card shadow-sm">
          <CardContent className="p-5 space-y-3">
            <Skeleton className="h-8 w-3/4" />
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
            </div>
            <Skeleton className="h-32 w-full" />
          </CardContent>
        </Card>
      )}

      {result && !loading && (
        <div className="space-y-4 animate-fade-in-up">
          <div className="flex flex-wrap items-center gap-3">
            <Badge
              variant="secondary"
              className="bg-foreground text-background hover:bg-foreground/90 border-0"
            >
              {result.asn}
            </Badge>
            <span className="text-sm text-muted-foreground flex items-center gap-1">
              <MapPin className="h-3.5 w-3.5" />
              国家 / 地区：{result.country}
            </span>
            <span className="text-sm text-muted-foreground flex items-center gap-1">
              <Globe className="h-3.5 w-3.5" />
              查询：{result.query}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Binary className="h-4 w-4 text-foreground" />
                  ASN
                </div>
                <div className="font-medium font-mono text-foreground break-all">
                  {result.asn}
                </div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Server className="h-4 w-4 text-foreground" />
                  自治系统名称
                </div>
                <div className="font-medium text-foreground break-all">{result.name}</div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Network className="h-4 w-4 text-foreground" />
                  路由前缀数
                </div>
                <div className="font-medium text-foreground">{result.prefixCount}</div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Globe className="h-4 w-4 text-foreground" />
                  邻居 ASN 数
                </div>
                <div className="font-medium text-foreground">{result.neighborCount}</div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-3 text-muted-foreground text-sm">
                <Network className="h-4 w-4 text-foreground" />
                公告前缀列表
              </div>
              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-16">序号</TableHead>
                      <TableHead>前缀</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {result.prefixes.map((prefix, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-mono">{index + 1}</TableCell>
                        <TableCell className="font-mono text-foreground break-all">
                          {prefix}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </ToolPageLayout>
  );
}
