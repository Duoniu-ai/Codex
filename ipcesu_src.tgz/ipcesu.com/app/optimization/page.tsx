"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { TrendingUp } from "lucide-react";

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "优秀", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "建议", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "需优化", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="SEO 优化"
      description="全面 SEO 优化建议"
      icon={TrendingUp}
      tips={[
        "输入目标 URL 获取整站 SEO 优化建议。",
        "优先处理标记为“需优化”的高风险项。",
        "建议定期复查，持续跟踪优化效果。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      onRun={async () => {
        await new Promise((r) => setTimeout(r, 800 + Math.floor(Math.random() * 400)));
        return {
          score: Math.floor(60 + Math.random() * 36),
          suggestions: [
            { name: "压缩图片资源", status: Math.random() > 0.4 ? "pass" : "warn", detail: "使用 WebP/AVIF 格式可显著降低 LCP" },
            { name: "启用浏览器缓存", status: Math.random() > 0.3 ? "pass" : "warn", detail: "为静态资源配置长效 Cache-Control" },
            { name: "减少阻塞渲染脚本", status: Math.random() > 0.4 ? "pass" : "warn", detail: "将非关键 JS 延迟加载或异步加载" },
            { name: "优化内部链接", status: Math.random() > 0.3 ? "pass" : "warn", detail: "确保重要页面在 3 次点击内可达" },
            { name: "修复死链", status: Math.random() > 0.7 ? "pass" : "risk", detail: "404 链接会影响蜘蛛抓取效率" },
            { name: "完善结构化数据", status: Math.random() > 0.5 ? "pass" : "warn", detail: "补充 JSON-LD 结构化数据标记" },
          ],
        };
      }}
      renderResult={(result) => {
        const data = result as {
          score: number;
          suggestions: { name: string; status: "pass" | "warn" | "risk"; detail: string }[];
        };
        return (
          <div className="space-y-4">
            <Card className="border-l-4 border-l-foreground">
              <CardContent className="pt-6">
                <div className="text-sm text-muted-foreground">优化评分</div>
                <div className="text-3xl font-bold">{data.score}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>优化建议</CardTitle>
                <CardDescription>按优先级给出的可执行优化项</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>优化项</TableHead>
                      <TableHead>评级</TableHead>
                      <TableHead>说明</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.suggestions.map((item) => (
                      <TableRow key={item.name}>
                        <TableCell>{item.name}</TableCell>
                        <TableCell>{statusBadge(item.status)}</TableCell>
                        <TableCell className="whitespace-normal">{item.detail}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}