import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "时间戳转换",
  "时间戳日期互转",
  "dev",
  "/timestamp",
);

export default function TimestampLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
