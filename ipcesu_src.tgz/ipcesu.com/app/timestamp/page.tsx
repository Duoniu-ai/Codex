"use client";

import { useState, useEffect } from "react";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CalendarClock, Copy, Check } from "lucide-react";

export default function Page() {
  const [timestamp, setTimestamp] = useState("");
  const [dateStr, setDateStr] = useState("");
  const [unit, setUnit] = useState<"s" | "ms">("s");
  const [nowTs, setNowTs] = useState<number>(0);
  const [copied, setCopied] = useState<string | null>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setNowTs(Math.floor(Date.now() / 1000));
    }, 1000);
    setNowTs(Math.floor(Date.now() / 1000));
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!timestamp) {
      setDateStr("");
      return;
    }
    const tsNum = Number(timestamp);
    if (isNaN(tsNum)) {
      setDateStr("");
      return;
    }
    const ms = unit === "s" ? tsNum * 1000 : tsNum;
    const d = new Date(ms);
    if (isNaN(d.getTime())) {
      setDateStr("");
      return;
    }
    setDateStr(d.toLocaleString("zh-CN", { hour12: false }));
  }, [timestamp, unit]);

  const handleNow = () => {
    const now = Date.now();
    if (unit === "s") {
      setTimestamp(String(Math.floor(now / 1000)));
    } else {
      setTimestamp(String(now));
    }
  };

  const handleCopy = async (value: string, key: string) => {
    await navigator.clipboard.writeText(value);
    setCopied(key);
    setTimeout(() => setCopied(null), 1500);
  };

  const dateToTimestamp = (value: string) => {
    if (!value) {
      setTimestamp("");
      return;
    }
    const d = new Date(value);
    if (isNaN(d.getTime())) return;
    if (unit === "s") {
      setTimestamp(String(Math.floor(d.getTime() / 1000)));
    } else {
      setTimestamp(String(d.getTime()));
    }
  };

  return (
    <ToolPageLayout
      title="时间戳转换"
      description="Unix 时间戳与日期时间互转，支持秒/毫秒"
      icon={CalendarClock}
      tips={[
        "支持 Unix 时间戳（秒或毫秒）转日期时间。",
        "也支持日期时间转时间戳。",
        "点击「当前时间」可快速填充当前时间戳。",
        "所有转换在浏览器本地完成。",
      ]}
    >
      <Card className="border-border/50 bg-card">
        <CardContent className="p-5 space-y-5">
          <div className="flex items-center gap-2">
            <Button variant={unit === "s" ? "default" : "outline"} size="sm" onClick={() => setUnit("s")}>
              秒（s）
            </Button>
            <Button variant={unit === "ms" ? "default" : "outline"} size="sm" onClick={() => setUnit("ms")}>
              毫秒（ms）
            </Button>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">Unix 时间戳</label>
              <div className="text-xs text-muted-foreground">当前：{nowTs}</div>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={timestamp}
                onChange={(e) => setTimestamp(e.target.value)}
                placeholder={`例如：${nowTs}`}
                className="flex-1 rounded-lg border border-input bg-transparent px-3 py-2 text-sm placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 outline-none"
              />
              <Button variant="outline" onClick={handleNow}>当前时间</Button>
              {timestamp && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleCopy(timestamp, "ts")}
                >
                  {copied === "ts" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">日期时间</label>
            <div className="flex gap-2">
              <input
                type="datetime-local"
                step="1"
                value={dateStr ? new Date(new Date(dateStr).getTime() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 19) : ""}
                onChange={(e) => dateToTimestamp(e.target.value)}
                className="flex-1 rounded-lg border border-input bg-transparent px-3 py-2 text-sm placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 outline-none"
              />
              {dateStr && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleCopy(dateStr, "date")}
                >
                  {copied === "date" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              )}
            </div>
            <div className="min-h-[24px] text-sm text-muted-foreground">
              {dateStr || "转换结果将显示在这里"}
            </div>
          </div>
        </CardContent>
      </Card>
    </ToolPageLayout>
  );
}