import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "CORS 检测",
  "跨域配置安全检测",
  "security",
  "/cors",
);

export default function CorsLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
