"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Crosshair } from "lucide-react";

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "安全", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "注意", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "风险", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="CORS 检测"
      description="跨域配置安全检测"
      icon={Crosshair}
      tips={[
        "输入目标 URL 即可模拟检测 CORS 响应头。",
        "Access-Control-Allow-Origin: * 配合 Allow-Credentials 存在风险。",
        "生产环境应使用明确的白名单域名。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://api.example.com" },
      ]}
      onRun={async () => {
        await new Promise((r) => setTimeout(r, 700 + Math.floor(Math.random() * 400)));
        const allowOrigin = Math.random() > 0.5 ? "*" : "https://trusted.com";
        const allowCredentials = Math.random() > 0.7;
        const reflectOrigin = Math.random() > 0.8;
        const allowMethods = "GET, POST, OPTIONS";
        const allowHeaders = "Content-Type, Authorization";
        let status: "pass" | "warn" | "risk" = "pass";
        if (allowOrigin === "*" && allowCredentials) status = "risk";
        else if (allowOrigin === "*" || reflectOrigin) status = "warn";
        return { allowOrigin, allowCredentials, reflectOrigin, allowMethods, allowHeaders, status };
      }}
      renderResult={(result) => {
        const data = result as {
          allowOrigin: string;
          allowCredentials: boolean;
          reflectOrigin: boolean;
          allowMethods: string;
          allowHeaders: string;
          status: "pass" | "warn" | "risk";
        };
        const checks: { name: string; value: string; status: "pass" | "warn" | "risk" }[] = [
          { name: "Allow-Origin", value: data.allowOrigin, status: data.allowOrigin === "*" ? "warn" : "pass" },
          { name: "Allow-Credentials", value: data.allowCredentials ? "true" : "false", status: data.allowCredentials && data.allowOrigin === "*" ? "risk" : "pass" },
          { name: "反射 Origin", value: data.reflectOrigin ? "存在" : "不存在", status: data.reflectOrigin ? "risk" : "pass" },
          { name: "Allow-Methods", value: data.allowMethods, status: "pass" },
          { name: "Allow-Headers", value: data.allowHeaders, status: "pass" },
        ];
        return (
          <div className="space-y-4">
            <Card className="border-l-4 border-l-foreground">
              <CardContent className="pt-6 flex items-center justify-between">
                <div>
                  <div className="text-sm text-muted-foreground">综合评级</div>
                  <div className="text-3xl font-bold">{statusBadge(data.status)}</div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>CORS 响应头</CardTitle>
                <CardDescription>跨域配置安全检查结果</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>检查项</TableHead>
                      <TableHead>值</TableHead>
                      <TableHead>状态</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {checks.map((c) => (
                      <TableRow key={c.name}>
                        <TableCell>{c.name}</TableCell>
                        <TableCell className="whitespace-normal max-w-xs break-all">{c.value}</TableCell>
                        <TableCell>{statusBadge(c.status)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}