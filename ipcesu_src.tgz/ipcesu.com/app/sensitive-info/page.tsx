"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertTriangle } from "lucide-react";

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "未发现", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "低风险", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "高风险", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="敏感信息泄露检测"
      description="检测网站是否存在敏感文件或信息泄露"
      icon={AlertTriangle}
      tips={[
        "输入目标域名即可模拟扫描常见敏感路径。",
        "仅用于自查网站安全风险，请勿用于非法用途。",
        "发现泄露后应及时清理并加强访问控制。",
      ]}
      inputs={[
        { id: "domain", label: "目标域名", type: "text", placeholder: "example.com" },
      ]}
      onRun={async () => {
        await new Promise((r) => setTimeout(r, 900 + Math.floor(Math.random() * 300)));
        const paths = [
          { path: "/.git/config", leaked: Math.random() > 0.7, severity: "risk" as "risk" | "warn" },
          { path: "/.env", leaked: Math.random() > 0.8, severity: "risk" },
          { path: "/backup.zip", leaked: Math.random() > 0.75, severity: "risk" },
          { path: "/api/swagger-ui.html", leaked: Math.random() > 0.6, severity: "warn" },
          { path: "/phpinfo.php", leaked: Math.random() > 0.8, severity: "warn" },
        ];
        const leaked = paths.filter((p) => p.leaked);
        return { scanned: paths.length, leakedCount: leaked.length, paths };
      }}
      renderResult={(result) => {
        const data = result as {
          scanned: number;
          leakedCount: number;
          paths: { path: string; leaked: boolean; severity: "risk" | "warn" }[];
        };
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">扫描路径</div><div className="text-2xl font-semibold">{data.scanned}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">泄露数量</div><div className="text-2xl font-semibold text-red-700">{data.leakedCount}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">安全路径</div><div className="text-2xl font-semibold text-green-700">{data.scanned - data.leakedCount}</div></CardContent></Card>
            </div>
            <Card>
              <CardHeader>
                <CardTitle>扫描结果</CardTitle>
                <CardDescription>常见敏感路径泄露检查</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>路径</TableHead>
                      <TableHead>是否泄露</TableHead>
                      <TableHead>风险等级</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.paths.map((p) => (
                      <TableRow key={p.path}>
                        <TableCell className="whitespace-normal max-w-xs break-all">{p.path}</TableCell>
                        <TableCell>{p.leaked ? "是" : "否"}</TableCell>
                        <TableCell>{statusBadge(p.leaked ? p.severity : "pass")}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}