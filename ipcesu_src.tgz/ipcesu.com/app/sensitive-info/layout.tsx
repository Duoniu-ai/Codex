import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "敏感信息泄露",
  "敏感文件泄露检测",
  "security",
  "/sensitive-info",
);

export default function SensitiveInfoLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
