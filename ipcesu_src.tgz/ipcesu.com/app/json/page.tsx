"use client";

import { useState } from "react";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Code, Copy, Check, RotateCcw, Minimize2 } from "lucide-react";

export default function Page() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);

  const handleFormat = () => {
    try {
      if (!input.trim()) {
        setOutput("");
        setError("");
        return;
      }
      const parsed = JSON.parse(input);
      setOutput(JSON.stringify(parsed, null, 2));
      setError("");
    } catch (e) {
      setError("JSON 格式错误，请检查输入内容");
      setOutput("");
    }
  };

  const handleCompress = () => {
    try {
      if (!input.trim()) {
        setOutput("");
        setError("");
        return;
      }
      const parsed = JSON.parse(input);
      setOutput(JSON.stringify(parsed));
      setError("");
    } catch (e) {
      setError("JSON 格式错误，请检查输入内容");
      setOutput("");
    }
  };

  const handleCopy = async () => {
    if (!output) return;
    await navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const handleReset = () => {
    setInput("");
    setOutput("");
    setError("");
  };

  return (
    <ToolPageLayout
      title="JSON 格式化"
      description="JSON 美化、压缩、校验工具"
      icon={Code}
      tips={[
        "粘贴 JSON 文本，点击「格式化」进行美化。",
        "点击「压缩」可去除多余空格，生成单行 JSON。",
        "工具会自动校验 JSON 语法并提示错误位置。",
        "所有操作在浏览器本地完成。",
      ]}
    >
      <Card className="border-border/50 bg-card">
        <CardContent className="p-5 space-y-5">
          <div className="flex flex-wrap gap-2">
            <Button onClick={handleFormat}>格式化</Button>
            <Button variant="outline" onClick={handleCompress}>
              <Minimize2 className="h-4 w-4 mr-1.5" />
              压缩
            </Button>
            <Button variant="outline" onClick={handleReset}>
              <RotateCcw className="h-4 w-4 mr-1.5" />
              清空
            </Button>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">输入 JSON</label>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder='{"name": "IPcesu", "tools": ["Ping", "DNS"]}'
              className="w-full min-h-[160px] rounded-lg border border-input bg-transparent px-3 py-2 text-sm placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 outline-none resize-y font-mono"
            />
          </div>

          {error && (
            <div className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">
              {error}
            </div>
          )}

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">结果</label>
              {output && (
                <Button variant="ghost" size="sm" onClick={handleCopy}>
                  {copied ? <Check className="h-4 w-4 mr-1.5" /> : <Copy className="h-4 w-4 mr-1.5" />}
                  {copied ? "已复制" : "复制"}
                </Button>
              )}
            </div>
            <pre className="min-h-[160px] max-h-[400px] overflow-auto rounded-lg border border-border/50 bg-muted/30 p-3 text-xs font-mono break-all whitespace-pre-wrap">
              {output || <span className="text-muted-foreground">格式化结果将显示在这里</span>}
            </pre>
          </div>
        </CardContent>
      </Card>
    </ToolPageLayout>
  );
}