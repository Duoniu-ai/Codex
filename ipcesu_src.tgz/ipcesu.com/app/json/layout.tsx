import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "JSON 格式化",
  "JSON 美化压缩校验",
  "dev",
  "/json",
);

export default function JsonLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
