"use client";

import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import { ShieldCheck, Building2, Calendar, FileText, Globe } from "lucide-react";

interface IcpResult {
  domain: string;
  company: string;
  license: string;
  siteName: string;
  nature: string;
  auditDate: string;
  status: string;
}

export default function IcpPage() {
  return (
    <Suspense fallback={<IcpPageSkeleton />}>
      <IcpPageForm />
    </Suspense>
  );
}

function IcpPageSkeleton() {
  return (
    <ToolPageLayout
      title="ICP 备案"
      description="查询域名 ICP 备案信息、备案主体和审核日期"
      icon={ShieldCheck}
      tips={[
        "输入域名即可查询 ICP 备案信息",
        "显示备案主体、备案号、网站名称等",
        "支持自动去除 URL 协议头",
        "未备案域名将显示模拟示例数据",
      ]}
    >
      <div className="space-y-3">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
      </div>
    </ToolPageLayout>
  );
}

function IcpPageForm() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get("q") || "";

  const [domain, setDomain] = useState(initialQuery);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<IcpResult | null>(null);
  const [error, setError] = useState("");

  const handleQuery = async () => {
    if (!domain.trim()) return;

    setLoading(true);
    setError("");
    setResult(null);

    try {
      const res = await fetch("/api/icp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ domain: domain.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "查询失败");
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "查询失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ToolPageLayout
      title="ICP 备案"
      description="查询域名 ICP 备案信息、备案主体和审核日期"
      icon={ShieldCheck}
      tips={[
        "输入域名即可查询 ICP 备案信息",
        "显示备案主体、备案号、网站名称等",
        "支持自动去除 URL 协议头",
        "未备案域名将显示模拟示例数据",
      ]}
    >
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <Input
          value={domain}
          onChange={(e) => setDomain(e.target.value)}
          placeholder="例如：baidu.com"
          className="flex-1 bg-secondary/50 border-border/50"
        />
        <Button
          onClick={handleQuery}
          disabled={loading}
          className="bg-foreground hover:bg-foreground/90 text-background"
        >
          {loading ? "查询中..." : "查询"}
        </Button>
      </div>

      {error && (
        <div className="p-4 rounded-lg bg-destructive/10 text-destructive text-sm mb-6">
          {error}
        </div>
      )}

      {loading && (
        <div className="space-y-3">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
        </div>
      )}

      {result && !loading && (
        <div className="space-y-4 animate-fade-in-up">
          <div className="flex items-center gap-3 mb-4">
            <Badge
              variant={result.status === "已备案" ? "default" : "destructive"}
              className={
                result.status === "已备案"
                  ? "bg-green-500/15 text-green-600 hover:bg-green-500/20 border-0"
                  : ""
              }
            >
              {result.status}
            </Badge>
            <span className="text-sm text-muted-foreground">
              域名：{result.domain}
            </span>
          </div>

          <Card className="border-0 bg-foreground text-background">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-3 text-background/70 text-sm">
                <Globe className="h-4 w-4" />
                网站名称
              </div>
              <div className="text-xl font-bold">{result.siteName}</div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Building2 className="h-4 w-4 text-foreground" />
                  备案主体
                </div>
                <div className="font-medium text-foreground">
                  {result.company}
                </div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <FileText className="h-4 w-4 text-foreground" />
                  备案号
                </div>
                <div className="font-medium font-mono text-foreground">
                  {result.license}
                </div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <ShieldCheck className="h-4 w-4 text-foreground" />
                  备案性质
                </div>
                <div className="font-medium text-foreground">{result.nature}</div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Calendar className="h-4 w-4 text-foreground" />
                  审核日期
                </div>
                <div className="font-medium text-foreground">
                  {result.auditDate}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </ToolPageLayout>
  );
}