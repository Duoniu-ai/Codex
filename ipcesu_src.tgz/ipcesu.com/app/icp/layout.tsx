import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "ICP 备案",
  "域名备案信息查询",
  "domain",
  "/icp",
);

export default function IcpLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
