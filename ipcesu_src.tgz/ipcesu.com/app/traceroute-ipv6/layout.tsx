import type { Metadata } from "next";
import { createToolMetadata } from "@/lib/seo";

export const metadata: Metadata = createToolMetadata(
  "Traceroute IPv6",
  "IPv6 路由追踪",
  "network",
  "/traceroute-ipv6",
);

export default function TracerouteIpv6Layout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
