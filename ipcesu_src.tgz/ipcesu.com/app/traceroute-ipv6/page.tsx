"use client";

import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Route, Server, MapPin, Clock, Globe } from "lucide-react";

interface Hop {
  hop: number;
  ip: string;
  location: string;
  rtt: number | null;
}

interface TracerouteIpv6Result {
  target: string;
  resolvedIp: string;
  node: string;
  hops: Hop[];
}

export default function TracerouteIpv6Page() {
  return (
    <Suspense fallback={<TracerouteIpv6PageSkeleton />}>
      <TracerouteIpv6PageForm />
    </Suspense>
  );
}

function TracerouteIpv6PageSkeleton() {
  return (
    <ToolPageLayout
      title="Traceroute IPv6"
      description="IPv6 路由追踪"
      icon={Route}
      tips={[
        "输入支持 IPv6 的域名或 IPv6 地址，追踪数据包路由路径。",
        "结果显示每一跳的 IPv6 地址、地理位置和延迟。",
        "部分节点可能不响应 ICMPv6，显示为超时。",
        "IPv6 路由路径通常与 IPv4 不同。",
      ]}
    >
      <div className="space-y-3">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    </ToolPageLayout>
  );
}

function TracerouteIpv6PageForm() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get("q") || "";

  const [target, setTarget] = useState(initialQuery);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<TracerouteIpv6Result | null>(null);
  const [error, setError] = useState("");

  const handleTest = async () => {
    if (!target.trim()) {
      setError("请输入目标地址");
      return;
    }

    setLoading(true);
    setError("");
    setResult(null);

    try {
      await new Promise((r) => setTimeout(r, 900 + Math.random() * 500));
      const hopCount = 6 + Math.floor(Math.random() * 7);
      const locations = [
        "本地网络",
        "城域网",
        "省级骨干",
        "国家骨干",
        "海外交换",
        "目标网络",
      ];
      const hops: Hop[] = Array.from({ length: hopCount }, (_, i) => ({
        hop: i + 1,
        ip: `2400:da00:${Math.floor(Math.random() * 9999).toString(16)}::${Math.floor(Math.random() * 9999).toString(16)}`,
        location: locations[Math.min(i, locations.length - 1)],
        rtt: Math.random() > 0.15 ? 10 + i * 8 + Math.random() * 20 : null,
      }));
      const data: TracerouteIpv6Result = {
        target: target.trim(),
        resolvedIp: `2400:da00:${Math.floor(Math.random() * 9999).toString(16)}::${Math.floor(Math.random() * 9999).toString(16)}`,
        node: "模拟节点-华东 IPv6",
        hops,
      };
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "追踪失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ToolPageLayout
      title="Traceroute IPv6"
      description="IPv6 路由追踪"
      icon={Route}
      tips={[
        "输入支持 IPv6 的域名或 IPv6 地址，追踪数据包路由路径。",
        "结果显示每一跳的 IPv6 地址、地理位置和延迟。",
        "部分节点可能不响应 ICMPv6，显示为超时。",
        "IPv6 路由路径通常与 IPv4 不同。",
      ]}
    >
      <Card className="border-border/40 bg-card shadow-sm">
        <CardContent className="p-5 space-y-5">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex-1 space-y-2">
              <label className="text-sm font-medium text-foreground">目标地址（IPv6）</label>
              <Input
                value={target}
                onChange={(e) => setTarget(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleTest()}
                placeholder="例如：ipv6.baidu.com 或 2400:da00::1"
                className="bg-secondary/50 border-border/50"
              />
            </div>
            <div className="flex items-end">
              <Button
                onClick={handleTest}
                disabled={loading}
                className="bg-foreground hover:bg-foreground/90 text-background"
              >
                {loading ? "追踪中..." : "开始追踪"}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {error && (
        <div className="p-4 rounded-lg bg-destructive/10 text-destructive text-sm">
          {error}
        </div>
      )}

      {loading && (
        <Card className="border-border/40 bg-card shadow-sm">
          <CardContent className="p-5 space-y-3">
            <Skeleton className="h-8 w-3/4" />
            <div className="space-y-2">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          </CardContent>
        </Card>
      )}

      {result && !loading && (
        <div className="space-y-4 animate-fade-in-up">
          <div className="flex flex-wrap items-center gap-3">
            <Badge
              variant="secondary"
              className="bg-foreground text-background hover:bg-foreground/90 border-0"
            >
              {result.hops.length} 跳
            </Badge>
            <span className="text-sm text-muted-foreground flex items-center gap-1">
              <Globe className="h-3.5 w-3.5" />
              测试节点：{result.node}
            </span>
            <span className="text-sm text-muted-foreground flex items-center gap-1">
              <Server className="h-3.5 w-3.5" />
              目标 IP：{result.resolvedIp}
            </span>
          </div>

          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-3 text-muted-foreground text-sm">
                <MapPin className="h-4 w-4 text-foreground" />
                追踪结果
              </div>
              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-20">跳数</TableHead>
                      <TableHead>IP 地址</TableHead>
                      <TableHead>位置</TableHead>
                      <TableHead className="w-28">延迟</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {result.hops.map((hop) => (
                      <TableRow key={hop.hop}>
                        <TableCell className="font-mono">{hop.hop}</TableCell>
                        <TableCell className="font-mono text-foreground break-all">
                          {hop.ip}
                        </TableCell>
                        <TableCell className="text-foreground">
                          {hop.location || "--"}
                        </TableCell>
                        <TableCell>
                          {hop.rtt !== null ? (
                            <span className="flex items-center gap-1 text-foreground">
                              <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                              {hop.rtt.toFixed(1)} ms
                            </span>
                          ) : (
                            <span className="text-muted-foreground">超时</span>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </ToolPageLayout>
  );
}
