# 技术架构文档

## 1. 架构设计

```mermaid
flowchart TB
    subgraph 客户端
        A["Next.js App Router<br/>React + TypeScript"]
        B["Tailwind CSS + shadcn/ui"]
    end
    subgraph 服务端
        C["Next.js API Routes"]
        D["工具执行服务<br/>Node.js child_process"]
    end
    subgraph 数据层
        E["PostgreSQL<br/>用户/历史/监控任务"]
        F["Redis<br/>缓存/限流/队列"]
    end
    subgraph 外部服务
        G["MaxMind GeoIP2<br/>IP 地理位置"]
        H["公共 DNS 服务器<br/>Google/Cloudflare/阿里"]
        I["WHOIS 服务器"]
    end
    A --> C
    C --> D
    C --> E
    C --> F
    D --> G
    D --> H
    D --> I
```

## 2. 技术选型

| 层级 | 技术 | 说明 |
|------|------|------|
| 前端框架 | Next.js 15 + React 19 + TypeScript | App Router、Server Components |
| 样式 | Tailwind CSS 4 + shadcn/ui | 原子化 CSS、组件库 |
| 图标 | Lucide React | 统一线性图标 |
| 字体 | 得意黑（Smiley Sans）+ Noto Sans SC | 科技感 + 中文阅读 |
| 构建工具 | Next.js 内置 Turbopack | 开发体验 |
| 后端 | Next.js API Routes | 统一在 Next.js 内 |
| 数据库 | PostgreSQL | 用户、历史记录、监控任务 |
| 缓存 | Redis | API 限流、结果缓存、session |
| 部署 | 静态/Node.js 输出 | 适配宝塔/Linux 服务器 |

## 3. 路由定义

| 路由 | 用途 |
|------|------|
| `/` | 首页 |
| `/tools` | 工具集列表 |
| `/tools/ip` | IP 查询 |
| `/tools/ping` | Ping 测试 |
| `/tools/dns` | DNS 查询 |
| `/tools/ssl` | SSL 检测 |
| `/tools/whois` | Whois 查询 |
| `/api-docs` | API 文档 |
| `/user/login` | 登录 |
| `/user/register` | 注册 |
| `/api/ip-info` | 获取当前访问 IP 信息 |
| `/api/tools/ip` | IP 查询接口 |
| `/api/tools/ping` | Ping 测试接口 |
| `/api/tools/dns` | DNS 查询接口 |
| `/api/tools/ssl` | SSL 检测接口 |
| `/api/tools/whois` | Whois 查询接口 |
| `/api/tools/{tool}/history` | 查询历史 |

## 4. API 定义

### 4.1 获取当前 IP

```typescript
// GET /api/ip-info
interface IpInfoResponse {
  ip: string;
  country: string;
  region: string;
  city: string;
  isp: string;
  asn: string;
  lat: number;
  lng: number;
  timezone: string;
}
```

### 4.2 IP 查询

```typescript
// POST /api/tools/ip
interface IpQueryRequest {
  target: string; // IP 或域名
}

interface IpQueryResponse {
  ip: string;
  country: string;
  region: string;
  city: string;
  isp: string;
  asn: string;
  lat: number;
  lng: number;
  timezone: string;
}
```

### 4.3 Ping 测试

```typescript
// POST /api/tools/ping
interface PingRequest {
  target: string;
  node?: string; // 节点 ID
}

interface PingResponse {
  resolvedIp: string;
  avgLatency: number; // ms
  packetLoss: number; // %
  status: 'success' | 'timeout' | 'error';
  node: string;
}
```

### 4.4 DNS 查询

```typescript
// POST /api/tools/dns
interface DnsRequest {
  domain: string;
  type: 'A' | 'AAAA' | 'CNAME' | 'MX' | 'NS' | 'TXT' | 'SOA';
}

interface DnsRecord {
  server: string;
  serverName: string;
  records: string[];
  responseTime: number;
}

interface DnsResponse {
  domain: string;
  type: string;
  results: DnsRecord[];
}
```

### 4.5 SSL 检测

```typescript
// POST /api/tools/ssl
interface SslRequest {
  domain: string;
}

interface SslResponse {
  domain: string;
  valid: boolean;
  issuer: string;
  validFrom: string;
  validTo: string;
  daysRemaining: number;
  subject: string;
  san: string[];
}
```

### 4.6 Whois 查询

```typescript
// POST /api/tools/whois
interface WhoisRequest {
  domain: string;
}

interface WhoisResponse {
  domain: string;
  registrar: string;
  creationDate: string;
  expirationDate: string;
  nameServers: string[];
  status: string[];
}
```

## 5. 服务端架构

```mermaid
flowchart LR
    A["API Route Handler"] --> B["Rate Limit Middleware"]
    B --> C["Auth Middleware"]
    C --> D["Tool Service"]
    D --> E["IP Lookup Service"]
    D --> F["Network Command Service"]
    D --> G["External API Service"]
    E --> H["MaxMind DB"]
    F --> I["dig / ping / openssl"]
    G --> J["WHOIS / DNS"]
```

## 6. 数据模型

### 6.1 ER 图

```mermaid
erDiagram
    USER ||--o{ QUERY_HISTORY : has
    USER ||--o{ MONITOR_TASK : owns
    USER {
        uuid id PK
        string email
        string password_hash
        string role
        int credits
        datetime created_at
    }
    QUERY_HISTORY {
        uuid id PK
        uuid user_id FK
        string tool_type
        string target
        json result
        datetime created_at
    }
    MONITOR_TASK {
        uuid id PK
        uuid user_id FK
        string name
        string type
        string target
        int interval
        string status
        datetime created_at
    }
```

### 6.2 建表语句（PostgreSQL）

```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'user',
    credits INT DEFAULT 100,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE query_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    tool_type VARCHAR(50) NOT NULL,
    target VARCHAR(255) NOT NULL,
    result JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_query_history_user_tool ON query_history(user_id, tool_type, created_at DESC);

CREATE TABLE monitor_tasks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL,
    target VARCHAR(255) NOT NULL,
    interval_seconds INT DEFAULT 300,
    status VARCHAR(50) DEFAULT 'active',
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

## 7. 项目目录结构

```
ipcesu.com/
├── app/                     # Next.js App Router
│   ├── layout.tsx           # 根布局
│   ├── page.tsx             # 首页
│   ├── globals.css          # 全局样式
│   ├── tools/
│   │   ├── page.tsx         # 工具集列表
│   │   ├── ip/page.tsx      # IP 查询
│   │   ├── ping/page.tsx    # Ping 测试
│   │   ├── dns/page.tsx     # DNS 查询
│   │   ├── ssl/page.tsx     # SSL 检测
│   │   └── whois/page.tsx   # Whois 查询
│   ├── api-docs/page.tsx    # API 文档
│   ├── user/
│   │   ├── login/page.tsx
│   │   └── register/page.tsx
│   └── api/
│       ├── ip-info/route.ts
│       └── tools/
│           ├── ip/route.ts
│           ├── ping/route.ts
│           ├── dns/route.ts
│           ├── ssl/route.ts
│           └── whois/route.ts
├── components/              # React 组件
│   ├── ui/                  # shadcn/ui 组件
│   ├── layout/              # 导航、页脚
│   ├── tools/               # 工具页面组件
│   └── home/                # 首页组件
├── lib/                     # 工具函数
│   ├── utils.ts
│   ├── ip-lookup.ts
│   └── rate-limit.ts
├── public/                  # 静态资源
├── prisma/                  # 数据库 schema
├── .env.example
├── next.config.js
├── tailwind.config.ts
├── tsconfig.json
└── package.json
```
