import Link from "next/link";
import { Activity } from "lucide-react";

const productLinks = [
  { label: "监控服务", href: "/monitor" },
  { label: "工具集", href: "/tools" },
  { label: "API接口", href: "/api-docs" },
  { label: "VIP会员", href: "/user/vip" },
];

const supportLinks = [
  { label: "帮助中心", href: "/article?category=帮助中心" },
  { label: "技术教程", href: "/article?category=技术教程" },
  { label: "网站公告", href: "/article?category=网站公告" },
  { label: "API文档", href: "/api-docs" },
];

export function Footer() {
  return (
    <footer className="border-t bg-muted/50">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2">
              <Activity className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold text-foreground">
                IPcesu 工具站
              </span>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed">
              IPcesu 是专业的在线网络工具站与网站质量监测平台，免费提供 Ping 测试、IP 查询、DNS 查询、SSL 检测、Whois 查询、网站测速、SEO 诊断等网络检测工具，助力网站运维与性能优化。
            </p>
          </div>

          <div>
            <h3 className="font-semibold mb-4 text-foreground">产品服务</h3>
            <ul className="space-y-2">
              {productLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4 text-foreground">帮助支持</h3>
            <ul className="space-y-2">
              {supportLinks.map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4 text-foreground">快捷入口</h3>
            <ul className="space-y-2">
              <li>
                <Link
                  href="/tools"
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  全部工具
                </Link>
              </li>
              <li>
                <Link
                  href="/monitor"
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  监控服务
                </Link>
              </li>
              <li>
                <Link
                  href="/article"
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  技术教程
                </Link>
              </li>
              <li>
                <Link
                  href="/user/login"
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  登录 / 注册
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <p>© 2026 IPcesu 工具站. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <Link href="#" className="hover:text-foreground transition-colors">
              隐私政策
            </Link>
            <Link href="#" className="hover:text-foreground transition-colors">
              服务条款
            </Link>
            <Link href="#" className="hover:text-foreground transition-colors">
              网站地图
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
