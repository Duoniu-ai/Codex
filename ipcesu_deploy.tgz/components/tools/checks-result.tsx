"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export type CheckStatus = "pass" | "warn" | "risk";

const statusConfig: Record<CheckStatus, { text: string; cls: string }> = {
  pass: { text: "通过", cls: "bg-green-100 text-green-700 border-green-200" },
  warn: { text: "提示", cls: "bg-amber-100 text-amber-700 border-amber-200" },
  risk: { text: "风险", cls: "bg-red-100 text-red-700 border-red-200" },
};

export function StatusBadge({ status }: { status: CheckStatus }) {
  return (
    <Badge variant="outline" className={statusConfig[status].cls}>
      {statusConfig[status].text}
    </Badge>
  );
}

interface ChecksResultProps {
  title?: string;
  score?: number;
  summary?: { total: number; pass: number; warn: number; risk: number };
  checks: Array<{ name: string; status: CheckStatus; detail: string }>;
  children?: React.ReactNode;
}

export function ChecksResult({
  title = "检测明细",
  score,
  summary,
  checks,
  children,
}: ChecksResultProps) {
  return (
    <div className="space-y-4">
      {children}

      {(score !== undefined || summary) && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {score !== undefined && (
            <Card className="border-l-4 border-l-foreground">
              <CardContent className="pt-6">
                <div className="text-sm text-muted-foreground">综合评分</div>
                <div className="text-3xl font-bold text-foreground">{score}</div>
              </CardContent>
            </Card>
          )}
          {summary && (
            <>
              <Card>
                <CardContent className="pt-6">
                  <div className="text-sm text-muted-foreground">检查总数</div>
                  <div className="text-2xl font-semibold">{summary.total}</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="text-sm text-muted-foreground">通过</div>
                  <div className="text-2xl font-semibold text-green-700">{summary.pass}</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="text-sm text-muted-foreground">风险</div>
                  <div className="text-2xl font-semibold text-red-700">{summary.risk}</div>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      )}

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>{title}</CardTitle>
          <CardDescription>逐项检查结果</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>检查项</TableHead>
                  <TableHead className="w-24">状态</TableHead>
                  <TableHead>说明</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {checks.map((check) => (
                  <TableRow key={check.name}>
                    <TableCell className="font-medium text-foreground whitespace-normal">
                      {check.name}
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={check.status} />
                    </TableCell>
                    <TableCell className="text-muted-foreground whitespace-normal break-all">
                      {check.detail}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
