"use client";

import { ReactNode, useMemo } from "react";
import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  ChevronRight,
  Home,
  Lightbulb,
  ListChecks,
  HelpCircle,
  ArrowRight,
  Sparkles,
} from "lucide-react";
import { tools, aiTools, toolCategories } from "@/lib/tools";
import { toolFaqs, categoryContent } from "@/lib/tool-content";
import {
  buildBreadcrumbSchema,
  buildFaqSchema,
  buildWebApplicationSchema,
} from "@/lib/seo";
import type { LucideIcon } from "lucide-react";

interface ToolPageLayoutProps {
  title: string;
  description: string;
  icon: LucideIcon;
  children: ReactNode;
  tips: string[];
}

export function ToolPageLayout({
  title,
  description,
  icon: Icon,
  children,
  tips,
}: ToolPageLayoutProps) {
  const tool = useMemo(
    () => [...tools, ...aiTools].find((t) => t.label === title),
    [title]
  );
  const category = useMemo(
    () => toolCategories.find((c) => c.id === tool?.category),
    [tool]
  );
  const faqs = useMemo(() => toolFaqs[title] || [], [title]);
  const content = useMemo(
    () =>
      tool && tool.category ? categoryContent[tool.category] : null,
    [tool]
  );
  const related = useMemo(
    () =>
      tool
        ? [...tools, ...aiTools]
            .filter((t) => t.category === tool.category && t.href !== tool.href)
            .slice(0, 6)
        : [],
    [tool]
  );

  const breadcrumbSchema = buildBreadcrumbSchema([
    { name: "首页", path: "/" },
    { name: "工具集", path: "/tools" },
    ...(category ? [{ name: category.label, path: "/tools" }] : []),
    { name: title, path: tool?.href || "/tools" },
  ]);
  const faqSchema = buildFaqSchema(faqs);
  const webAppSchema = buildWebApplicationSchema({
    name: title,
    description,
    path: tool?.href || "/tools",
  });

  const schemaJson = JSON.stringify([
    breadcrumbSchema,
    ...(faqs.length > 0 ? [faqSchema] : []),
    webAppSchema,
  ]);

  return (
    <main className="container mx-auto px-4 py-6 md:py-10">
      <article className="max-w-6xl mx-auto">
        <nav
          aria-label="面包屑"
          className="mb-5 flex flex-wrap items-center gap-1 text-sm text-muted-foreground"
        >
          <Link
            href="/"
            className="inline-flex items-center gap-1 hover:text-foreground transition-colors"
          >
            <Home className="h-3.5 w-3.5" />
            首页
          </Link>
          <ChevronRight className="h-3.5 w-3.5 shrink-0" />
          <Link
            href="/tools"
            className="hover:text-foreground transition-colors"
          >
            工具集
          </Link>
          {category && (
            <>
              <ChevronRight className="h-3.5 w-3.5 shrink-0" />
              <span className="text-muted-foreground">{category.label}</span>
            </>
          )}
          <ChevronRight className="h-3.5 w-3.5 shrink-0" />
          <span className="font-medium text-foreground" aria-current="page">
            {title}
          </span>
        </nav>

        <header className="mb-8">
          <div className="flex items-center gap-3 mb-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <Icon className="h-6 w-6" aria-hidden="true" />
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">
              {title}
            </h1>
          </div>
          <p className="text-muted-foreground text-sm max-w-3xl">{description}</p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <section
            className="lg:col-span-2 space-y-6"
            aria-label={`${title}操作区`}
          >
            {children}
          </section>

          <aside className="lg:col-span-1">
            <Card className="border-border/40 bg-card shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-base text-foreground flex items-center gap-2">
                  <Lightbulb className="h-4 w-4 text-primary" />
                  使用说明
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <ul className="space-y-3">
                  {tips.map((tip, index) => (
                    <li
                      key={index}
                      className="text-sm text-muted-foreground flex items-start gap-2"
                    >
                      <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary text-xs font-medium">
                        {index + 1}
                      </span>
                      {tip}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </aside>
        </div>

        {content && (
          <section className="mt-10 space-y-6" aria-label={`${title}介绍`}>
            <Card className="border-border/40 bg-card shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg text-foreground flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-primary" />
                  什么是{title}？
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {description}。{content.intro}
                </p>
              </CardContent>
            </Card>

            <Card className="border-border/40 bg-card shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg text-foreground flex items-center gap-2">
                  <ListChecks className="h-5 w-5 text-primary" />
                  如何使用{title}？
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <ol className="space-y-2.5">
                  {content.usage.map((step, index) => (
                    <li
                      key={index}
                      className="flex items-start gap-3 text-sm text-muted-foreground"
                    >
                      <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary text-xs font-medium">
                        {index + 1}
                      </span>
                      <span className="leading-relaxed pt-0.5">{step}</span>
                    </li>
                  ))}
                </ol>
              </CardContent>
            </Card>

            {related.length > 0 && (
              <Card className="border-border/40 bg-card shadow-sm">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg text-foreground flex items-center gap-2">
                    <ArrowRight className="h-5 w-5 text-primary" />
                    相关工具推荐
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
                    {related.map((item) => (
                      <Link
                        key={item.href}
                        href={item.href}
                        title={item.description}
                        className="flex flex-col items-start gap-1.5 rounded-lg border border-border/50 bg-secondary/30 p-3 text-foreground transition-colors hover:bg-secondary hover:border-border"
                      >
                        <item.icon className="h-4 w-4 text-primary" />
                        <span className="text-xs font-medium line-clamp-2">
                          {item.label}
                        </span>
                      </Link>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {faqs.length > 0 && (
              <Card className="border-border/40 bg-card shadow-sm">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg text-foreground flex items-center gap-2">
                    <HelpCircle className="h-5 w-5 text-primary" />
                    {title}常见问题
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-4">
                    {faqs.map((faq) => (
                      <div key={faq.question} className="space-y-1.5">
                        <h3 className="text-sm font-semibold text-foreground">
                          {faq.question}
                        </h3>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {faq.answer}
                        </p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </section>
        )}

        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: schemaJson }}
        />
      </article>
    </main>
  );
}
