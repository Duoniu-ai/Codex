"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import {
  Type,
  Code,
  TrendingUp,
  Shield,
  Sparkles,
  FileCode,
  Languages,
  Image as ImageIcon,
  ArrowRight,
} from "lucide-react";
import { tools, aiTools, toolCategories } from "@/lib/tools";
import { Hero } from "@/components/home/hero";
import { Stats } from "@/components/home/stats";
import "@/app/home-v2.css";

const categoryOrder = ["network", "speed", "batch", "analysis", "domain", "security", "seo", "dev"];

const categoryTagMap: Record<string, string> = {
  network: "NET",
  speed: "SPD",
  batch: "BAT",
  analysis: "DATA",
  domain: "DOM",
  security: "SEC",
  seo: "SEO",
  dev: "DEV",
};

const newsData = [
  {
    title: "技术教程",
    href: "/article?category=技术教程",
    items: [
      { title: "网络延迟优化的 10 个技巧", date: "11-15", href: "/article/11" },
      { title: "如何解读 Ping 测试结果", date: "11-14", href: "/article/12" },
      { title: "Traceroute 路由追踪原理详解", date: "11-13", href: "/article/13" },
      { title: "网络延迟与丢包率的关系分析", date: "11-12", href: "#" },
      { title: "TCP 与 UDP 在网络检测中的区别", date: "11-11", href: "#" },
    ],
  },
  {
    title: "帮助中心",
    href: "/article?category=帮助中心",
    items: [
      { title: "如何正确使用在线 Ping 工具", date: "11-25", href: "#" },
      { title: "网站测速结果异常怎么办", date: "11-24", href: "#" },
      { title: "TCPing 检测失败的原因分析", date: "11-23", href: "#" },
      { title: "路由追踪结果中的星号是什么意思", date: "11-22", href: "#" },
      { title: "DNS 查询结果如何解读", date: "11-21", href: "#" },
    ],
  },
  {
    title: "网站公告",
    href: "/article?category=网站公告",
    items: [
      { title: "全新功能上线公告", date: "12-01", href: "#" },
      { title: "网站服务器升级维护通知", date: "11-28", href: "#" },
      { title: "数据安全与隐私保护政策更新", date: "11-25", href: "#" },
      { title: "网站使用条款变更说明", date: "11-20", href: "#" },
      { title: "新工具上线：IPv6 检测功能", date: "11-15", href: "#" },
    ],
  },
];

export function HomeClient() {
  const [activeTab, setActiveTab] = useState("network");

  const orderedCategories = useMemo(
    () =>
      categoryOrder
        .map((id) => toolCategories.find((c) => c.id === id))
        .filter(Boolean) as typeof toolCategories,
    []
  );

  const activeTools = useMemo(
    () => tools.filter((t) => t.category === activeTab),
    [activeTab]
  );

  return (
    <div className="home-v2">
      <Hero />

      <Stats />

      <section id="tools">
        <div className="wrap">
          <div className="section-top">
            <div className="section-head">
              <h2>工具广场</h2>
              <p>按场景分类的全套检测工具，从单点排查到批量巡检。</p>
            </div>
            <Link className="more-link" href="/tools">
              查看全部工具 →
            </Link>
          </div>

          <div className="tabs">
            {orderedCategories.map((category) => (
              <button
                key={category.id}
                type="button"
                className={`tab ${activeTab === category.id ? "active" : ""}`}
                onClick={() => setActiveTab(category.id)}
              >
                {category.label}
              </button>
            ))}
          </div>
          <div className="tool-grid">
            {activeTools.map((tool) => (
              <Link key={tool.id} href={tool.href} className="tool-card">
                <span className="tag">{categoryTagMap[tool.category] || "TOOL"}</span>
                <h4>{tool.label}</h4>
                <p>{tool.description}</p>
                <span className="go">打开工具 →</span>
              </Link>
            ))}
            {Array.from({ length: (3 - (activeTools.length % 3)) % 3 }).map((_, i) => (
              <div key={`placeholder-${i}`} className="tool-card tool-card-placeholder" aria-hidden="true" />
            ))}
          </div>
        </div>
      </section>

      <section className="ai-section" id="ai">
        <div className="wrap">
          <div className="section-top">
            <div className="section-head">
              <h2>AI 智能工具</h2>
              <p>基于大模型的辅助能力，把检测结果变成可执行的建议。</p>
            </div>
            <Link className="more-link" href="/ai-tools">
              探索更多 →
            </Link>
          </div>
          <div className="ai-grid">
            {aiTools.map((tool, idx) => {
              const glyphs = [
                <Sparkles key="1" className="h-4 w-4" />,
                <Type key="2" className="h-4 w-4" />,
                <Code key="3" className="h-4 w-4" />,
                <TrendingUp key="4" className="h-4 w-4" />,
                <Shield key="5" className="h-4 w-4" />,
                <FileCode key="6" className="h-4 w-4" />,
                <Languages key="7" className="h-4 w-4" />,
                <ImageIcon key="8" className="h-4 w-4" />,
              ];
              return (
                <Link key={tool.id} href={tool.href} className="ai-card">
                  <div className="glyph">{glyphs[idx % glyphs.length]}</div>
                  <h4>{tool.label}</h4>
                  <p>{tool.description}</p>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      <section id="news">
        <div className="wrap">
          <div className="section-top">
            <div className="section-head">
              <h2>热门资讯</h2>
              <p>技术教程、帮助中心与网站公告。</p>
            </div>
            <Link className="more-link" href="/article">
              更多资讯 →
            </Link>
          </div>
          <div className="news-grid">
            {newsData.map((col) => (
              <div className="news-col" key={col.title}>
                <h3>
                  {col.title} <Link href={col.href}>更多</Link>
                </h3>
                <ul>
                  {col.items.map((item, i) => (
                    <li key={i}>
                      <Link href={item.href}>{item.title}</Link>
                      <time>{item.date}</time>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="monitor" className="on-soft">
        <div className="wrap split">
          <div>
            <div className="eyebrow">
              <span className="dot pulse"></span>监控服务
            </div>
            <h2 style={{ fontSize: 26 }}>7×24 小时网站监控</h2>
            <p style={{ color: "var(--text-secondary)", marginTop: 12 }}>
              实时监控网站可用性、响应时间、SSL 证书等关键指标，第一时间发现故障并告警通知。
            </p>
            <ul>
              <li>全球 100+ 监测节点</li>
              <li>多种监控类型：HTTP、Ping、TCP、SSL</li>
              <li>微信、邮件、钉钉多渠道告警</li>
              <li>详细的历史数据和趋势分析</li>
            </ul>
            <div className="btn-row">
              <Link className="btn btn-primary" href="/monitor">
                进入控制台 <ArrowRight className="h-4 w-4" />
              </Link>
              <Link className="btn btn-ghost" href="/monitor">
                了解详情
              </Link>
            </div>
          </div>

          <div className="dash-card">
            <div className="dash-head">
              <span>实时监控概览</span>
              <span className="live-tag">
                <span className="dot"></span> 运行中
              </span>
            </div>
            <div className="dash-stats">
              <div>
                <div className="n">99.9%</div>
                <div className="l">可用率</div>
              </div>
              <div>
                <div className="n">45ms</div>
                <div className="l">平均响应</div>
              </div>
              <div>
                <div className="n">12</div>
                <div className="l">监控任务</div>
              </div>
            </div>
            <div className="term">
              <div className="l1">$ curl -X POST https://api.ipcesu.com/v1/ping \</div>
              <div className="l1">{`  -H "Authorization: Bearer YOUR_KEY" \\`}</div>
              <div className="l1">
                {`  -d '{"target": "example.com", "nodes": ["beijing","shanghai"]}'`}
              </div>
              <div className="out">
                {`{"status": "success", "avg": "45ms"}`}<span className="cursor"></span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="api">
        <div className="wrap">
          <div className="eyebrow">
            <span className="dot pulse"></span>开发者
          </div>
          <h2 style={{ fontSize: 26, maxWidth: 560 }}>开放 API 接口</h2>
          <p style={{ color: "var(--text-secondary)", marginTop: 12, maxWidth: 560 }}>
            提供标准化 RESTful API，支持 Ping 测试、DNS 查询、SSL 检测等核心功能，轻松集成到您的业务系统。
          </p>
          <div className="feat-row">
            <div>
              <div className="n">快速响应</div>
              <p>毫秒级返回检测结果</p>
            </div>
            <div>
              <div className="n">安全认证</div>
              <p>Bearer Token 鉴权</p>
            </div>
            <div>
              <div className="n">详细文档</div>
              <p>覆盖全部接口说明</p>
            </div>
            <div>
              <div className="n">调用统计</div>
              <p>用量与状态实时可查</p>
            </div>
          </div>
          <div className="btn-row">
            <Link className="btn btn-primary" href="/api-docs">
              查看 API 文档 <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      <section id="seo-content" className="wrap" style={{ borderBottom: "none" }}>
        <div className="section-top">
          <div className="section-head">
            <h2>一站式免费在线网络检测工具平台</h2>
            <p>
              从网络连通性到网站性能，从域名安全到 SEO
              优化，IPcesu 提供 45+ 款免费在线工具，覆盖站长、运维与开发者的日常检测需求，无需安装打开即用。
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            {
              title: "网络检测工具",
              intro: "诊断网络连通性、延迟与路由，快速定位网络故障。",
              links: [
                ["Ping 测试", "/ping"],
                ["IP 查询", "/ip"],
                ["DNS 查询", "/dns"],
                ["路由追踪", "/traceroute"],
                ["TCPing", "/tcping"],
                ["BGP 路由查询", "/bgp"],
              ],
            },
            {
              title: "网站性能与安全",
              intro: "检测网站速度、证书与安全配置，发现潜在风险。",
              links: [
                ["网站测速", "/speed"],
                ["HTTP 检测", "/http"],
                ["SSL 检测", "/ssl"],
                ["端口扫描", "/portscan"],
                ["网站安全检测", "/security"],
                ["WAF 检测", "/waf"],
              ],
            },
            {
              title: "域名与 SEO 优化",
              intro: "查询域名信息、备案状态，逐项优化搜索引擎表现。",
              links: [
                ["Whois 查询", "/whois"],
                ["ICP 备案", "/icp"],
                ["CDN 检测", "/cdn"],
                ["SEO 检测", "/seo"],
                ["SEO 诊断", "/seo-diagnosis"],
                ["Robots 检测", "/robots-txt"],
              ],
            },
            {
              title: "批量与开发工具",
              intro: "批量巡检服务器与站点，常用编码转换开箱即用。",
              links: [
                ["批量 Ping", "/batch-ping"],
                ["批量 TCPing", "/batch-tcping"],
                ["批量 HTTP(S)", "/batch-http"],
                ["JSON 格式化", "/json"],
                ["Base64 编解码", "/base64"],
                ["Hash 生成器", "/hash"],
              ],
            },
          ].map((block) => (
            <div
              key={block.title}
              className="rounded-2xl border border-border/50 bg-card p-5"
            >
              <h3 className="text-lg font-semibold text-foreground">
                {block.title}
              </h3>
              <p className="mt-1.5 text-sm text-muted-foreground">
                {block.intro}
              </p>
              <ul className="mt-4 grid grid-cols-2 gap-x-3 gap-y-2">
                {block.links.map(([label, href]) => (
                  <li key={href}>
                    <Link
                      href={href}
                      className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors"
                    >
                      <ArrowRight className="h-3.5 w-3.5" />
                      {label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      <section className="cta" style={{ borderBottom: "none" }}>
        <div className="wrap">
          <h2>开始使用 IPcesu 工具站</h2>
          <p>注册即可获得免费积分，体验所有工具和监控服务。</p>
          <div className="btn-row">
            <Link className="btn btn-primary" href="/user/register">
              免费注册 <ArrowRight className="h-4 w-4" />
            </Link>
            <Link className="btn btn-ghost" href="/user/vip">
              查看 VIP 特权
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
