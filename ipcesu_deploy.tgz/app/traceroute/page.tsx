"use client";

import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Route, Server, MapPin, Clock } from "lucide-react";

interface Hop {
  hop: number;
  ip: string | null;
  loss: number;
  sent: number;
  last: number | null;
  avg: number | null;
  best: number | null;
  worst: number | null;
  stdev: number | null;
}

interface TracerouteResult {
  target: string;
  resolvedIp: string;
  node: string;
  hops: Hop[];
}

export default function TraceroutePage() {
  return (
    <Suspense fallback={<TraceroutePageSkeleton />}>
      <TraceroutePageForm />
    </Suspense>
  );
}

function TraceroutePageSkeleton() {
  return (
    <ToolPageLayout
      title="路由追踪"
      description="追踪数据包到目标地址经过的路由节点"
      icon={Route}
      tips={[
        "输入域名或 IP 地址即可追踪路由路径",
        "显示每一跳的 IP、地理位置和延迟",
        "支持 IPv4 地址测试",
        "路由追踪由服务器真实执行（MTR 报告）",
      ]}
    >
      <div className="space-y-3">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
      </div>
    </ToolPageLayout>
  );
}

function TraceroutePageForm() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get("q") || "";

  const [target, setTarget] = useState(initialQuery);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<TracerouteResult | null>(null);
  const [error, setError] = useState("");

  const handleTrace = async () => {
    if (!target.trim()) return;

    setLoading(true);
    setError("");
    setResult(null);

    try {
      const res = await fetch("/api/traceroute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ target: target.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "测试失败");
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "测试失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ToolPageLayout
      title="路由追踪"
      description="追踪数据包到目标地址经过的路由节点"
      icon={Route}
      tips={[
        "输入域名或 IP 地址即可追踪路由路径",
        "显示每一跳的 IP、地理位置和延迟",
        "支持 IPv4 地址测试",
        "路由追踪由服务器真实执行（MTR 报告）",
      ]}
    >
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <Input
          value={target}
          onChange={(e) => setTarget(e.target.value)}
          placeholder="例如：baidu.com 或 8.8.8.8"
          className="flex-1 bg-secondary/50 border-border/50"
        />
        <Button
          onClick={handleTrace}
          disabled={loading}
          className="bg-foreground hover:bg-foreground/90 text-background"
        >
          {loading ? "追踪中..." : "开始追踪"}
        </Button>
      </div>

      {error && (
        <div className="p-4 rounded-lg bg-destructive/10 text-destructive text-sm mb-6">
          {error}
        </div>
      )}

      {loading && (
        <div className="space-y-3">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
        </div>
      )}

      {result && !loading && (
        <div className="space-y-4 animate-fade-in-up">
          <div className="flex flex-wrap items-center gap-3 mb-4">
            <Badge variant="secondary" className="bg-foreground text-background hover:bg-foreground/90 border-0">
              {result.hops.length} 跳
            </Badge>
            <span className="text-sm text-muted-foreground flex items-center gap-1">
              <Server className="h-3.5 w-3.5" />
              目标 IP：{result.resolvedIp}
            </span>
          </div>

          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-3 text-muted-foreground text-sm">
                <MapPin className="h-4 w-4 text-foreground" />
                追踪结果
              </div>
              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-20">跳数</TableHead>
                      <TableHead>IP 地址</TableHead>
                      <TableHead className="w-24">丢包率</TableHead>
                      <TableHead className="w-28">平均延迟</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {result.hops.map((hop) => (
                      <TableRow key={hop.hop}>
                        <TableCell className="font-mono">{hop.hop}</TableCell>
                        <TableCell className="font-mono text-foreground">
                          {hop.ip || "???"}
                        </TableCell>
                        <TableCell className="text-foreground">
                          {hop.loss.toFixed(0)} %
                        </TableCell>
                        <TableCell>
                          {hop.avg !== null ? (
                            <span className="flex items-center gap-1 text-foreground">
                              <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                              {hop.avg.toFixed(1)} ms
                            </span>
                          ) : (
                            <span className="text-muted-foreground">超时</span>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </ToolPageLayout>
  );
}
