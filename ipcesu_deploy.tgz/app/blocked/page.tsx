"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Lock, Server, Globe, Clock } from "lucide-react";

interface BlockedResult {
  target: string;
  resolvedIp: string;
  verdict: "normal" | "blocked" | "unreachable" | "unknown";
  status: "pass" | "warn" | "risk";
  conclusion: string;
  local: {
    tcp443: string;
    tcp80: string;
    httpOk: boolean;
    httpCode: number;
    httpTime: number;
    ok: boolean;
  };
  overseas: {
    ok: boolean;
    nodes: Array<{ name: string; ok: boolean; detail: string }>;
  };
}

const verdictConfig = {
  normal: { label: "未被墙", cls: "bg-green-100 text-green-700 border-green-200" },
  blocked: { label: "疑似被墙", cls: "bg-red-100 text-red-700 border-red-200" },
  unreachable: { label: "目标不可达", cls: "bg-red-100 text-red-700 border-red-200" },
  unknown: { label: "无法判定", cls: "bg-amber-100 text-amber-700 border-amber-200" },
};

export default function Page() {
  return (
    <SimulatedToolPage
      title="被墙检测"
      description="检测网站或 IP 是否在中国大陆被屏蔽"
      icon={Lock}
      tips={[
        "工具从国内服务器真实探测 TCP/HTTP，并与海外节点结果对比。",
        "海外可访问、国内不可达时判定为疑似被墙。",
        "建议结合多个节点和时段综合判断。",
      ]}
      inputs={[
        { id: "target", label: "域名或 IP", type: "text", placeholder: "example.com" },
      ]}
      demo={false}
      onRun={async (values) => {
        const res = await fetch("/api/blocked", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ target: values.target.trim() }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "检测失败");
        return data as BlockedResult;
      }}
      renderResult={(result) => {
        const data = result as BlockedResult;
        return (
          <div className="space-y-4">
            <Card className="border-l-4 border-l-foreground">
              <CardContent className="pt-6">
                <div className="text-sm text-muted-foreground mb-2">综合判断</div>
                <Badge variant="outline" className={verdictConfig[data.verdict].cls}>
                  {verdictConfig[data.verdict].label}
                </Badge>
                <p className="text-sm text-muted-foreground mt-3 leading-relaxed">
                  {data.conclusion}
                </p>
              </CardContent>
            </Card>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">解析 IP</div><div className="font-mono text-sm font-medium mt-1 break-all">{data.resolvedIp}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">TCP 443</div><div className="text-xl font-semibold mt-1">{data.local.tcp443 === "open" ? "开放" : "失败"}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">TCP 80</div><div className="text-xl font-semibold mt-1">{data.local.tcp80 === "open" ? "开放" : "失败"}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">国内 HTTP</div><div className="text-xl font-semibold mt-1">{data.local.httpOk ? data.local.httpCode : "失败"}</div></CardContent></Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>海外节点对比（check-host.net）</CardTitle>
                <CardDescription>海外节点 HTTP 可达性，用于判定是否被墙</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>节点</TableHead>
                      <TableHead>状态</TableHead>
                      <TableHead>响应</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.overseas.nodes.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={3} className="text-muted-foreground">
                          海外节点检测暂不可用
                        </TableCell>
                      </TableRow>
                    )}
                    {data.overseas.nodes.map((node) => (
                      <TableRow key={node.name}>
                        <TableCell className="font-mono text-sm break-all">{node.name}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className={node.ok ? "bg-green-100 text-green-700 border-green-200" : "bg-red-100 text-red-700 border-red-200"}>
                            {node.ok ? "可达" : "不可达"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-muted-foreground">{node.detail}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}
