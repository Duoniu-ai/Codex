"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { ChecksResult } from "@/components/tools/checks-result";
import { Search } from "lucide-react";

interface SeoDiagnosisResult {
  url: string;
  finalUrl: string;
  statusCode: number;
  score: number;
  summary: { total: number; pass: number; warn: number; risk: number };
  checks: Array<{ name: string; status: "pass" | "warn" | "risk"; detail: string }>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="SEO 诊断"
      description="网站 SEO 问题诊断"
      icon={Search}
      tips={[
        "服务器真实抓取页面，逐项诊断 15 项 SEO 关键配置。",
        "输出综合评分与通过/提示/风险统计。",
        "优先处理风险项：noindex、canonical 缺失、H1 缺失。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      demo={false}
      onRun={async (values) => {
        const res = await fetch("/api/seo-diagnosis", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ target: values.url.trim() }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "诊断失败");
        return data as SeoDiagnosisResult;
      }}
      renderResult={(result) => {
        const data = result as SeoDiagnosisResult;
        return (
          <ChecksResult score={data.score} summary={data.summary} checks={data.checks} />
        );
      }}
    />
  );
}
