"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { TrendingUp } from "lucide-react";

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "优秀", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "建议", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "需优化", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="SEO 优化"
      description="全面 SEO 优化建议"
      icon={TrendingUp}
      tips={[
        "输入目标 URL 获取整站 SEO 优化建议。",
        "优先处理标记为“需优化”的高风险项。",
        "建议定期复查，持续跟踪优化效果。",
        "结果由服务器真实抓取页面并逐项检测生成。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      demo={false}
      onRun={async (values) => {
        const res = await fetch("/api/optimization", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ target: values.url.trim() }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "分析失败");
        return data;
      }}
      renderResult={(result) => {
        const data = result as {
          score: number;
          suggestions: { name: string; status: "pass" | "warn" | "risk"; detail: string }[];
        };
        return (
          <div className="space-y-4">
            <Card className="border-l-4 border-l-foreground">
              <CardContent className="pt-6">
                <div className="text-sm text-muted-foreground">优化评分</div>
                <div className="text-3xl font-bold">{data.score}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>优化建议</CardTitle>
                <CardDescription>按优先级给出的可执行优化项</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>优化项</TableHead>
                      <TableHead>评级</TableHead>
                      <TableHead>说明</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.suggestions.map((item) => (
                      <TableRow key={item.name}>
                        <TableCell>{item.name}</TableCell>
                        <TableCell>{statusBadge(item.status)}</TableCell>
                        <TableCell className="whitespace-normal">{item.detail}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}
