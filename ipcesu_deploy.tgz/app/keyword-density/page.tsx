"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Hash } from "lucide-react";

interface KeywordDensityResult {
  url: string;
  keyword: string;
  occurrences: number;
  totalWords: number;
  density: number;
  densityStatus: "low" | "good" | "high";
  topWords: Array<{ word: string; count: number }>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="关键词密度"
      description="页面关键词分布分析"
      icon={Hash}
      tips={[
        "输入目标 URL 和关键词，工具真实抓取页面并统计密度。",
        "建议关键词密度在 1%-3% 之间。",
        "同时列出页面高频词供内容优化参考。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
        { id: "keyword", label: "关键词", type: "text", placeholder: "例如：网络延迟" },
      ]}
      demo={false}
      onRun={async (values) => {
        const res = await fetch("/api/keyword-density", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            target: values.url.trim(),
            keyword: values.keyword.trim(),
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "检测失败");
        return data as KeywordDensityResult;
      }}
      renderResult={(result) => {
        const data = result as KeywordDensityResult;
        const densityConfig = {
          low: { text: "偏低", cls: "bg-amber-100 text-amber-700 border-amber-200" },
          good: { text: "适中", cls: "bg-green-100 text-green-700 border-green-200" },
          high: { text: "偏高", cls: "bg-red-100 text-red-700 border-red-200" },
        };
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground">关键词</div>
                  <div className="text-lg font-semibold break-all mt-1">{data.keyword}</div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground">出现次数</div>
                  <div className="text-2xl font-semibold mt-1">{data.occurrences}</div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground">总字数</div>
                  <div className="text-2xl font-semibold mt-1">{data.totalWords}</div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground">密度</div>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-2xl font-semibold">{data.density}%</span>
                    <Badge variant="outline" className={densityConfig[data.densityStatus].cls}>
                      {densityConfig[data.densityStatus].text}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle>页面高频词</CardTitle>
                <CardDescription>出现次数 ≥ 2 的词频统计</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-16">序号</TableHead>
                        <TableHead>词汇</TableHead>
                        <TableHead>次数</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {data.topWords.map((w, i) => (
                        <TableRow key={`${w.word}-${i}`}>
                          <TableCell className="font-mono text-muted-foreground">{i + 1}</TableCell>
                          <TableCell className="font-medium break-all">{w.word}</TableCell>
                          <TableCell>{w.count}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}
