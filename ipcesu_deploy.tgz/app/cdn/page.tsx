"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Server, Link as LinkIcon, CheckCircle, ShieldAlert } from "lucide-react";

interface CdnResult {
  url: string;
  host: string;
  status: "pass" | "warn";
  detected: string[];
  cnameChain: string[];
  headers: Array<{ header: string; value: string }>;
  checks: Array<{ name: string; status: "pass" | "warn" | "risk"; detail: string }>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="CDN 检测"
      description="CDN 厂商识别"
      icon={Server}
      tips={[
        "输入域名或 URL，工具真实请求站点并解析 CNAME 链路。",
        "通过响应头和 CNAME 特征识别 CDN 厂商。",
        "未识别到 CDN 特征时可能为源站直连。",
      ]}
      inputs={[
        { id: "domain", label: "域名", type: "text", placeholder: "例如：baidu.com" },
      ]}
      demo={false}
      onRun={async (values) => {
        const res = await fetch("/api/cdn", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ target: values.domain.trim() }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "检测失败");
        return data as CdnResult;
      }}
      renderResult={(result) => {
        const data = result as CdnResult;
        return (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-3">
              {data.detected.length > 0 ? (
                data.detected.map((v) => (
                  <Badge key={v} variant="secondary" className="bg-foreground text-background hover:bg-foreground/90 border-0">
                    {v}
                  </Badge>
                ))
              ) : (
                <Badge variant="outline" className="bg-amber-100 text-amber-700 border-amber-200">
                  未识别（可能直连源站）
                </Badge>
              )}
              <span className="text-sm text-muted-foreground">检测域名：{data.host}</span>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>CNAME 解析链</CardTitle>
                <CardDescription>DNS CNAME 记录追踪</CardDescription>
              </CardHeader>
              <CardContent>
                {data.cnameChain.length > 0 ? (
                  <div className="flex flex-wrap items-center gap-2 font-mono text-sm">
                    <span>{data.host}</span>
                    {data.cnameChain.map((c, i) => (
                      <span key={i} className="flex items-center gap-2">
                        <span className="text-muted-foreground">→</span>
                        <span className="break-all">{c}</span>
                      </span>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">未检测到 CNAME 记录（可能使用 A 记录直连）</p>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>CDN 特征响应头</CardTitle>
                <CardDescription>判断依据</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-48">响应头</TableHead>
                      <TableHead>值</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.headers.map((item) => (
                      <TableRow key={item.header}>
                        <TableCell className="font-mono text-sm">{item.header}</TableCell>
                        <TableCell className="font-mono text-sm break-all text-muted-foreground">{item.value}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {data.checks.map((check) => (
                <Card key={check.name} className="border-border/50 bg-card">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-foreground">{check.name}</span>
                      {check.status === "pass" ? (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      ) : (
                        <ShieldAlert className="h-4 w-4 text-amber-600" />
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">{check.detail}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        );
      }}
    />
  );
}
