"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { ChecksResult } from "@/components/tools/checks-result";
import { Card, CardContent } from "@/components/ui/card";
import { Type } from "lucide-react";

interface TdkResult {
  url: string;
  title: string;
  description: string;
  keywords: string;
  titleLength: number;
  descriptionLength: number;
  checks: Array<{ name: string; status: "pass" | "warn" | "risk"; detail: string }>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="TDK 检测"
      description="标题、描述、关键词检测"
      icon={Type}
      tips={[
        "读取页面真实的 Title、Description、Keywords 并对照最佳长度。",
        "标题建议 10-60 字，描述建议 50-160 字。",
        "检测由服务器真实抓取页面完成。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      demo={false}
      onRun={async (values) => {
        const res = await fetch("/api/tdk-check", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ target: values.url.trim() }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "检测失败");
        return data as TdkResult;
      }}
      renderResult={(result) => {
        const data = result as TdkResult;
        return (
          <ChecksResult checks={data.checks}>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground mb-1">
                    Title（{data.titleLength} 字）
                  </div>
                  <div className="text-sm font-medium text-foreground break-all">
                    {data.title}
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground mb-1">
                    Description（{data.descriptionLength} 字）
                  </div>
                  <div className="text-sm text-muted-foreground line-clamp-3 break-all">
                    {data.description}
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground mb-1">Keywords</div>
                  <div className="text-sm text-muted-foreground break-all">
                    {data.keywords}
                  </div>
                </CardContent>
              </Card>
            </div>
          </ChecksResult>
        );
      }}
    />
  );
}
