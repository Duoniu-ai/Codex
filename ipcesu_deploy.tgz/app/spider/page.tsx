"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Bug, CheckCircle, ShieldAlert } from "lucide-react";

interface SpiderResult {
  url: string;
  finalUrl: string;
  normalStatus: number;
  googlebotStatus: number;
  googlebotSize: number;
  normalSize: number;
  title: string;
  description: string;
  metaRobots: string | null;
  robotsContent: string;
  checks: Array<{ name: string; status: "pass" | "warn" | "risk"; detail: string }>;
}

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "允许", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "受限", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "禁止", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="蜘蛛抓取"
      description="模拟搜索引擎蜘蛛抓取"
      icon={Bug}
      tips={[
        "以 Googlebot UA 真实请求目标页面，对比普通 UA 的响应。",
        "检查 robots.txt 与 meta robots 是否屏蔽页面。",
        "帮助判断搜索引擎能否正常抓取和收录。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      demo={false}
      onRun={async (values) => {
        const res = await fetch("/api/spider", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ target: values.url.trim() }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "检测失败");
        return data as SpiderResult;
      }}
      renderResult={(result) => {
        const data = result as SpiderResult;
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">普通 UA 状态</div><div className="text-2xl font-semibold">{data.normalStatus}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">Googlebot 状态</div><div className="text-2xl font-semibold">{data.googlebotStatus || "--"}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">标题 / 描述</div><div className="text-sm font-medium mt-1 line-clamp-2">{data.title || "--"}</div></CardContent></Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>抓取检查</CardTitle>
                <CardDescription>搜索引擎抓取与收录条件</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>检查项</TableHead>
                      <TableHead>状态</TableHead>
                      <TableHead>说明</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.checks.map((c) => (
                      <TableRow key={c.name}>
                        <TableCell>{c.name}</TableCell>
                        <TableCell>{statusBadge(c.status)}</TableCell>
                        <TableCell className="whitespace-normal text-muted-foreground">{c.detail}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            {data.robotsContent && (
              <Card>
                <CardHeader>
                  <CardTitle>robots.txt 内容</CardTitle>
                </CardHeader>
                <CardContent>
                  <pre className="text-xs font-mono p-3 rounded-lg bg-secondary/50 overflow-auto max-h-48 text-foreground">
                    {data.robotsContent}
                  </pre>
                </CardContent>
              </Card>
            )}
          </div>
        );
      }}
    />
  );
}
