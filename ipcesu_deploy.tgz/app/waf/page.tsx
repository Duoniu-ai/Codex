"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { ChecksResult } from "@/components/tools/checks-result";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Fingerprint } from "lucide-react";

interface WafResult {
  url: string;
  status: "pass" | "warn";
  detected: string[];
  signals: Array<{ header: string; value: string }>;
  checks: Array<{ name: string; status: "pass" | "warn" | "risk"; detail: string }>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="WAF 检测"
      description="防火墙识别"
      icon={Fingerprint}
      tips={[
        "通过响应头特征识别 Cloudflare、阿里云盾、安全狗等常见 WAF。",
        "未识别到特征不代表无防护，可能使用了自研防护。",
        "检测为被动指纹识别，不发送攻击性请求。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      demo={false}
      onRun={async (values) => {
        const res = await fetch("/api/waf", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ target: values.url.trim() }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "检测失败");
        return data as WafResult;
      }}
      renderResult={(result) => {
        const data = result as WafResult;
        return (
          <ChecksResult checks={data.checks}>
            <div className="flex flex-wrap items-center gap-2">
              {data.detected.length > 0 ? (
                data.detected.map((w) => (
                  <Badge key={w} variant="secondary" className="bg-foreground text-background hover:bg-foreground/90 border-0">
                    {w}
                  </Badge>
                ))
              ) : (
                <Badge variant="outline" className="bg-amber-100 text-amber-700 border-amber-200">
                  未检测到常见 WAF 特征
                </Badge>
              )}
            </div>
            <div className="flex flex-wrap gap-2">
              {data.signals.map((s) => (
                <span
                  key={s.header}
                  className="inline-flex items-center gap-1.5 text-xs font-mono px-2.5 py-1 rounded-md bg-secondary/50 text-muted-foreground"
                >
                  {s.header}: <span className="text-foreground">{s.value}</span>
                </span>
              ))}
            </div>
          </ChecksResult>
        );
      }}
    />
  );
}
