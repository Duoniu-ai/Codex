import { NextRequest, NextResponse } from "next/server";
import {
  extractMeta,
  fetchPage,
  normalizeUrl,
  type CheckStatus,
} from "@/lib/site-analysis";
import { checkAndDeductCredits } from "@/lib/auth";

interface TdkRequest {
  target: string;
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: TdkRequest = await req.json();
    const { target } = body;
    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入目标 URL" },
        { status: 400 }
      );
    }

    const url = normalizeUrl(target);
    const page = await fetchPage(url, { bodyLimit: 1_000_000, timeoutMs: 20000 });
    const meta = extractMeta(page.html, page.finalUrl);

    const titleLen = meta.title.length;
    const descLen = meta.description.length;
    const checks: Array<{ name: string; status: CheckStatus; detail: string }> = [
      {
        name: "Title 标题",
        status: titleLen > 0 ? "pass" : "risk",
        detail: titleLen > 0 ? `已设置（${titleLen} 字）` : "未设置 <title>",
      },
      {
        name: "Title 长度",
        status: titleLen >= 10 && titleLen <= 60 ? "pass" : "warn",
        detail: `${titleLen} 字，建议 10-60 字`,
      },
      {
        name: "Meta Description",
        status: descLen > 0 ? "pass" : "risk",
        detail: descLen > 0 ? `已设置（${descLen} 字）` : "未设置 meta description",
      },
      {
        name: "Description 长度",
        status: descLen >= 50 && descLen <= 160 ? "pass" : "warn",
        detail: `${descLen} 字，建议 50-160 字`,
      },
      {
        name: "Meta Keywords",
        status: meta.keywords ? "pass" : "warn",
        detail: meta.keywords ? meta.keywords.slice(0, 80) : "未设置关键词（已非强制）",
      },
    ];

    return NextResponse.json({
      url,
      title: meta.title || "--",
      description: meta.description || "--",
      keywords: meta.keywords || "--",
      titleLength: titleLen,
      descriptionLength: descLen,
      checks,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "检测失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
