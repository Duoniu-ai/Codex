import { NextRequest, NextResponse } from "next/server";
import {
  extractMeta,
  fetchPage,
  normalizeUrl,
} from "@/lib/site-analysis";
import { checkAndDeductCredits } from "@/lib/auth";

interface KeywordDensityRequest {
  target: string;
  keyword: string;
}

function stripHtml(input: string): string {
  return input
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&[a-zA-Z#0-9]+;/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: KeywordDensityRequest = await req.json();
    const { target, keyword } = body;
    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入目标 URL" },
        { status: 400 }
      );
    }
    if (!keyword || typeof keyword !== "string") {
      return NextResponse.json(
        { error: "请输入要统计的关键词" },
        { status: 400 }
      );
    }

    const url = normalizeUrl(target);
    const page = await fetchPage(url, { bodyLimit: 1_000_000, timeoutMs: 20000 });
    const meta = extractMeta(page.html, page.finalUrl);
    const text = stripHtml(page.html);
    const cleanKeyword = keyword.trim().toLowerCase();

    const occurrences = text
      .toLowerCase()
      .split(cleanKeyword).length - 1;
    const totalWords =
      (text.match(/[\u4e00-\u9fff]/g) || []).length +
      (text.match(/[a-zA-Z0-9]+/g) || []).length;
    const density = totalWords > 0 ? (occurrences / totalWords) * 100 : 0;

    // 提取高频词（中文二元组 + 英文单词）
    const freq: Record<string, number> = {};
    const englishWords = text.match(/[a-zA-Z]{2,}/g) || [];
    for (const w of englishWords) {
      const key = w.toLowerCase();
      freq[key] = (freq[key] || 0) + 1;
    }
    const cjkChars = text.match(/[\u4e00-\u9fff]/g) || [];
    for (let i = 0; i < cjkChars.length - 1; i++) {
      const key = cjkChars[i] + cjkChars[i + 1];
      freq[key] = (freq[key] || 0) + 1;
    }
    const topWords = Object.entries(freq)
      .filter(([, count]) => count >= 2)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 20)
      .map(([word, count]) => ({ word, count }));

    return NextResponse.json({
      url,
      keyword: cleanKeyword,
      occurrences,
      totalWords,
      density: Number(density.toFixed(2)),
      densityStatus:
        density < 0.5 ? "low" : density <= 3 ? "good" : "high",
      topWords,
      title: meta.title,
      description: meta.description,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "检测失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
