import { NextRequest, NextResponse } from "next/server";
import { scanPorts, sanitizeHost, isValidHostnameOrIp } from "@/lib/net-tools";
import { checkAndDeductCredits } from "@/lib/auth";

interface PortscanRequest {
  target: string;
  ports?: string;
  family?: 4 | 6;
}

const MAX_PORTS = 30;

function parsePorts(input: string): number[] {
  const ports = input
    .split(/[,，\s]+/)
    .map((p) => parseInt(p.trim(), 10))
    .filter((p) => !isNaN(p) && p >= 1 && p <= 65535);
  return Array.from(new Set(ports)).slice(0, MAX_PORTS);
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: PortscanRequest = await req.json();
    const { target, ports = "80,443,22,21,25,3306,3389", family = 4 } = body;

    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入目标主机" },
        { status: 400 }
      );
    }

    const host = sanitizeHost(target);
    if (!isValidHostnameOrIp(host)) {
      return NextResponse.json(
        { error: "请输入有效的主机地址" },
        { status: 400 }
      );
    }

    const portList = parsePorts(ports);
    if (portList.length === 0) {
      return NextResponse.json(
        { error: "请至少输入一个有效端口（1-65535）" },
        { status: 400 }
      );
    }

    const result = await scanPorts(host, portList, {
      family,
      concurrency: 12,
      timeoutMs: 1500,
    });
    return NextResponse.json(result);
  } catch (err) {
    const message = err instanceof Error ? err.message : "扫描失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
