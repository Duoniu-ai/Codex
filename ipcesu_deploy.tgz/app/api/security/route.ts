import { NextRequest, NextResponse } from "next/server";
import tls from "tls";
import {
  fetchPage,
  normalizeUrl,
  type CheckStatus,
} from "@/lib/site-analysis";
import { checkAndDeductCredits } from "@/lib/auth";

interface SecurityRequest {
  target: string;
}

function checkSecurityHeaders(h: Record<string, string>): Array<{
  name: string;
  status: CheckStatus;
  detail: string;
}> {
  return [
    {
      name: "HTTPS",
      status: h["x-final-url"]?.startsWith("https://") ? "pass" : "risk",
      detail: h["x-final-url"]?.startsWith("https://")
        ? "站点使用 HTTPS 加密"
        : "站点未使用 HTTPS",
    },
    {
      name: "HSTS",
      status: h["strict-transport-security"] ? "pass" : "warn",
      detail: h["strict-transport-security"]
        ? "已启用 HSTS"
        : "未启用 HSTS（Strict-Transport-Security）",
    },
    {
      name: "X-Frame-Options",
      status: h["x-frame-options"] ? "pass" : "warn",
      detail: h["x-frame-options"]
        ? `已设置: ${h["x-frame-options"]}`
        : "未设置，存在点击劫持风险",
    },
    {
      name: "X-Content-Type-Options",
      status: h["x-content-type-options"] === "nosniff" ? "pass" : "warn",
      detail: h["x-content-type-options"]
        ? `已设置: ${h["x-content-type-options"]}`
        : "未设置 nosniff",
    },
    {
      name: "Content-Security-Policy",
      status: h["content-security-policy"] ? "pass" : "warn",
      detail: h["content-security-policy"]
        ? "已配置 CSP"
        : "未配置 CSP，XSS 风险较高",
    },
    {
      name: "Referrer-Policy",
      status: h["referrer-policy"] ? "pass" : "warn",
      detail: h["referrer-policy"]
        ? `已设置: ${h["referrer-policy"]}`
        : "未设置 Referrer-Policy",
    },
    {
      name: "Permissions-Policy",
      status: h["permissions-policy"] ? "pass" : "warn",
      detail: h["permissions-policy"]
        ? "已设置 Permissions-Policy"
        : "未设置 Permissions-Policy",
    },
  ];
}

function getTlsInfo(host: string): Promise<{
  tlsVersion: string;
  cipher: string;
  validTo: string;
  daysRemaining: number;
}> {
  return new Promise((resolve) => {
    const socket = tls.connect(443, host, { servername: host }, () => {
      const cert = socket.getPeerCertificate();
      const validTo = new Date(cert.valid_to);
      const daysRemaining = Math.ceil(
        (validTo.getTime() - Date.now()) / (1000 * 60 * 60 * 24)
      );
      resolve({
        tlsVersion: socket.getProtocol() || "unknown",
        cipher: (socket.getCipher?.().name as string) || "unknown",
        validTo: cert.valid_to || "",
        daysRemaining,
      });
      socket.end();
    });
    socket.on("error", () =>
      resolve({ tlsVersion: "--", cipher: "--", validTo: "--", daysRemaining: 0 })
    );
    socket.setTimeout(8000, () => {
      socket.destroy();
      resolve({ tlsVersion: "--", cipher: "--", validTo: "--", daysRemaining: 0 });
    });
  });
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: SecurityRequest = await req.json();
    const { target } = body;
    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入目标 URL" },
        { status: 400 }
      );
    }

    const url = normalizeUrl(target);
    const page = await fetchPage(url, { bodyLimit: 500_000, timeoutMs: 20000 });
    const host = new URL(page.finalUrl).hostname;

    const headers: Record<string, string> = {
      ...page.headers,
      "x-final-url": page.finalUrl,
    };
    const headerChecks = checkSecurityHeaders(headers);
    const tlsInfo = await getTlsInfo(host);

    const setCookie = String(headers["set-cookie"] || "");
    const checks = [
      ...headerChecks,
      {
        name: "Cookie Secure 标记",
        status: setCookie.includes("Secure") ? "pass" : "warn",
        detail: setCookie.includes("Secure")
          ? "Cookie 已标记 Secure"
          : "未检测到带 Secure 标记的 Cookie",
      },
      {
        name: "TLS 协议",
        status:
          tlsInfo.tlsVersion === "TLSv1.3" || tlsInfo.tlsVersion === "TLSv1.2"
            ? "pass"
            : "warn",
        detail: `当前握手协议 ${tlsInfo.tlsVersion}，加密套件 ${tlsInfo.cipher}`,
      },
      {
        name: "证书有效期",
        status: tlsInfo.daysRemaining > 30 ? "pass" : "warn",
        detail: `证书剩余 ${tlsInfo.daysRemaining} 天（至 ${tlsInfo.validTo}）`,
      },
    ];

    const passCount = checks.filter((c) => c.status === "pass").length;
    return NextResponse.json({
      url,
      finalUrl: page.finalUrl,
      score: Math.round((passCount / checks.length) * 100),
      server: String(page.headers["server"] || "--"),
      tls: tlsInfo,
      checks,
      passCount,
      total: checks.length,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "检测失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
