import { NextRequest, NextResponse } from "next/server";
import {
  resolveAddresses,
  runPing,
  sanitizeHost,
  serverHasIpv6,
} from "@/lib/net-tools";
import { checkAndDeductCredits } from "@/lib/auth";

interface PingRequest {
  target: string;
  node?: string;
  family?: 4 | 6;
  count?: number;
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: PingRequest = await req.json();
    const { target, node = "默认节点", family = 4, count = 4 } = body;

    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入有效的域名或 IP" },
        { status: 400 }
      );
    }

    const host = sanitizeHost(target);

    if (family === 6) {
      const ipv6Addresses = await resolveAddresses(host, 6);
      if (ipv6Addresses.length === 0) {
        return NextResponse.json(
          { error: "目标域名没有 IPv6 (AAAA) 记录" },
          { status: 400 }
        );
      }
      const ipv6Available = await serverHasIpv6();
      if (!ipv6Available) {
        return NextResponse.json({
          target: host,
          resolvedIps: ipv6Addresses,
          status: "ipv6-unavailable",
          message:
            "当前检测节点未启用 IPv6 网络，无法执行真实 IPv6 Ping。已为您解析目标的 AAAA 记录，如需完整检测请为服务器开通 IPv6。",
        });
      }
    }

    const result = await runPing(host, {
      family,
      count: Math.min(Math.max(count, 1), 10),
      node,
    });
    return NextResponse.json(result);
  } catch (err) {
    const message = err instanceof Error ? err.message : "测试失败，请稍后重试";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
