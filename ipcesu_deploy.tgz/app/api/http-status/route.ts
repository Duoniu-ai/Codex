import { NextRequest, NextResponse } from "next/server";
import {
  fetchPage,
  normalizeUrl,
  runWithConcurrency,
} from "@/lib/site-analysis";
import { checkAndDeductCredits } from "@/lib/auth";

interface HttpStatusRequest {
  targets: string[];
}

const MAX_TARGETS = 20;

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: HttpStatusRequest = await req.json();
    const { targets } = body;

    if (!Array.isArray(targets) || targets.length === 0) {
      return NextResponse.json(
        { error: "请至少输入一个 URL" },
        { status: 400 }
      );
    }

    const list = targets
      .map((t) => (typeof t === "string" ? t.trim() : ""))
      .filter(Boolean)
      .slice(0, MAX_TARGETS);

    const results: Array<{
      url: string;
      finalUrl: string;
      code: number;
      time: number;
      redirects: number;
      error?: string;
    }> = [];

    await runWithConcurrency(list, 5, async (raw) => {
      const url = normalizeUrl(raw);
      try {
        const page = await fetchPage(url, {
          bodyLimit: 200_000,
          timeoutMs: 12000,
        });
        results.push({
          url,
          finalUrl: page.finalUrl,
          code: page.statusCode,
          time: Math.round(page.totalTime),
          redirects: page.redirectCount,
        });
      } catch {
        results.push({
          url,
          finalUrl: url,
          code: 0,
          time: 0,
          redirects: 0,
          error: "请求失败",
        });
      }
    });

    results.sort((a, b) => a.code - b.code);
    return NextResponse.json({
      total: results.length,
      ok: results.filter((r) => r.code >= 200 && r.code < 300).length,
      redirect: results.filter((r) => r.code >= 300 && r.code < 400).length,
      error: results.filter((r) => r.code >= 400 || r.code === 0).length,
      results,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "检测失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
