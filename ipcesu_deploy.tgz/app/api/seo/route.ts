import { NextRequest, NextResponse } from "next/server";
import {
  analyzeSeo,
  extractMeta,
  fetchPage,
  normalizeUrl,
} from "@/lib/site-analysis";
import { checkAndDeductCredits } from "@/lib/auth";

interface SeoRequest {
  target: string;
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: SeoRequest = await req.json();
    const { target } = body;
    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入目标 URL" },
        { status: 400 }
      );
    }

    const url = normalizeUrl(target);
    const page = await fetchPage(url, { bodyLimit: 2_000_000, timeoutMs: 20000 });
    const meta = extractMeta(page.html, page.finalUrl);
    const result = analyzeSeo(meta, page, page.finalUrl);

    return NextResponse.json({
      url,
      finalUrl: page.finalUrl,
      statusCode: page.statusCode,
      score: result.score,
      checks: result.checks,
      meta: {
        title: meta.title,
        description: meta.description,
        h1Count: meta.h1Count,
        canonical: meta.canonical,
        robots: meta.robots,
        wordCount: meta.wordCount,
      },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "检测失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
