import { NextRequest, NextResponse } from "next/server";
import {
  analyzePerformance,
  analyzeSeo,
  extractMeta,
  fetchPage,
  normalizeUrl,
} from "@/lib/site-analysis";
import { checkAndDeductCredits } from "@/lib/auth";

interface OptimizationRequest {
  target: string;
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: OptimizationRequest = await req.json();
    const { target } = body;

    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入目标 URL" },
        { status: 400 }
      );
    }

    const url = normalizeUrl(target);
    const page = await fetchPage(url, { bodyLimit: 2_000_000, timeoutMs: 20000 });
    const meta = extractMeta(page.html, page.finalUrl);
    const seo = analyzeSeo(meta, page, page.finalUrl);
    const perf = analyzePerformance(page, meta);

    const suggestions = [...seo.checks];

    suggestions.push({
      name: "启用 Gzip/Brotli 压缩",
      status: perf.compressed ? "pass" : "warn",
      detail: perf.compressed
        ? `已启用 ${perf.compression} 压缩`
        : "响应未压缩，建议开启 Gzip/Brotli 以减小传输体积",
    });
    suggestions.push({
      name: "配置浏览器缓存",
      status: perf.cacheControl ? "pass" : "warn",
      detail: perf.cacheControl
        ? `已设置 Cache-Control: ${perf.cacheControl}`
        : "未设置 Cache-Control，建议为静态资源配置长缓存",
    });
    suggestions.push({
      name: "减小首屏体积",
      status: perf.sizeKb <= 500 ? "pass" : "warn",
      detail: `HTML 文档 ${perf.sizeKb} KB${
        perf.sizeKb > 500 ? "，偏大，建议精简" : "，处于合理范围"
      }`,
    });
    suggestions.push({
      name: "减少阻塞渲染脚本",
      status: meta.scriptCount <= 10 ? "pass" : "warn",
      detail: `页面包含 ${meta.scriptCount} 个 <script> 标签${
        meta.scriptCount > 10 ? "，建议合并或延迟加载" : ""
      }`,
    });
    suggestions.push({
      name: "优化图片资源",
      status:
        meta.imagesWithoutAlt === 0 && meta.imagesTotal <= 20 ? "pass" : "warn",
      detail:
        meta.imagesWithoutAlt === 0 && meta.imagesTotal <= 20
          ? "图片数量与 alt 属性正常"
          : `${meta.imagesTotal} 张图片，${meta.imagesWithoutAlt} 张缺少 alt，建议压缩并补充 alt`,
    });

    const riskCount = suggestions.filter((s) => s.status === "risk").length;
    const warnCount = suggestions.filter((s) => s.status === "warn").length;
    const score = Math.max(
      10,
      Math.min(
        99,
        Math.round(
          seo.score * 0.6 -
            riskCount * 8 -
            warnCount * 3 +
            (perf.compressed ? 5 : 0)
        )
      )
    );

    return NextResponse.json({
      url,
      finalUrl: page.finalUrl,
      statusCode: page.statusCode,
      score,
      suggestions,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "分析失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
