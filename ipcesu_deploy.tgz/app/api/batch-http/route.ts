import { NextRequest, NextResponse } from "next/server";
import {
  fetchPage,
  normalizeUrl,
  runWithConcurrency,
} from "@/lib/site-analysis";
import { checkAndDeductCredits } from "@/lib/auth";

interface BatchHttpRequest {
  targets: string[];
}

const MAX_TARGETS = 20;

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: BatchHttpRequest = await req.json();
    const { targets } = body;

    if (!Array.isArray(targets) || targets.length === 0) {
      return NextResponse.json(
        { error: "请至少输入一个 URL" },
        { status: 400 }
      );
    }

    const list = targets
      .map((t) => (typeof t === "string" ? t.trim() : ""))
      .filter(Boolean)
      .slice(0, MAX_TARGETS);

    const items: Array<{
      url: string;
      statusCode: number;
      statusText: string;
      totalTime: number;
      server: string;
      finalUrl: string;
      size: number;
      redirects: number;
      error?: string;
    }> = [];

    await runWithConcurrency(list, 5, async (raw) => {
      const url = normalizeUrl(raw);
      try {
        const page = await fetchPage(url, {
          bodyLimit: 300_000,
          timeoutMs: 12000,
        });
        items.push({
          url,
          statusCode: page.statusCode,
          statusText: page.statusText || "",
          totalTime: Math.round(page.totalTime),
          server: String(page.headers["server"] || page.headers["x-powered-by"] || "--"),
          finalUrl: page.finalUrl,
          size: page.size,
          redirects: page.redirectCount,
        });
      } catch {
        items.push({
          url,
          statusCode: 0,
          statusText: "请求失败",
          totalTime: 0,
          server: "--",
          finalUrl: url,
          size: 0,
          redirects: 0,
          error: "请求失败",
        });
      }
    });

    items.sort((a, b) => a.statusCode - b.statusCode);
    return NextResponse.json({
      total: items.length,
      available: items.filter((i) => i.statusCode >= 200 && i.statusCode < 400).length,
      failed: items.filter((i) => i.statusCode >= 400 || i.statusCode === 0).length,
      items,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "检测失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
