import { NextRequest, NextResponse } from "next/server";
import {
  analyzePerformance,
  extractMeta,
  fetchPage,
  normalizeUrl,
} from "@/lib/site-analysis";
import { checkAndDeductCredits } from "@/lib/auth";

interface CoreWebVitalsRequest {
  target: string;
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: CoreWebVitalsRequest = await req.json();
    const { target } = body;

    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入目标 URL" },
        { status: 400 }
      );
    }

    const url = normalizeUrl(target);
    const page = await fetchPage(url, { bodyLimit: 2_000_000, timeoutMs: 20000 });
    const meta = extractMeta(page.html, page.finalUrl);
    const perf = analyzePerformance(page, meta);

    const lcpStatus: "pass" | "warn" | "risk" =
      perf.lcpEstimate <= 2500 ? "pass" : perf.lcpEstimate <= 4000 ? "warn" : "risk";
    const inpStatus: "pass" | "warn" | "risk" =
      perf.inpEstimate <= 200 ? "pass" : perf.inpEstimate <= 500 ? "warn" : "risk";
    const clsStatus: "pass" | "warn" | "risk" =
      perf.clsEstimate <= 0.1 ? "pass" : perf.clsEstimate <= 0.25 ? "warn" : "risk";

    return NextResponse.json({
      url,
      finalUrl: page.finalUrl,
      statusCode: page.statusCode,
      estimate: true,
      lcp: perf.lcpEstimate / 1000,
      inp: perf.inpEstimate,
      cls: perf.clsEstimate,
      lcpStatus,
      inpStatus,
      clsStatus,
      ttfb: perf.ttfb,
      totalTime: perf.totalTime,
      sizeKb: perf.sizeKb,
      compressed: perf.compressed,
      compression: perf.compression,
      cacheControl: perf.cacheControl,
      redirectCount: page.redirectCount,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "检测失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
