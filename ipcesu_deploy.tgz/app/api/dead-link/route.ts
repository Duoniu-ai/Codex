import { NextRequest, NextResponse } from "next/server";
import {
  extractMeta,
  fetchPage,
  normalizeUrl,
  runWithConcurrency,
} from "@/lib/site-analysis";
import { checkAndDeductCredits } from "@/lib/auth";

interface DeadLinkRequest {
  target: string;
}

const MAX_LINKS = 30;

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: DeadLinkRequest = await req.json();
    const { target } = body;

    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入目标 URL" },
        { status: 400 }
      );
    }

    const url = normalizeUrl(target);
    const page = await fetchPage(url, { bodyLimit: 2_000_000, timeoutMs: 20000 });
    if (page.statusCode >= 400) {
      return NextResponse.json(
        { error: `目标页面返回 HTTP ${page.statusCode}，无法抓取链接` },
        { status: 400 }
      );
    }

    const meta = extractMeta(page.html, page.finalUrl);
    const targetHost = new URL(page.finalUrl).hostname;
    const uniqueLinks = Array.from(
      new Set(
        meta.links.filter((link) => {
          try {
            return new URL(link).hostname === targetHost;
          } catch {
            return false;
          }
        })
      )
    ).slice(0, MAX_LINKS);

    const checked: Array<{
      url: string;
      code: number;
      time: number;
      status: "ok" | "redirect" | "dead";
    }> = [];

    await runWithConcurrency(uniqueLinks, 5, async (link) => {
      try {
        const result = await fetchPage(link, {
          bodyLimit: 50_000,
          timeoutMs: 10000,
          maxRedirects: 2,
        });
        const status =
          result.statusCode >= 400
            ? "dead"
            : result.statusCode >= 300
            ? "redirect"
            : "ok";
        checked.push({
          url: link,
          code: result.statusCode,
          time: Math.round(result.totalTime),
          status,
        });
      } catch {
        checked.push({
          url: link,
          code: 0,
          time: 0,
          status: "dead",
        });
      }
    });

    const deadLinks = checked.filter((c) => c.status === "dead");
    return NextResponse.json({
      target: url,
      total: checked.length,
      ok: checked.filter((c) => c.status === "ok").length,
      redirect: checked.filter((c) => c.status === "redirect").length,
      dead: deadLinks.length,
      deadLinks: deadLinks.map(({ url: u, code }) => ({ url: u, code })),
      checked,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "检测失败";
    return NextResponse.json({ error: `死链检测失败：${message}` }, { status: 500 });
  }
}
