import { NextRequest, NextResponse } from "next/server";
import { execFile } from "child_process";
import { promisify } from "util";
import {
  fetchPage,
  normalizeUrl,
  type CheckStatus,
} from "@/lib/site-analysis";
import { checkAndDeductCredits } from "@/lib/auth";

const execFileAsync = promisify(execFile);

interface CdnRequest {
  target: string;
}

const CDN_HEADERS: Array<{ name: string; test: (h: Record<string, string>) => boolean }> = [
  { name: "Cloudflare", test: (h) => Boolean(h["cf-ray"] || h["cf-cache-status"] || h["cf-connecting-ip"]) },
  { name: "阿里云 CDN", test: (h) => /aliyun|acs-cdn/i.test(String(h["server"] || "") + String(h["via"] || "")) },
  { name: "腾讯云 CDN", test: (h) => /tencent|tcdn|tengine/i.test(String(h["server"] || "") + String(h["via"] || "")) },
  { name: "网宿 CDN", test: (h) => /china cache|wsng|cdn\-/i.test(String(h["server"] || "") + String(h["x-cache"] || "")) },
  { name: "百度云加速", test: (h) => /yunjiasu/i.test(String(h["server"] || "")) },
  { name: "Akamai", test: (h) => /akamai/i.test(String(h["server"] || "") + String(h["x-akamai"] || "")) },
  { name: "Fastly", test: (h) => /fastly/i.test(String(h["server"] || "") + String(h["x-fastly"] || "")) },
  { name: "AWS CloudFront", test: (h) => /cloudfront|amazon/i.test(String(h["server"] || "") + String(h["x-amz-cf-id"] || "")) },
];

async function getCnameChain(domain: string): Promise<string[]> {
  const chain: string[] = [];
  let current = domain;
  try {
    const { stdout } = await execFileAsync("dig", ["+short", "CNAME", current], {
      timeout: 8000,
    });
    const target = stdout.trim().replace(/\.$/, "");
    if (target && !target.includes(";")) {
      chain.push(target);
      const next = await getCnameChain(target);
      chain.push(...next);
    }
  } catch {
    // ignore
  }
  return chain;
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: CdnRequest = await req.json();
    const { target } = body;
    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入目标 URL" },
        { status: 400 }
      );
    }

    const url = normalizeUrl(target);
    const page = await fetchPage(url, { bodyLimit: 200_000, timeoutMs: 15000 });
    const h = page.headers;
    const host = new URL(page.finalUrl).hostname;

    const headerMatches = CDN_HEADERS.filter((sig) => sig.test(h)).map((s) => s.name);
    const cnameChain = await getCnameChain(host);
    const cnameMatches = CDN_HEADERS.filter((sig) =>
      cnameChain.some((c) => sig.test({ ...h, "x-cdn-cname": c }))
    ).map((s) => s.name);

    const detected = Array.from(new Set([...headerMatches, ...cnameMatches]));
    const status: CheckStatus = detected.length > 0 ? "pass" : "warn";
    return NextResponse.json({
      url,
      host,
      status,
      detected,
      cnameChain,
      headers: Object.entries(h)
        .filter(([key]) =>
          /^(server|via|age|cf-ray|cf-cache-status|x-cache|x-cdn|x-served-by|x-amz-cf-id|vary)$/i.test(
            key
          )
        )
        .map(([key, value]) => ({ header: key, value: String(value).slice(0, 120) })),
      checks: [
        {
          name: "CDN 识别",
          status,
          detail:
            detected.length > 0
              ? `识别到 ${detected.join("、")}`
              : "未识别到常见 CDN 特征，可能为源站直连",
        },
        {
          name: "CNAME 解析",
          status: cnameChain.length > 0 ? "pass" : "warn",
          detail:
            cnameChain.length > 0
              ? cnameChain.join(" → ")
              : "未检测到 CNAME 记录（可能使用 A 记录直连）",
        },
      ],
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "检测失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
