import { NextRequest, NextResponse } from "next/server";
import {
  extractMeta,
  fetchPage,
  normalizeUrl,
  type CheckStatus,
} from "@/lib/site-analysis";
import { checkAndDeductCredits } from "@/lib/auth";

interface RobotsRequest {
  target: string;
}

function parseRobots(content: string): Array<{
  userAgent: string;
  rules: { type: string; value: string }[];
}> {
  const groups: Array<{
    userAgent: string;
    rules: { type: string; value: string }[];
  }> = [];
  let current: (typeof groups)[number] | null = null;

  for (const rawLine of content.split("\n")) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) continue;
    const idx = line.indexOf(":");
    if (idx === -1) continue;
    const key = line.slice(0, idx).trim().toLowerCase();
    const value = line.slice(idx + 1).trim();

    if (key === "user-agent") {
      current = { userAgent: value, rules: [] };
      groups.push(current);
    } else if (current && (key === "disallow" || key === "allow" || key === "sitemap")) {
      current.rules.push({ type: key, value });
    }
  }
  return groups;
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: RobotsRequest = await req.json();
    const { target } = body;
    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入目标 URL" },
        { status: 400 }
      );
    }

    const url = normalizeUrl(target);
    const parsed = new URL(url);
    const robotsUrl = `${parsed.protocol}//${parsed.host}/robots.txt`;

    let robotsContent = "";
    let robotsStatus = 0;
    try {
      const res = await fetch(robotsUrl, {
        redirect: "follow",
        signal: AbortSignal.timeout(10000),
        headers: {
          "User-Agent":
            "Mozilla/5.0 (compatible; IPcesuBot/1.0; +https://test.ipcesu.com)",
        },
      });
      robotsStatus = res.status;
      robotsContent = (await res.text()).slice(0, 20000);
    } catch {
      robotsStatus = 0;
    }

    const rules = parseRobots(robotsContent);
    const path = parsed.pathname || "/";
    const targetRules =
      rules.find(
        (g) => g.userAgent === "*" || g.userAgent.toLowerCase() === "googlebot"
      ) || null;

    let allowed = true;
    let matchedRule = "";
    if (targetRules) {
      for (const rule of targetRules.rules) {
        if (rule.type === "disallow" && rule.value !== "" && path.startsWith(rule.value)) {
          allowed = false;
          matchedRule = `Disallow: ${rule.value}`;
          break;
        }
      }
    }

    const page = await fetchPage(url, { bodyLimit: 500_000, timeoutMs: 15000 });
    const meta = extractMeta(page.html, page.finalUrl);

    const checks: Array<{ name: string; status: CheckStatus; detail: string }> = [
      {
        name: "robots.txt 存在",
        status: robotsStatus >= 200 && robotsStatus < 400 ? "pass" : "warn",
        detail:
          robotsStatus >= 200 && robotsStatus < 400
            ? `robots.txt 返回 HTTP ${robotsStatus}`
            : "未找到 robots.txt 或请求失败",
      },
      {
        name: "抓取权限",
        status: allowed ? "pass" : "risk",
        detail: allowed
          ? "搜索引擎蜘蛛可以抓取该路径"
          : `该路径被 ${matchedRule} 规则屏蔽`,
      },
      {
        name: "meta robots",
        status: meta.robots ? "warn" : "pass",
        detail: meta.robots
          ? `页面声明 meta robots: ${meta.robots}`
          : "页面未设置 meta robots 标签",
      },
      {
        name: "Sitemap 声明",
        status: robotsContent.includes("Sitemap:") ? "pass" : "warn",
        detail: robotsContent.includes("Sitemap:")
          ? "robots.txt 中声明了 Sitemap"
          : "未在 robots.txt 中声明 Sitemap",
      },
    ];

    return NextResponse.json({
      url,
      robotsUrl,
      robotsStatus,
      robotsContent: robotsContent.slice(0, 4000),
      groups: rules.slice(0, 10),
      targetPath: path,
      allowed,
      matchedRule,
      checks,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "检测失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
