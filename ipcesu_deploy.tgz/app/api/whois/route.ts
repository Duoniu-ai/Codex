import { NextRequest, NextResponse } from "next/server";
import { checkAndDeductCredits } from "@/lib/auth";

interface WhoisRequest {
  domain: string;
}

function normalizeDomain(input: string): string {
  return input
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//i, "")
    .replace(/\/.*$/, "")
    .replace(/:\d+$/, "")
    .replace(/^www\./, "");
}

function isValidDomain(domain: string): boolean {
  if (domain.length > 253 || !domain.includes(".")) return false;
  return /^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/.test(
    domain
  );
}

function getEntityName(entity: {
  roles?: string | string[];
  vcardArray?: unknown[];
  fn?: string;
}): string | null {
  const vcard = entity.vcardArray?.[1];
  if (Array.isArray(vcard)) {
    for (const field of vcard as unknown[][]) {
      if (Array.isArray(field) && field[0] === "fn") {
        const value = field[3];
        if (typeof value === "string") return value;
      }
    }
  }
  return entity.fn || null;
}

function hasRole(
  entity: { roles?: string | string[] },
  role: string
): boolean {
  const roles = Array.isArray(entity.roles) ? entity.roles : [entity.roles];
  return roles.includes(role);
}

async function queryRdap(domain: string): Promise<Record<string, unknown>> {
  const res = await fetch(
    `https://rdap.org/domain/${encodeURIComponent(domain)}`,
    {
      redirect: "follow",
      signal: AbortSignal.timeout(15000),
      headers: { Accept: "application/rdap+json, application/json" },
    }
  );
  if (!res.ok) {
    throw new Error(`RDAP 查询失败 (HTTP ${res.status})`);
  }
  return res.json();
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: WhoisRequest = await req.json();
    const { domain } = body;

    if (!domain || typeof domain !== "string") {
      return NextResponse.json(
        { error: "请输入有效的域名" },
        { status: 400 }
      );
    }

    const trimmedDomain = normalizeDomain(domain);
    if (!isValidDomain(trimmedDomain)) {
      return NextResponse.json(
        { error: "请输入有效的域名（例如 example.com）" },
        { status: 400 }
      );
    }

    const data = await queryRdap(trimmedDomain);
    const entities = Array.isArray(data.entities) ? data.entities : [];

    const registrar =
      entities.find((e: { roles?: string | string[] }) =>
        hasRole(e, "registrar")
      ) || null;
    const registrant =
      entities.find((e: { roles?: string | string[] }) =>
        hasRole(e, "registrant")
      ) || null;

    const events = Array.isArray(data.events) ? data.events : [];
    const findEvent = (action: string) =>
      events.find(
        (e: { eventAction?: string; eventDate?: string }) =>
          e.eventAction === action
      )?.eventDate || null;

    const nameServers = Array.isArray(data.nameservers)
      ? data.nameservers
          .map((ns: { ldhName?: string }) => ns.ldhName)
          .filter(Boolean)
      : [];

    const status = Array.isArray(data.status) ? data.status : [];
    const secureDns = data.secureDNS as
      | { delegationSigned?: boolean; dsData?: unknown[] }
      | undefined;

    return NextResponse.json({
      domain: trimmedDomain,
      rdap: true,
      registrar: registrar ? getEntityName(registrar) || "--" : "--",
      registrant: registrant ? getEntityName(registrant) || "--" : "--",
      creationDate:
        findEvent("registration") || findEvent("last changed") || "--",
      expirationDate: findEvent("expiration") || "--",
      updatedDate: findEvent("last changed") || "--",
      nameServers,
      status: status.map((s) => String(s)),
      secureDns: {
        enabled: Boolean(secureDns?.delegationSigned),
        dsCount: Array.isArray(secureDns?.dsData) ? secureDns.dsData.length : 0,
      },
      raw: JSON.stringify(data, null, 2).slice(0, 3000),
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "查询失败";
    return NextResponse.json(
      {
        error: `Whois 查询失败：${message}。该后缀可能暂不支持 RDAP 查询，请稍后重试。`,
      },
      { status: 500 }
    );
  }
}
