import { NextRequest, NextResponse } from "next/server";
import {
  fetchPage,
  normalizeUrl,
  type CheckStatus,
} from "@/lib/site-analysis";
import { checkAndDeductCredits } from "@/lib/auth";

interface CorsRequest {
  target: string;
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: CorsRequest = await req.json();
    const { target } = body;
    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入目标 URL" },
        { status: 400 }
      );
    }

    const url = normalizeUrl(target);
    const parsed = new URL(url);
    const origins = [
      "https://evil.example.com",
      "https://attacker.com",
      "null",
    ];

    const results: Array<{
      origin: string;
      allowOrigin: string | null;
      allowCredentials: string | null;
      allowMethods: string | null;
      reflected: boolean;
    }> = [];

    for (const origin of origins) {
      try {
        const res = await fetch(url, {
          method: "GET",
          redirect: "follow",
          signal: AbortSignal.timeout(10000),
          headers: {
            Origin: origin,
            "User-Agent": "Mozilla/5.0 (compatible; IPcesuBot/1.0)",
          },
        });
        const allowOrigin = res.headers.get("access-control-allow-origin");
        results.push({
          origin,
          allowOrigin,
          allowCredentials: res.headers.get("access-control-allow-credentials"),
          allowMethods: res.headers.get("access-control-allow-methods"),
          reflected: allowOrigin === origin || allowOrigin === "*",
        });
      } catch {
        results.push({
          origin,
          allowOrigin: null,
          allowCredentials: null,
          allowMethods: null,
          reflected: false,
        });
      }
    }

    const vulnerable = results.filter((r) => r.reflected && r.origin !== "null").length;
    const status: CheckStatus =
      vulnerable > 0 ? "risk" : results.some((r) => r.allowOrigin === "*") ? "warn" : "pass";

    return NextResponse.json({
      url,
      status,
      vulnerable,
      results,
      checks: [
        {
          name: "任意来源反射",
          status: vulnerable > 0 ? "risk" : "pass",
          detail:
            vulnerable > 0
              ? "检测到响应反射了不可信 Origin，存在跨域信息泄露风险"
              : "未反射不可信来源的 Origin",
        },
        {
          name: "通配符配置",
          status: results.some((r) => r.allowOrigin === "*") ? "warn" : "pass",
          detail: results.some((r) => r.allowOrigin === "*")
            ? "使用了 Access-Control-Allow-Origin: *，建议限制为可信域名"
            : "未使用通配符配置",
        },
      ] as Array<{ name: string; status: CheckStatus; detail: string }>,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "检测失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
