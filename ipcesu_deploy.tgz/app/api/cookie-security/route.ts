import { NextRequest, NextResponse } from "next/server";
import {
  fetchPage,
  normalizeUrl,
  type CheckStatus,
} from "@/lib/site-analysis";
import { checkAndDeductCredits } from "@/lib/auth";

interface CookieSecurityRequest {
  target: string;
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: CookieSecurityRequest = await req.json();
    const { target } = body;
    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入目标 URL" },
        { status: 400 }
      );
    }

    const url = normalizeUrl(target);
    const page = await fetchPage(url, { bodyLimit: 200_000, timeoutMs: 15000 });
    const rawCookies = String(page.headers["set-cookie"] || "");

    const cookies: Array<{
      name: string;
      secure: boolean;
      httpOnly: boolean;
      sameSite: string | null;
      expires: string | null;
      checks: Array<{ name: string; status: CheckStatus; detail: string }>;
    }> = [];

    for (const raw of rawCookies.split(",")) {
      const parts = raw.split(";").map((p) => p.trim());
      const first = parts.shift() || "";
      const eq = first.indexOf("=");
      if (eq <= 0) continue;
      const name = first.slice(0, eq).trim();
      const secure = parts.some((p) => p.toLowerCase() === "secure");
      const httpOnly = parts.some((p) => p.toLowerCase() === "httponly");
      const sameSite =
        parts
          .find((p) => p.toLowerCase().startsWith("samesite="))
          ?.split("=")[1] || null;
      const expires =
        parts
          .find((p) => p.toLowerCase().startsWith("expires="))
          ?.split("=").slice(1).join("=") || null;

      const checks: Array<{ name: string; status: CheckStatus; detail: string }> =
        [
          {
            name: "Secure",
            status: secure ? "pass" : "risk",
            detail: secure ? "仅 HTTPS 传输" : "可在 HTTP 明文传输，建议设置",
          },
          {
            name: "HttpOnly",
            status: httpOnly ? "pass" : "warn",
            detail: httpOnly ? "禁止脚本读取" : "可被 JS 读取，会话类 Cookie 应设置",
          },
          {
            name: "SameSite",
            status:
              sameSite === "Strict" || sameSite === "Lax"
                ? "pass"
                : sameSite === "None"
                ? "warn"
                : "risk",
            detail: sameSite
              ? `SameSite=${sameSite}`
              : "未设置 SameSite，存在 CSRF 风险",
          },
        ];
      cookies.push({ name, secure, httpOnly, sameSite, expires, checks });
    }

    const riskCount = cookies.reduce(
      (acc, c) => acc + c.checks.filter((x) => x.status === "risk").length,
      0
    );
    return NextResponse.json({
      url,
      total: cookies.length,
      riskCount,
      cookies,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "检测失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
