import { NextRequest, NextResponse } from "next/server";
import {
  analyzeSeo,
  extractMeta,
  fetchPage,
  normalizeUrl,
} from "@/lib/site-analysis";
import { checkAndDeductCredits } from "@/lib/auth";

interface SeoDiagnosisRequest {
  target: string;
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: SeoDiagnosisRequest = await req.json();
    const { target } = body;
    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入目标 URL" },
        { status: 400 }
      );
    }

    const url = normalizeUrl(target);
    const page = await fetchPage(url, { bodyLimit: 2_000_000, timeoutMs: 20000 });
    const meta = extractMeta(page.html, page.finalUrl);
    const result = analyzeSeo(meta, page, page.finalUrl);
    const riskCount = result.checks.filter((c) => c.status === "risk").length;
    const warnCount = result.checks.filter((c) => c.status === "warn").length;

    return NextResponse.json({
      url,
      finalUrl: page.finalUrl,
      statusCode: page.statusCode,
      score: result.score,
      summary: {
        total: result.checks.length,
        pass: result.checks.filter((c) => c.status === "pass").length,
        warn: warnCount,
        risk: riskCount,
      },
      checks: result.checks,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "诊断失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
