import { NextRequest, NextResponse } from "next/server";
import {
  analyzePerformance,
  analyzeSeo,
  extractMeta,
  fetchPage,
  normalizeUrl,
  type CheckStatus,
} from "@/lib/site-analysis";
import { checkAndDeductCredits } from "@/lib/auth";

interface WebsiteAnalysisRequest {
  target: string;
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: WebsiteAnalysisRequest = await req.json();
    const { target } = body;

    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入目标 URL" },
        { status: 400 }
      );
    }

    const url = normalizeUrl(target);
    const page = await fetchPage(url, { bodyLimit: 2_000_000, timeoutMs: 20000 });
    const meta = extractMeta(page.html, page.finalUrl);
    const seo = analyzeSeo(meta, page, page.finalUrl);
    const perf = analyzePerformance(page, meta);

    const h = page.headers;
    const securityChecks: Array<{
      name: string;
      status: CheckStatus;
      detail: string;
    }> = [
      {
        name: "HTTPS 加密",
        status: page.finalUrl.startsWith("https://") ? "pass" : "risk",
        detail: page.finalUrl.startsWith("https://")
          ? "站点已启用 HTTPS"
          : "站点未使用 HTTPS",
      },
      {
        name: "HSTS",
        status: h["strict-transport-security"] ? "pass" : "warn",
        detail: h["strict-transport-security"]
          ? "已启用 HTTP 严格传输安全"
          : "未启用 HSTS 响应头",
      },
      {
        name: "X-Frame-Options",
        status: h["x-frame-options"] ? "pass" : "warn",
        detail: h["x-frame-options"]
          ? `已设置 X-Frame-Options: ${h["x-frame-options"]}`
          : "未设置 X-Frame-Options，存在点击劫持风险",
      },
      {
        name: "X-Content-Type-Options",
        status: h["x-content-type-options"] ? "pass" : "warn",
        detail: h["x-content-type-options"]
          ? "已设置 X-Content-Type-Options: nosniff"
          : "未设置 X-Content-Type-Options",
      },
      {
        name: "内容安全策略 (CSP)",
        status: h["content-security-policy"] ? "pass" : "warn",
        detail: h["content-security-policy"]
          ? "已配置 CSP"
          : "未配置 Content-Security-Policy",
      },
      {
        name: "Cookie 安全",
        status: (h["set-cookie"] || "").includes("Secure")
          ? "pass"
          : "warn",
        detail: (h["set-cookie"] || "").includes("Secure")
          ? "Cookie 已标记 Secure"
          : "未检测到带 Secure 标记的 Cookie",
      },
    ];

    const perfStatus: CheckStatus =
      perf.ttfb <= 600 && perf.sizeKb <= 500
        ? "pass"
        : perf.ttfb <= 1500
        ? "warn"
        : "risk";
    const metrics = [
      {
        label: "SEO 得分",
        value: `${seo.score}/100`,
        status: seo.score >= 80 ? "pass" : seo.score >= 60 ? "warn" : "risk",
      },
      {
        label: "性能得分",
        value: perfStatus === "pass" ? "优" : perfStatus === "warn" ? "中" : "差",
        status: perfStatus,
      },
      {
        label: "安全得分",
        value: `${
          Math.round(
            (securityChecks.filter((c) => c.status === "pass").length /
              securityChecks.length) *
              100
          )
        }/100`,
        status:
          securityChecks.filter((c) => c.status === "risk").length > 0
            ? "risk"
            : securityChecks.filter((c) => c.status === "warn").length > 0
            ? "warn"
            : "pass",
      },
      {
        label: "页面可用性",
        value: `HTTP ${page.statusCode}`,
        status: page.statusCode < 400 ? "pass" : "risk",
      },
    ];

    const checks = [
      ...seo.checks.slice(0, 8),
      ...securityChecks,
      {
        name: "TTFB（首字节）",
        status: perfStatus,
        detail: `实测 ${perf.ttfb} ms（服务器端测量）`,
      },
      {
        name: "页面体积",
        status: perf.sizeKb <= 500 ? "pass" : "warn",
        detail: `HTML 文档约 ${perf.sizeKb} KB${
          perf.compressed ? `（${perf.compression} 压缩）` : "（未压缩）"
        }`,
      },
    ];

    const overall = Math.round(
      (seo.score * 0.5 +
        (perfStatus === "pass" ? 90 : perfStatus === "warn" ? 65 : 40) * 0.3 +
        (securityChecks.filter((c) => c.status === "pass").length /
          securityChecks.length) *
          100 *
          0.2)
    );

    return NextResponse.json({
      url,
      finalUrl: page.finalUrl,
      statusCode: page.statusCode,
      score: overall,
      title: meta.title,
      description: meta.description,
      metrics,
      checks,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "分析失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
