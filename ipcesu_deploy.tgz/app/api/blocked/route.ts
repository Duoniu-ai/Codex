import { NextRequest, NextResponse } from "next/server";
import {
  fetchPage,
  normalizeUrl,
  type CheckStatus,
} from "@/lib/site-analysis";
import { resolveHost, tcpingProbe } from "@/lib/net-tools";
import { checkAndDeductCredits } from "@/lib/auth";

interface BlockedRequest {
  target: string;
}

async function checkHttpOverseas(
  host: string
): Promise<{ ok: boolean; nodes: Array<{ name: string; ok: boolean; detail: string }> }> {
  try {
    const initRes = await fetch(
      `https://check-host.net/check-http?host=${encodeURIComponent(
        host
      )}&max_nodes=3`,
      {
        redirect: "follow",
        signal: AbortSignal.timeout(10000),
        headers: { Accept: "application/json" },
      }
    );
    const init = (await initRes.json()) as { request_id?: string };
    if (!init.request_id) {
      throw new Error("no request id");
    }

    let nodes: Record<string, unknown> = {};
    for (let i = 0; i < 8; i++) {
      await new Promise((r) => setTimeout(r, 1500));
      try {
        const res = await fetch(
          `https://check-host.net/check-result/${init.request_id}`,
          {
            signal: AbortSignal.timeout(8000),
            headers: { Accept: "application/json" },
          }
        );
        const data = (await res.json()) as Record<string, unknown>;
        const hasResult = Object.values(data).some(
          (v) => Array.isArray(v) && (v as unknown[]).length > 0
        );
        if (hasResult) {
          nodes = data;
          break;
        }
      } catch {
        // continue polling
      }
    }

    const results = Object.entries(nodes).map(([name, raw]) => {
      const entries = Array.isArray(raw) ? (raw as unknown[]) : [];
      const first = entries[0];
      let ok = false;
      let detail = "无响应";
      if (Array.isArray(first)) {
        const inner = first as unknown[];
        if (inner.length === 0) {
          detail = "超时/无响应";
        } else {
          const item = inner[0] as {
            status?: string;
            error?: string;
            time?: number;
          };
          if (item?.error) {
            detail = item.error;
          } else if (item?.status === "OK" || typeof item?.time === "number") {
            ok = true;
            detail = `${(item.time || 0).toFixed(0)}ms`;
          }
        }
      } else if (first && typeof first === "object") {
        const item = first as { status?: string; error?: string; time?: number };
        if (item?.error) detail = item.error;
        else if (item?.status === "OK") {
          ok = true;
          detail = `${(item.time || 0).toFixed(0)}ms`;
        }
      }
      return { name, ok, detail };
    });

    return {
      ok: results.filter((r) => r.ok).length >= 2,
      nodes: results,
    };
  } catch {
    return { ok: false, nodes: [] };
  }
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: BlockedRequest = await req.json();
    const { target } = body;
    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入目标地址" },
        { status: 400 }
      );
    }

    const url = normalizeUrl(target);
    const parsed = new URL(url);
    const host = parsed.hostname;

    let resolvedIp = host;
    try {
      resolvedIp = await resolveHost(host, 4);
    } catch {
      return NextResponse.json(
        { error: "无法解析该域名，请检查输入" },
        { status: 400 }
      );
    }

    // 国内节点（本服务器）探测：TCP 443/80 + HTTP
    const tcp443 = await tcpingProbe(resolvedIp, 443, 4000);
    const tcp80 = await tcpingProbe(resolvedIp, 80, 4000);
    let httpOk = false;
    let httpCode = 0;
    let httpTime = 0;
    try {
      const page = await fetchPage(url, {
        bodyLimit: 100_000,
        timeoutMs: 10000,
        maxRedirects: 2,
      });
      httpOk = page.statusCode >= 200 && page.statusCode < 500;
      httpCode = page.statusCode;
      httpTime = Math.round(page.totalTime);
    } catch {
      // 国内 HTTP 失败
    }

    const localOk = tcp443.status === "open" || tcp80.status === "open" || httpOk;

    // 海外节点对比
    const overseas = await checkHttpOverseas(host);

    let verdict: "normal" | "blocked" | "unreachable" | "unknown" = "unknown";
    let status: CheckStatus = "warn";
    let conclusion = "";

    if (localOk && overseas.ok) {
      verdict = "normal";
      status = "pass";
      conclusion = "目标在国内与海外节点均可访问，未被墙。";
    } else if (!localOk && overseas.ok) {
      verdict = "blocked";
      status = "risk";
      conclusion =
        "目标在海外节点可访问，但国内节点连接失败，疑似被墙或国内链路受限。";
    } else if (!localOk && !overseas.ok && overseas.nodes.length > 0) {
      verdict = "unreachable";
      status = "risk";
      conclusion = "国内与海外节点均无法访问，目标服务器本身可能不可达或已宕机。";
    } else if (localOk && !overseas.ok) {
      verdict = "normal";
      status = "pass";
      conclusion = "国内可正常访问；海外节点检测受限，未能完整对比。";
    } else {
      verdict = "unknown";
      status = "warn";
      conclusion = "海外节点检测暂不可用，请稍后重试或多次检测。";
    }

    return NextResponse.json({
      target: host,
      resolvedIp,
      verdict,
      status,
      conclusion,
      local: {
        tcp443: tcp443.status,
        tcp80: tcp80.status,
        httpOk,
        httpCode,
        httpTime,
        ok: localOk,
      },
      overseas: {
        ok: overseas.ok,
        nodes: overseas.nodes,
      },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "检测失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
