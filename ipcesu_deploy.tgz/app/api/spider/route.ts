import { NextRequest, NextResponse } from "next/server";
import {
  extractMeta,
  fetchPage,
  normalizeUrl,
  type CheckStatus,
} from "@/lib/site-analysis";
import { checkAndDeductCredits } from "@/lib/auth";

interface SpiderRequest {
  target: string;
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: SpiderRequest = await req.json();
    const { target } = body;
    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入目标 URL" },
        { status: 400 }
      );
    }

    const url = normalizeUrl(target);
    const parsed = new URL(url);

    const googlebotPage = await fetchPage(url, {
      bodyLimit: 1_000_000,
      timeoutMs: 20000,
      // fetchPage 使用默认 UA，这里再单独以 Googlebot UA 请求一次
    });

    let googlebotStatus = 0;
    let googlebotSize = 0;
    try {
      const res = await fetch(googlebotPage.finalUrl, {
        redirect: "follow",
        signal: AbortSignal.timeout(15000),
        headers: {
          "User-Agent":
            "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
          Accept: "text/html,application/xhtml+xml",
          "Accept-Language": "zh-CN,zh;q=0.9",
        },
      });
      googlebotStatus = res.status;
      const text = await res.text();
      googlebotSize = text.length;
    } catch {
      googlebotStatus = 0;
    }

    let robotsContent = "";
    try {
      const res = await fetch(`${parsed.protocol}//${parsed.host}/robots.txt`, {
        redirect: "follow",
        signal: AbortSignal.timeout(8000),
        headers: { "User-Agent": "Googlebot/2.1" },
      });
      robotsContent = (await res.text()).slice(0, 3000);
    } catch {
      // ignore
    }

    const meta = extractMeta(googlebotPage.html, googlebotPage.finalUrl);
    const noindex = Boolean(meta.robots?.includes("noindex"));
    const robotsDisallow = robotsContent
      .toLowerCase()
      .includes(`disallow: ${parsed.pathname}`) ||
      (robotsContent.toLowerCase().includes("disallow: /") &&
        parsed.pathname !== "/");

    const checks: Array<{ name: string; status: CheckStatus; detail: string }> = [
      {
        name: "Googlebot 抓取",
        status: googlebotStatus >= 200 && googlebotStatus < 400 ? "pass" : "risk",
        detail:
          googlebotStatus >= 200 && googlebotStatus < 400
            ? `Googlebot UA 返回 HTTP ${googlebotStatus}`
            : "Googlebot UA 抓取失败",
      },
      {
        name: "robots.txt 屏蔽",
        status: robotsDisallow ? "risk" : "pass",
        detail: robotsDisallow
          ? "该路径被 robots.txt 规则屏蔽"
          : "robots.txt 未屏蔽该路径",
      },
      {
        name: "meta noindex",
        status: noindex ? "risk" : "pass",
        detail: noindex
          ? "页面声明了 noindex，不会被收录"
          : "页面允许索引",
      },
      {
        name: "内容可抓取性",
        status:
          meta.wordCount > 0 ? "pass" : "warn",
        detail:
          meta.wordCount > 0
            ? `抓取到约 ${meta.wordCount} 字正文内容`
            : "未抓取到正文内容（可能依赖 JS 渲染）",
      },
    ];

    return NextResponse.json({
      url,
      finalUrl: googlebotPage.finalUrl,
      normalStatus: googlebotPage.statusCode,
      googlebotStatus,
      googlebotSize,
      normalSize: googlebotPage.size,
      title: meta.title,
      description: meta.description,
      metaRobots: meta.robots,
      robotsContent: robotsContent.slice(0, 1500),
      checks,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "检测失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
