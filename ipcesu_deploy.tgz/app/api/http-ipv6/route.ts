import { NextRequest, NextResponse } from "next/server";
import { execFile } from "child_process";
import { promisify } from "util";
import {
  resolveAddresses,
  sanitizeHost,
  serverHasIpv6,
} from "@/lib/net-tools";
import { checkAndDeductCredits } from "@/lib/auth";

const execFileAsync = promisify(execFile);

interface HttpIpv6Request {
  target: string;
}

function normalizeUrl(target: string): string {
  const trimmed = target.trim();
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  return `https://${trimmed}`;
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: HttpIpv6Request = await req.json();
    const { target } = body;

    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入有效的 URL 或域名" },
        { status: 400 }
      );
    }

    const urlStr = normalizeUrl(target);
    let parsed: URL;
    try {
      parsed = new URL(urlStr);
    } catch {
      return NextResponse.json({ error: "URL 格式不正确" }, { status: 400 });
    }
    if (!/^https?:$/.test(parsed.protocol)) {
      return NextResponse.json(
        { error: "仅支持 HTTP / HTTPS 协议" },
        { status: 400 }
      );
    }

    const host = sanitizeHost(parsed.hostname);
    const ipv6Addresses = await resolveAddresses(host, 6);
    if (ipv6Addresses.length === 0) {
      return NextResponse.json(
        { error: "目标域名没有 IPv6 (AAAA) 记录，无法进行 IPv6 检测" },
        { status: 400 }
      );
    }

    const ipv6Available = await serverHasIpv6();
    if (!ipv6Available) {
      return NextResponse.json({
        target: host,
        resolvedIps: ipv6Addresses,
        status: "ipv6-unavailable",
        message:
          "当前检测节点未启用 IPv6 网络，无法执行真实 IPv6 HTTP 检测。已为您解析目标的 AAAA 记录，如需完整检测请为服务器开通 IPv6。",
      });
    }

    const format =
      "%{http_code}|%{time_total}|%{time_connect}|%{time_starttransfer}|%{size_download}|%{url_effective}|%{num_redirects}|%{remote_ip}";
    let stdout: string;
    try {
      ({ stdout } = await execFileAsync(
        "curl",
        [
          "-6",
          "-s",
          "-o",
          "/dev/null",
          "-L",
          "--max-time",
          "20",
          "-w",
          format,
          urlStr,
        ],
        { timeout: 25000, maxBuffer: 1024 * 1024 }
      ));
    } catch {
      throw new Error("目标站点 IPv6 不可达（连接失败或超时）");
    }

    const [statusCode, timeTotal, timeConnect, timeTtfb, size, finalUrl, redirects, remoteIp] =
      stdout.split("|");

    return NextResponse.json({
      url: urlStr,
      finalUrl,
      statusCode: parseInt(statusCode, 10) || 0,
      remoteIp,
      resolvedIps: ipv6Addresses,
      totalTime: Number(Number(timeTotal).toFixed(2)),
      connectTime: Number(Number(timeConnect).toFixed(2)),
      ttfb: Number(Number(timeTtfb).toFixed(2)),
      size: parseInt(size, 10) || 0,
      redirects: parseInt(redirects, 10) || 0,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "检测失败";
    return NextResponse.json({ error: `IPv6 HTTP 检测失败：${message}` }, { status: 500 });
  }
}
