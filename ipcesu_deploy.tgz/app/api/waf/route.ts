import { NextRequest, NextResponse } from "next/server";
import {
  fetchPage,
  normalizeUrl,
  type CheckStatus,
} from "@/lib/site-analysis";
import { checkAndDeductCredits } from "@/lib/auth";

interface WafRequest {
  target: string;
}

const WAF_SIGNATURES: Array<{ name: string; test: (h: Record<string, string>) => boolean }> = [
  { name: "Cloudflare", test: (h) => Boolean(h["cf-ray"] || h["cf-cache-status"] || h["cf-connecting-ip"]) },
  { name: "阿里云盾", test: (h) => /aliyunwaf|yundun/i.test(String(h["server"] || "") + String(h["x-wa-info"] || "")) },
  { name: "安全狗", test: (h) => /safedog|sd-waf/i.test(String(h["server"] || "")) },
  { name: "腾讯云 WAF", test: (h) => /waf|tencentwaf/i.test(String(h["server"] || "") + String(h["x-wa-info"] || "")) },
  { name: "百度云加速", test: (h) => /yunjiasu|baidu/i.test(String(h["server"] || "")) },
  { name: "360 网站卫士", test: (h) => /360wzb/i.test(String(h["server"] || "")) },
  { name: "Sucuri", test: (h) => /sucuri/i.test(String(h["server"] || "") + String(h["x-sucuri-id"] || "")) },
  { name: "Imperva", test: (h) => /imperva|incapsula/i.test(String(h["server"] || "")) },
  { name: "AWS WAF", test: (h) => /awswaf/i.test(String(h["x-amz-cf-id"] || "") + String(h["server"] || "")) },
];

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: WafRequest = await req.json();
    const { target } = body;
    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入目标 URL" },
        { status: 400 }
      );
    }

    const url = normalizeUrl(target);
    const page = await fetchPage(url, { bodyLimit: 200_000, timeoutMs: 15000 });
    const h = page.headers;

    const detected = WAF_SIGNATURES.filter((sig) => sig.test(h)).map((s) => s.name);
    const signals = Object.entries(h)
      .filter(([key, value]) =>
        /^(server|x-wa-info|x-sucuri-id|cf-ray|cf-cache-status|x-cdn|x-served-by|x-cache|x-powered-by|x-request-id)$/i.test(
          key
        )
      )
      .map(([key, value]) => ({ header: key, value: String(value).slice(0, 100) }));

    const status: CheckStatus = detected.length > 0 ? "warn" : "pass";
    return NextResponse.json({
      url,
      status,
      detected,
      signals,
      checks: [
        {
          name: "WAF 识别",
          status,
          detail:
            detected.length > 0
              ? `检测到 ${detected.join("、")} 特征`
              : "未检测到常见 WAF 特征（可能无防护或使用自研防护）",
        },
        {
          name: "CDN/代理层",
          status: h["cf-ray"] || h["x-cdn"] || h["x-served-by"] ? "warn" : "pass",
          detail:
            h["cf-ray"] || h["x-cdn"] || h["x-served-by"]
              ? "站点前面存在 CDN/代理层"
              : "未检测到 CDN/代理层特征",
        },
      ],
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "检测失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
