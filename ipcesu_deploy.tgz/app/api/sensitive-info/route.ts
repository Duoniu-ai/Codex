import { NextRequest, NextResponse } from "next/server";
import {
  fetchPage,
  normalizeUrl,
  type CheckStatus,
} from "@/lib/site-analysis";
import { checkAndDeductCredits } from "@/lib/auth";

interface SensitiveInfoRequest {
  target: string;
}

const PATTERNS: Array<{ name: string; regex: RegExp; risk: "high" | "medium" | "low" }> = [
  { name: "邮箱地址", regex: /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g, risk: "low" },
  { name: "OpenAI API Key", regex: /sk-[a-zA-Z0-9]{20,}/g, risk: "high" },
  { name: "Google API Key", regex: /AIza[0-9A-Za-z_-]{35}/g, risk: "high" },
  { name: "AWS Access Key", regex: /AKIA[0-9A-Z]{16}/g, risk: "high" },
  { name: "GitHub Token", regex: /ghp_[a-zA-Z0-9]{36}/g, risk: "high" },
  { name: "私钥块", regex: /-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----/g, risk: "high" },
  { name: "密码参数", regex: /(password|passwd|pwd|secret)\s*[:=]\s*["'][^"']{4,}["']/gi, risk: "high" },
  { name: "数据库连接串", regex: /(mongodb|mysql|postgres|redis|amqp):\/\/[^\s"']+/gi, risk: "high" },
  { name: "内网 IP", regex: /\b(10\.\d{1,3}\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|172\.(1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3})\b/g, risk: "medium" },
  { name: "Token 参数", regex: /(token|api[_-]?key|access[_-]?key)\s*[:=]\s*["'][^"']{8,}["']/gi, risk: "high" },
];

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: SensitiveInfoRequest = await req.json();
    const { target } = body;
    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入目标 URL" },
        { status: 400 }
      );
    }

    const url = normalizeUrl(target);
    const page = await fetchPage(url, { bodyLimit: 2_000_000, timeoutMs: 20000 });
    const html = page.html;

    // 抓取页面引用的前 3 个同域 JS/CSS
    const assetUrls = Array.from(
      new Set(
        [
          ...(html.match(/<script[^>]+src=["']([^"']+)["']/gi) || []),
          ...(html.match(/<link[^>]+href=["']([^"']+)["'][^>]*stylesheet/gi) || []),
        ]
          .map((tag) => tag.match(/["']([^"']+)["']/)?.[1] || "")
          .filter(Boolean)
          .map((src) => {
            try {
              return new URL(src, page.finalUrl).toString();
            } catch {
              return "";
            }
          })
          .filter((u) => u && new URL(u).hostname === new URL(page.finalUrl).hostname)
      )
    ).slice(0, 3);

    let assetText = "";
    for (const assetUrl of assetUrls) {
      try {
        const res = await fetch(assetUrl, {
          redirect: "follow",
          signal: AbortSignal.timeout(8000),
        });
        if (res.ok) assetText += `\n${(await res.text()).slice(0, 300_000)}`;
      } catch {
        // ignore asset fetch errors
      }
    }

    const scanText = `${html}\n${assetText}`;
    const findings: Array<{
      type: string;
      risk: "high" | "medium" | "low";
      samples: string[];
      count: number;
    }> = [];

    for (const pattern of PATTERNS) {
      const matches = scanText.match(pattern.regex);
      if (matches && matches.length > 0) {
        const deduped = Array.from(new Set(matches)).slice(0, 5);
        findings.push({
          type: pattern.name,
          risk: pattern.risk,
          samples: deduped.map((m) =>
            m.length > 80 ? `${m.slice(0, 40)}...${m.slice(-30)}` : m
          ),
          count: matches.length,
        });
      }
    }

    const highRisk = findings.filter((f) => f.risk === "high").length;
    const status: CheckStatus = highRisk > 0 ? "risk" : findings.length > 0 ? "warn" : "pass";
    return NextResponse.json({
      url,
      status,
      highRisk,
      total: findings.length,
      assetsScanned: assetUrls.length,
      findings,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "检测失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
