import { NextRequest, NextResponse } from "next/server";
import {
  extractMeta,
  fetchPage,
  normalizeUrl,
  runWithConcurrency,
} from "@/lib/site-analysis";
import { checkAndDeductCredits } from "@/lib/auth";

interface BacklinkRequest {
  target: string;
}

const MAX_LINKS = 30;

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: BacklinkRequest = await req.json();
    const { target } = body;
    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入目标 URL" },
        { status: 400 }
      );
    }

    const url = normalizeUrl(target);
    const page = await fetchPage(url, { bodyLimit: 2_000_000, timeoutMs: 20000 });
    const meta = extractMeta(page.html, page.finalUrl);
    const targetHost = new URL(page.finalUrl).hostname;

    // 优先检查外链（友情链接通常为站外链接），不足再补站内链接
    const uniqueLinks = Array.from(new Set(meta.links));
    const external = uniqueLinks.filter(
      (l) => new URL(l).hostname !== targetHost
    );
    const internal = uniqueLinks.filter(
      (l) => new URL(l).hostname === targetHost
    );
    const checkedLinks = [...external, ...internal].slice(0, MAX_LINKS);

    const items: Array<{
      url: string;
      code: number;
      time: number;
      status: "ok" | "redirect" | "dead";
    }> = [];

    await runWithConcurrency(checkedLinks, 5, async (link) => {
      try {
        const result = await fetchPage(link, {
          bodyLimit: 50_000,
          timeoutMs: 10000,
          maxRedirects: 2,
        });
        const status =
          result.statusCode >= 400
            ? "dead"
            : result.statusCode >= 300
            ? "redirect"
            : "ok";
        items.push({
          url: link,
          code: result.statusCode,
          time: Math.round(result.totalTime),
          status,
        });
      } catch {
        items.push({ url: link, code: 0, time: 0, status: "dead" });
      }
    });

    const deadLinks = items.filter((i) => i.status === "dead");
    return NextResponse.json({
      target: url,
      total: items.length,
      ok: items.filter((i) => i.status === "ok").length,
      redirect: items.filter((i) => i.status === "redirect").length,
      dead: deadLinks.length,
      externalCount: external.length,
      items,
      deadLinks: deadLinks.map(({ url: u, code }) => ({ url: u, code })),
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "检测失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
