import { NextRequest, NextResponse } from "next/server";
import {
  extractMeta,
  fetchPage,
  normalizeUrl,
  type CheckStatus,
} from "@/lib/site-analysis";
import { checkAndDeductCredits } from "@/lib/auth";

interface OpenGraphRequest {
  target: string;
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: OpenGraphRequest = await req.json();
    const { target } = body;
    if (!target || typeof target !== "string") {
      return NextResponse.json(
        { error: "请输入目标 URL" },
        { status: 400 }
      );
    }

    const url = normalizeUrl(target);
    const page = await fetchPage(url, { bodyLimit: 1_000_000, timeoutMs: 20000 });
    const meta = extractMeta(page.html, page.finalUrl);

    const tags = [
      { name: "og:title", value: meta.ogTitle, required: true },
      { name: "og:description", value: meta.ogDescription, required: true },
      { name: "og:image", value: meta.ogImage, required: true },
      { name: "og:type", value: meta.ogType, required: false },
      { name: "og:url", value: meta.canonical, required: false },
      { name: "twitter:card", value: meta.twitterCard, required: false },
    ];

    const checks: Array<{ name: string; status: CheckStatus; detail: string }> =
      tags.map((tag) => ({
        name: tag.name,
        status: tag.value ? "pass" : tag.required ? "risk" : "warn",
        detail: tag.value || (tag.required ? "缺失（影响分享卡片展示）" : "未设置（可选）"),
      }));

    const complete = tags.filter((t) => t.required).every((t) => t.value);
    return NextResponse.json({
      url,
      complete,
      ogTitle: meta.ogTitle,
      ogDescription: meta.ogDescription,
      ogImage: meta.ogImage,
      ogType: meta.ogType,
      ogUrl: meta.canonical,
      twitterCard: meta.twitterCard,
      checks,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "检测失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
