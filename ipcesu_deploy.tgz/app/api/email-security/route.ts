import { NextRequest, NextResponse } from "next/server";
import { Resolver } from "dns/promises";
import { checkAndDeductCredits } from "@/lib/auth";

interface EmailSecurityRequest {
  domain: string;
}

async function queryTxt(domain: string): Promise<string[]> {
  const resolver = new Resolver();
  resolver.setServers(["8.8.8.8", "1.1.1.1", "223.5.5.5"]);
  try {
    const records = await resolver.resolveTxt(domain);
    return records.map((r) => r.join(""));
  } catch {
    return [];
  }
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: EmailSecurityRequest = await req.json();
    const { domain } = body;
    if (!domain || typeof domain !== "string") {
      return NextResponse.json(
        { error: "请输入域名" },
        { status: 400 }
      );
    }

    const cleanDomain = domain
      .trim()
      .toLowerCase()
      .replace(/^https?:\/\//i, "")
      .replace(/\/.*$/, "");

    const [spfRecords, dkimRecords, dmarcRecords] = await Promise.all([
      queryTxt(cleanDomain),
      queryTxt(`default._domainkey.${cleanDomain}`),
      queryTxt(`_dmarc.${cleanDomain}`),
    ]);

    const spf = spfRecords.find((r) => r.startsWith("v=spf1")) || null;
    const dmarc = dmarcRecords.find((r) => r.startsWith("v=DMARC1")) || null;
    const dkim = dkimRecords.find((r) => r.startsWith("v=DKIM1")) || null;

    const checks = [
      {
        name: "SPF 记录",
        status: spf ? "pass" : "risk",
        detail: spf
          ? spf.slice(0, 120)
          : "未配置 SPF，域名可被伪造发信",
      },
      {
        name: "SPF 策略",
        status: spf?.includes("-all") ? "pass" : "warn",
        detail: spf?.includes("-all")
          ? "SPF 使用 -all 严格策略"
          : spf?.includes("~all")
          ? "SPF 使用 ~all 软失败策略"
          : "SPF 未配置 -all/~all 终止策略",
      },
      {
        name: "DKIM 记录",
        status: dkim ? "pass" : "warn",
        detail: dkim
          ? "检测到 default 选择器 DKIM 记录"
          : "default 选择器未检测到 DKIM（可能使用了其他选择器）",
      },
      {
        name: "DMARC 记录",
        status: dmarc ? "pass" : "risk",
        detail: dmarc
          ? dmarc.slice(0, 120)
          : "未配置 DMARC，无法控制伪造邮件的处理策略",
      },
      {
        name: "DMARC 策略",
        status: dmarc?.includes("p=reject")
          ? "pass"
          : dmarc?.includes("p=quarantine")
          ? "warn"
          : "risk",
        detail: dmarc
          ? `策略：${dmarc.match(/p=(\w+)/)?.[1] || "未知"}`
          : "未配置",
      },
    ];

    return NextResponse.json({
      domain: cleanDomain,
      spf: spf || null,
      dkim: dkim || null,
      dmarc: dmarc || null,
      checks,
      passCount: checks.filter((c) => c.status === "pass").length,
      total: checks.length,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "检测失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
