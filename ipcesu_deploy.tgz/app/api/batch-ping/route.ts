import { NextRequest, NextResponse } from "next/server";
import { runPing, sanitizeHost } from "@/lib/net-tools";
import { checkAndDeductCredits } from "@/lib/auth";

interface BatchPingRequest {
  targets: string[];
}

const MAX_TARGETS = 20;
const CONCURRENCY = 4;

async function runWithConcurrency<T>(
  items: T[],
  limit: number,
  worker: (item: T) => Promise<void>
) {
  let cursor = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (cursor < items.length) {
      const item = items[cursor++];
      await worker(item);
    }
  });
  await Promise.all(workers);
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: BatchPingRequest = await req.json();
    const { targets } = body;

    if (!Array.isArray(targets) || targets.length === 0) {
      return NextResponse.json(
        { error: "请至少输入一个目标地址" },
        { status: 400 }
      );
    }

    const list = targets
      .map((t) => (typeof t === "string" ? sanitizeHost(t) : ""))
      .filter(Boolean)
      .slice(0, MAX_TARGETS);

    if (list.length === 0) {
      return NextResponse.json(
        { error: "请输入有效的目标地址" },
        { status: 400 }
      );
    }

    const items: Array<{
      target: string;
      resolvedIp: string;
      status: "success" | "timeout" | "error";
      avgLatency: number;
      packetLoss: number;
      error?: string;
    }> = [];

    await runWithConcurrency(list, CONCURRENCY, async (target) => {
      try {
        const result = await runPing(target, { count: 2, timeoutSec: 2 });
        items.push({
          target: result.target,
          resolvedIp: result.resolvedIp,
          status: result.status,
          avgLatency: result.avgLatency,
          packetLoss: result.packetLoss,
        });
      } catch (err) {
        items.push({
          target,
          resolvedIp: "--",
          status: "error",
          avgLatency: 0,
          packetLoss: 100,
          error: err instanceof Error ? err.message : "检测失败",
        });
      }
    });

    return NextResponse.json({
      total: items.length,
      success: items.filter((i) => i.status === "success").length,
      failed: items.filter((i) => i.status !== "success").length,
      items,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "批量检测失败";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
