import { NextRequest, NextResponse } from "next/server";
import { checkAndDeductCredits } from "@/lib/auth";

interface BgpRequest {
  query: string;
}

async function fetchJson(url: string, timeoutMs = 10000): Promise<unknown> {
  const res = await fetch(url, {
    redirect: "follow",
    signal: AbortSignal.timeout(timeoutMs),
    headers: { Accept: "application/json" },
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

function extractAsnFromRdap(data: Record<string, unknown>): string | null {
  const asnList = Array.isArray(data.asn) ? data.asn : [];
  const entry = asnList[0] as
    | { handle?: string; autnum?: number | string; name?: string }
    | undefined;
  if (!entry) return null;
  const raw = String(entry.autnum ?? entry.handle ?? "");
  return raw.replace(/^AS/i, "") || null;
}

export async function POST(req: NextRequest) {
  try {
    const creditCheck = await checkAndDeductCredits(req);
    if (creditCheck.error) {
      return NextResponse.json(
        { error: creditCheck.error },
        { status: 403 }
      );
    }

    const body: BgpRequest = await req.json();
    const { query } = body;

    if (!query || typeof query !== "string") {
      return NextResponse.json(
        { error: "请输入 ASN 或 IP 地址" },
        { status: 400 }
      );
    }

    const trimmed = query.trim();
    let asn: string | null = null;
    let ipInfo: Record<string, unknown> | null = null;

    const asnMatch = trimmed.match(/^(?:AS)?(\d{1,8})$/i);
    if (asnMatch) {
      asn = asnMatch[1];
    } else {
      const ipRegex =
        /^(\d{1,3}\.){3}\d{1,3}$|^([0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}$/;
      if (!ipRegex.test(trimmed)) {
        return NextResponse.json(
          { error: "请输入有效的 ASN（如 AS4538）或 IP 地址" },
          { status: 400 }
        );
      }

      try {
        const rdap = (await fetchJson(
          `https://rdap.org/ip/${encodeURIComponent(trimmed)}`
        )) as Record<string, unknown>;
        ipInfo = {
          handle: rdap.handle || null,
          name: rdap.name || null,
          country: rdap.country || null,
          type: rdap.type || null,
          startAddress: rdap.startAddress || null,
          endAddress: rdap.endAddress || null,
        };
        asn = extractAsnFromRdap(rdap);
      } catch {
        // fall through to ipinfo below
      }

      if (!asn) {
        try {
          const ipinfo = (await fetchJson(
            `https://ipinfo.io/${encodeURIComponent(trimmed)}/json`
          )) as { org?: string; country?: string };
          const orgMatch = ipinfo.org?.match(/^AS(\d+)/i);
          asn = orgMatch?.[1] || null;
          if (asn) {
            ipInfo = {
              handle: trimmed,
              name: ipinfo.org || null,
              country: ipinfo.country || null,
            };
          }
        } catch {
          // ignore
        }
      }
    }

    if (!asn) {
      return NextResponse.json(
        { error: "未找到该 IP 对应的 ASN 信息" },
        { status: 404 }
      );
    }

    let name = "";
    let country = "";
    let prefixes: string[] = [];
    let neighborCount = 0;

    try {
      const [overview, prefixesData, neighboursData] = await Promise.all([
        fetchJson(
          `https://stat.ripe.net/data/as-overview/data.json?resource=AS${asn}`
        ).catch(() => null),
        fetchJson(
          `https://stat.ripe.net/data/announced-prefixes/data.json?resource=AS${asn}`
        ).catch(() => null),
        fetchJson(
          `https://stat.ripe.net/data/as-neighbours/data.json?resource=AS${asn}`
        ).catch(() => null),
      ]);

      const overviewData = (overview as { data?: { holder?: string; country?: string } })?.data;
      name = overviewData?.holder || "";
      country = overviewData?.country || "";

      const prefixesDataObj = prefixesData as {
        data?: { prefixes?: { prefix?: string }[] };
      };
      prefixes = (
        prefixesDataObj?.data?.prefixes ||
        []
      ).map((p) => p.prefix).filter(Boolean) as string[];

      const neighboursDataObj = neighboursData as {
        data?: { neighbours?: unknown[]; left_neighbours?: unknown[]; right_neighbours?: unknown[] };
      };
      const neighbours =
        neighboursDataObj?.data?.neighbours ||
        neighboursDataObj?.data?.left_neighbours ||
        [];
      neighborCount = Array.isArray(neighbours) ? neighbours.length : 0;
    } catch {
      // fall back to RDAP-level info only
    }

    if (!name) name = String(ipInfo?.name || `AS${asn}`);
    if (!country) country = String(ipInfo?.country || "未知");

    return NextResponse.json({
      query: trimmed,
      asn: `AS${asn}`,
      name,
      country,
      prefixCount: prefixes.length,
      neighborCount,
      prefixes: prefixes.slice(0, 100),
      ipInfo,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "查询失败";
    return NextResponse.json({ error: `BGP 查询失败：${message}` }, { status: 500 });
  }
}
