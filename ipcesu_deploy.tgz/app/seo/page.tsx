"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { ChecksResult } from "@/components/tools/checks-result";
import { Card, CardContent } from "@/components/ui/card";
import { Search } from "lucide-react";

interface SeoResult {
  url: string;
  finalUrl: string;
  statusCode: number;
  score: number;
  checks: Array<{ name: string; status: "pass" | "warn" | "risk"; detail: string }>;
  meta: {
    title: string;
    description: string;
    h1Count: number;
    canonical: string | null;
    robots: string | null;
    wordCount: number;
  };
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="SEO 检测"
      description="SEO 基础配置检测"
      icon={Search}
      tips={[
        "输入目标 URL，服务器真实抓取页面并逐项检测。",
        "覆盖标题、描述、H1、canonical、结构化数据、图片 alt 等 15 项。",
        "按风险项优先级修复，可反复检测复查效果。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      demo={false}
      onRun={async (values) => {
        const res = await fetch("/api/seo", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ target: values.url.trim() }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "检测失败");
        return data as SeoResult;
      }}
      renderResult={(result) => {
        const data = result as SeoResult;
        return (
          <ChecksResult score={data.score} checks={data.checks}>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground mb-1">页面标题</div>
                  <div className="text-sm font-medium text-foreground break-all">
                    {data.meta.title || "--"}
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground mb-1">页面描述</div>
                  <div className="text-sm text-muted-foreground line-clamp-2 break-all">
                    {data.meta.description || "--"}
                  </div>
                </CardContent>
              </Card>
            </div>
          </ChecksResult>
        );
      }}
    />
  );
}
