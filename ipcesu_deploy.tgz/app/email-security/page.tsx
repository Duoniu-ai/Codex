"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { ChecksResult } from "@/components/tools/checks-result";
import { Card, CardContent } from "@/components/ui/card";
import { MailCheck } from "lucide-react";

interface EmailSecurityResult {
  domain: string;
  spf: string | null;
  dkim: string | null;
  dmarc: string | null;
  checks: Array<{ name: string; status: "pass" | "warn" | "risk"; detail: string }>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="邮件安全检测"
      description="SPF/DKIM/DMARC 检测"
      icon={MailCheck}
      tips={[
        "通过公共 DNS 查询域名的 SPF、DKIM、DMARC 记录。",
        "三项齐全可显著降低域名被伪造发信的风险。",
        "检测数据来自真实 DNS 解析。",
      ]}
      inputs={[
        { id: "domain", label: "域名", type: "text", placeholder: "example.com" },
      ]}
      demo={false}
      onRun={async (values) => {
        const res = await fetch("/api/email-security", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ domain: values.domain.trim() }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "检测失败");
        return data as EmailSecurityResult;
      }}
      renderResult={(result) => {
        const data = result as EmailSecurityResult;
        return (
          <ChecksResult checks={data.checks}>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[
                { label: "SPF", value: data.spf },
                { label: "DKIM (default)", value: data.dkim },
                { label: "DMARC", value: data.dmarc },
              ].map((item) => (
                <Card key={item.label} className="border-border/50 bg-card">
                  <CardContent className="p-4">
                    <div className="text-sm text-muted-foreground mb-1">{item.label}</div>
                    <div className="text-xs font-mono text-foreground break-all leading-relaxed">
                      {item.value || "未配置"}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </ChecksResult>
        );
      }}
    />
  );
}
