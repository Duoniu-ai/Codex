"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { ChecksResult } from "@/components/tools/checks-result";
import { Card, CardContent } from "@/components/ui/card";
import { AppWindow } from "lucide-react";

interface OpenGraphResult {
  url: string;
  complete: boolean;
  ogTitle: string | null;
  ogDescription: string | null;
  ogImage: string | null;
  ogType: string | null;
  ogUrl: string | null;
  twitterCard: string | null;
  checks: Array<{ name: string; status: "pass" | "warn" | "risk"; detail: string }>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="Open Graph"
      description="社交分享标签检测"
      icon={AppWindow}
      tips={[
        "检查页面 og:title / og:description / og:image 等社交分享标签。",
        "配置完整后，分享到微信、微博、Facebook 会显示丰富卡片。",
        "检测由服务器真实抓取页面完成。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      demo={false}
      onRun={async (values) => {
        const res = await fetch("/api/open-graph", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ target: values.url.trim() }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "检测失败");
        return data as OpenGraphResult;
      }}
      renderResult={(result) => {
        const data = result as OpenGraphResult;
        return (
          <ChecksResult checks={data.checks}>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground mb-1">og:title</div>
                  <div className="text-sm font-medium text-foreground break-all">
                    {data.ogTitle || "--"}
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground mb-1">og:description</div>
                  <div className="text-sm text-muted-foreground line-clamp-3 break-all">
                    {data.ogDescription || "--"}
                  </div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground mb-1">og:image</div>
                  <div className="text-sm text-muted-foreground break-all">
                    {data.ogImage || "--"}
                  </div>
                </CardContent>
              </Card>
            </div>
          </ChecksResult>
        );
      }}
    />
  );
}
