"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { ChecksResult } from "@/components/tools/checks-result";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Crosshair } from "lucide-react";

interface CorsResult {
  url: string;
  status: "pass" | "warn" | "risk";
  vulnerable: number;
  results: Array<{
    origin: string;
    allowOrigin: string | null;
    allowCredentials: string | null;
    allowMethods: string | null;
    reflected: boolean;
  }>;
  checks: Array<{ name: string; status: "pass" | "warn" | "risk"; detail: string }>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="CORS 检测"
      description="跨域配置安全检测"
      icon={Crosshair}
      tips={[
        "发送携带不同 Origin 的跨域请求，检查 Access-Control-Allow-Origin。",
        "若响应反射不可信 Origin，则存在跨域信息泄露风险。",
        "生产环境应只允许明确的可信域名。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://api.example.com" },
      ]}
      demo={false}
      onRun={async (values) => {
        const res = await fetch("/api/cors", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ target: values.url.trim() }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "检测失败");
        return data as CorsResult;
      }}
      renderResult={(result) => {
        const data = result as CorsResult;
        return (
          <ChecksResult checks={data.checks}>
            <Card className="border-border/50 bg-card">
              <CardHeader className="pb-3">
                <CardTitle>Origin 反射测试</CardTitle>
                <CardDescription>携带不同 Origin 的跨域请求结果</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Origin</TableHead>
                        <TableHead>Allow-Origin</TableHead>
                        <TableHead>凭证</TableHead>
                        <TableHead>反射</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {data.results.map((r) => (
                        <TableRow key={r.origin}>
                          <TableCell className="font-mono text-xs break-all">{r.origin}</TableCell>
                          <TableCell className="font-mono text-xs break-all">
                            {r.allowOrigin || "未返回"}
                          </TableCell>
                          <TableCell>{r.allowCredentials || "--"}</TableCell>
                          <TableCell>
                            <span className={r.reflected ? "text-red-600 font-medium" : "text-green-600"}>
                              {r.reflected ? "是（风险）" : "否"}
                            </span>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </ChecksResult>
        );
      }}
    />
  );
}
