"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Link as LinkIcon } from "lucide-react";

interface LinkItem {
  url: string;
  code: number;
  time: number;
  status: "ok" | "redirect" | "dead";
}

interface BacklinkResult {
  target: string;
  total: number;
  ok: number;
  redirect: number;
  dead: number;
  externalCount: number;
  items: LinkItem[];
  deadLinks: Array<{ url: string; code: number }>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="友情链接查询"
      description="检测友链有效性与 SEO 价值"
      icon={LinkIcon}
      tips={[
        "抓取目标页面，优先检测站外链接（友情链接）的有效性。",
        "逐一真实请求验证状态码，找出失效链接。",
        "单次最多检测 30 个链接。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      demo={false}
      onRun={async (values) => {
        const res = await fetch("/api/backlink-check", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ target: values.url.trim() }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "检测失败");
        return data as BacklinkResult;
      }}
      renderResult={(result) => {
        const data = result as BacklinkResult;
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground">检测链接</div>
                  <div className="text-2xl font-semibold">{data.total}</div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground">正常</div>
                  <div className="text-2xl font-semibold text-green-700">{data.ok}</div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground">跳转</div>
                  <div className="text-2xl font-semibold text-amber-700">{data.redirect}</div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground">失效</div>
                  <div className="text-2xl font-semibold text-red-700">{data.dead}</div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle>链接检测明细</CardTitle>
                <CardDescription>站外 {data.externalCount} 个，站内 {data.total - data.externalCount} 个</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>链接</TableHead>
                        <TableHead className="w-24">状态码</TableHead>
                        <TableHead className="w-24">耗时</TableHead>
                        <TableHead className="w-24">结果</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {data.items.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={4} className="text-muted-foreground">
                            未检测到链接（页面可能由 JS 渲染）
                          </TableCell>
                        </TableRow>
                      )}
                      {data.items.map((item, idx) => (
                        <TableRow key={idx}>
                          <TableCell className="text-muted-foreground break-all max-w-xs whitespace-normal">
                            {item.url}
                          </TableCell>
                          <TableCell>{item.code || "--"}</TableCell>
                          <TableCell>{item.time > 0 ? `${item.time} ms` : "--"}</TableCell>
                          <TableCell>
                            <Badge
                              variant="outline"
                              className={
                                item.status === "ok"
                                  ? "bg-green-100 text-green-700 border-green-200"
                                  : item.status === "redirect"
                                  ? "bg-amber-100 text-amber-700 border-amber-200"
                                  : "bg-red-100 text-red-700 border-red-200"
                              }
                            >
                              {item.status === "ok" ? "正常" : item.status === "redirect" ? "跳转" : "失效"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}
