"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertTriangle, CheckCircle } from "lucide-react";

interface Finding {
  type: string;
  risk: "high" | "medium" | "low";
  samples: string[];
  count: number;
}

interface SensitiveInfoResult {
  url: string;
  status: "pass" | "warn" | "risk";
  highRisk: number;
  total: number;
  assetsScanned: number;
  findings: Finding[];
}

const riskConfig = {
  high: { text: "高危", cls: "bg-red-100 text-red-700 border-red-200" },
  medium: { text: "中危", cls: "bg-amber-100 text-amber-700 border-amber-200" },
  low: { text: "低危", cls: "bg-blue-100 text-blue-700 border-blue-200" },
};

export default function Page() {
  return (
    <SimulatedToolPage
      title="敏感信息泄露"
      description="敏感文件泄露检测"
      icon={AlertTriangle}
      tips={[
        "抓取页面 HTML 及其引用的同域 JS/CSS，扫描敏感信息。",
        "检测邮箱、API Key、私钥、数据库连接串、内网 IP 等。",
        "发现高危项应立即轮换凭据并清理代码。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      demo={false}
      onRun={async (values) => {
        const res = await fetch("/api/sensitive-info", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ target: values.url.trim() }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "检测失败");
        return data as SensitiveInfoResult;
      }}
      renderResult={(result) => {
        const data = result as SensitiveInfoResult;
        return (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-3">
              {data.status === "pass" ? (
                <Badge variant="outline" className="bg-green-100 text-green-700 border-green-200">
                  <CheckCircle className="h-3.5 w-3.5 mr-1" />
                  未发现敏感信息
                </Badge>
              ) : (
                <Badge variant="outline" className="bg-red-100 text-red-700 border-red-200">
                  <AlertTriangle className="h-3.5 w-3.5 mr-1" />
                  发现 {data.total} 项敏感信息
                </Badge>
              )}
              <span className="text-sm text-muted-foreground">
                扫描页面 + {data.assetsScanned} 个资源文件
              </span>
            </div>

            {data.findings.length > 0 && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle>检测结果</CardTitle>
                  <CardDescription>匹配到的敏感信息（已脱敏）</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="border rounded-lg overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>类型</TableHead>
                          <TableHead>风险</TableHead>
                          <TableHead>命中次数</TableHead>
                          <TableHead>样本</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {data.findings.map((f) => (
                          <TableRow key={f.type}>
                            <TableCell className="font-medium text-foreground">{f.type}</TableCell>
                            <TableCell>
                              <Badge variant="outline" className={riskConfig[f.risk].cls}>
                                {riskConfig[f.risk].text}
                              </Badge>
                            </TableCell>
                            <TableCell>{f.count}</TableCell>
                            <TableCell className="text-muted-foreground break-all">
                              <div className="space-y-1">
                                {f.samples.map((s, i) => (
                                  <div key={i} className="font-mono text-xs">{s}</div>
                                ))}
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        );
      }}
    />
  );
}
