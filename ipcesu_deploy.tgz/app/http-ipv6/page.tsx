"use client";

import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import { Globe, ArrowRight, Code, Clock, Server, ShieldCheck } from "lucide-react";

interface HttpIpv6Result {
  url: string;
  finalUrl: string;
  statusCode: number;
  statusText?: string;
  server?: string;
  contentType?: string;
  totalTime: number;
  connectTime?: number;
  ttfb?: number;
  size?: number;
  redirects?: number;
  remoteIp?: string;
  resolvedIps?: string[];
  bodyPreview?: string;
  status?: "ipv6-unavailable";
  message?: string;
}

export default function HttpIpv6Page() {
  return (
    <Suspense fallback={<HttpIpv6PageSkeleton />}>
      <HttpIpv6PageForm />
    </Suspense>
  );
}

function HttpIpv6PageSkeleton() {
  return (
    <ToolPageLayout
      title="HTTP IPv6"
      description="IPv6 网站测速"
      icon={Globe}
      tips={[
        "输入 URL 或域名，检测 IPv6 下的 HTTP 响应信息。",
        "自动补全 http:// 或 https:// 协议头。",
        "结果包含状态码、响应头、耗时和响应体预览。",
        "IPv6 访问需目标站点与本地网络均支持 IPv6。",
      ]}
    >
      <div className="space-y-3">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    </ToolPageLayout>
  );
}

function HttpIpv6PageForm() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get("q") || "";

  const [target, setTarget] = useState(initialQuery);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<HttpIpv6Result | null>(null);
  const [error, setError] = useState("");

  const handleTest = async () => {
    if (!target.trim()) {
      setError("请输入目标 URL");
      return;
    }

    setLoading(true);
    setError("");
    setResult(null);

    try {
      const res = await fetch("/api/http-ipv6", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ target: target.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "检测失败");
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "检测失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ToolPageLayout
      title="HTTP IPv6"
      description="IPv6 网站测速"
      icon={Globe}
      tips={[
        "输入 URL 或域名，检测 IPv6 下的 HTTP 响应信息。",
        "自动补全 http:// 或 https:// 协议头。",
        "结果包含状态码、响应头、耗时和响应体预览。",
        "IPv6 访问需目标站点与本地网络均支持 IPv6。",
      ]}
    >
      <Card className="border-border/40 bg-card shadow-sm">
        <CardContent className="p-5 space-y-5">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex-1 space-y-2">
              <label className="text-sm font-medium text-foreground">目标 URL</label>
              <Input
                value={target}
                onChange={(e) => setTarget(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleTest()}
                placeholder="例如：baidu.com 或 https://example.com"
                className="bg-secondary/50 border-border/50"
              />
            </div>
            <div className="flex items-end">
              <Button
                onClick={handleTest}
                disabled={loading}
                className="bg-foreground hover:bg-foreground/90 text-background"
              >
                {loading ? "检测中..." : "开始检测"}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {error && (
        <div className="p-4 rounded-lg bg-destructive/10 text-destructive text-sm">
          {error}
        </div>
      )}

      {loading && (
        <Card className="border-border/40 bg-card shadow-sm">
          <CardContent className="p-5 space-y-3">
            <Skeleton className="h-12 w-full" />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
            </div>
            <Skeleton className="h-32 w-full" />
          </CardContent>
        </Card>
      )}

      {result && !loading && (
        <div className="space-y-4 animate-fade-in-up">
          {result.status === "ipv6-unavailable" ? (
            <Card className="border-amber-200 bg-amber-50 dark:border-amber-500/30 dark:bg-amber-500/10">
              <CardContent className="p-5 space-y-3">
                <p className="text-sm text-amber-800 dark:text-amber-200">
                  {result.message}
                </p>
                <div>
                  <div className="flex items-center gap-2 mb-2 text-sm text-amber-800/70 dark:text-amber-200/70">
                    <Server className="h-4 w-4" />
                    目标 AAAA 记录（真实解析）
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {(result.resolvedIps || []).map((ip) => (
                      <span
                        key={ip}
                        className="font-mono text-xs px-2.5 py-1 rounded-md bg-amber-100 dark:bg-amber-500/20 text-amber-900 dark:text-amber-100 break-all"
                      >
                        {ip}
                      </span>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            <>
          <div className="flex flex-wrap items-center gap-3">
            <Badge
              variant={result.statusCode < 400 ? "outline" : "destructive"}
              className={
                result.statusCode < 400
                  ? "bg-green-500/15 text-green-600 border-0"
                  : ""
              }
            >
              {result.statusCode} {result.statusText}
            </Badge>
            <span className="text-sm text-muted-foreground flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" />
              耗时 {result.totalTime.toFixed(0)} ms
            </span>
            <span className="text-sm text-muted-foreground flex items-center gap-1">
              <ArrowRight className="h-3.5 w-3.5" />
              跳转 {result.redirects ?? 0} 次
            </span>
            <span className="text-sm text-muted-foreground flex items-center gap-1">
              <ShieldCheck className="h-3.5 w-3.5" />
              IPv6
            </span>
          </div>

          <Card className="border-0 bg-foreground text-background">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-3 text-background/70 text-sm">
                <Globe className="h-4 w-4" />
                最终地址
              </div>
              <div className="text-lg font-medium font-mono break-all">
                {result.finalUrl}
              </div>
              <div className="text-sm text-background/60 mt-2">
                原始地址：{result.url}（节点：{result.remoteIp || "--"}）
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Server className="h-4 w-4 text-foreground" />
                  Server
                </div>
                <div className="font-medium font-mono text-foreground break-all">
                  {result.server || "--"}
                </div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Code className="h-4 w-4 text-foreground" />
                  Content-Type
                </div>
                <div className="font-medium font-mono text-foreground break-all">
                  {result.contentType || "--"}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-3 text-muted-foreground text-sm">
                <Code className="h-4 w-4 text-foreground" />
                响应体预览
              </div>
              <pre className="text-xs font-mono p-3 rounded-lg bg-secondary/50 overflow-auto max-h-80 text-foreground break-all whitespace-pre-wrap">
                {result.bodyPreview}
              </pre>
            </CardContent>
          </Card>
            </>
          )}
        </div>
      )}
    </ToolPageLayout>
  );
}
