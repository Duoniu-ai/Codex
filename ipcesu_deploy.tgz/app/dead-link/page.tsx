"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Unlink } from "lucide-react";

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "正常", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "跳转", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "死链", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="死链检测"
      description="检测网站页面中的无效链接"
      icon={Unlink}
      tips={[
        "输入目标 URL 即可扫描页面内链接。",
        "可识别 404、500 等异常状态链接。",
        "帮助优化网站 SEO 和用户体验。",
        "仅扫描同域名链接，单次最多 30 个。",
        "JS 渲染的站点（SPA）可能检测不到链接。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      demo={false}
      onRun={async (values) => {
        const res = await fetch("/api/dead-link", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ target: values.url.trim() }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "检测失败");
        return data;
      }}
      renderResult={(result) => {
        const data = result as {
          total: number;
          dead: number;
          redirect: number;
          deadLinks: { url: string; code: number }[];
        };
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">扫描链接</div><div className="text-2xl font-semibold">{data.total}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">死链</div><div className="text-2xl font-semibold text-red-700">{data.dead}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">跳转</div><div className="text-2xl font-semibold text-amber-700">{data.redirect}</div></CardContent></Card>
            </div>
            <Card>
              <CardHeader>
                <CardTitle>死链列表</CardTitle>
                <CardDescription>检测到的异常链接</CardDescription>
              </CardHeader>
              <CardContent>
                {data.deadLinks.length === 0 ? (
                  <div className="text-sm text-muted-foreground">未发现死链，继续保持。</div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>链接</TableHead>
                        <TableHead>状态码</TableHead>
                        <TableHead>结果</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {data.deadLinks.map((item, idx) => (
                        <TableRow key={idx}>
                          <TableCell className="whitespace-normal max-w-xs break-all">{item.url}</TableCell>
                          <TableCell>{item.code}</TableCell>
                          <TableCell>{statusBadge("risk")}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}
