"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { FileSearch } from "lucide-react";

interface RobotsResult {
  url: string;
  robotsUrl: string;
  robotsStatus: number;
  robotsContent: string;
  targetPath: string;
  allowed: boolean;
  matchedRule: string;
  checks: Array<{ name: string; status: "pass" | "warn" | "risk"; detail: string }>;
}

function statusBadge(status: "pass" | "warn" | "risk") {
  const config = {
    pass: { text: "合规", cls: "bg-green-100 text-green-700 border-green-200" },
    warn: { text: "注意", cls: "bg-amber-100 text-amber-700 border-amber-200" },
    risk: { text: "风险", cls: "bg-red-100 text-red-700 border-red-200" },
  };
  return <Badge variant="outline" className={config[status].cls}>{config[status].text}</Badge>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="Robots 检测"
      description="爬虫规则分析"
      icon={FileSearch}
      tips={[
        "输入目标 URL，工具自动抓取并解析该站点的 robots.txt。",
        "检查目标路径是否被误屏蔽、Sitemap 是否声明。",
        "结合 meta robots 判断搜索引擎收录条件。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com/about" },
      ]}
      demo={false}
      onRun={async (values) => {
        const res = await fetch("/api/robots-txt", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ target: values.url.trim() }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "检测失败");
        return data as RobotsResult;
      }}
      renderResult={(result) => {
        const data = result as RobotsResult;
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">robots.txt</div><div className="text-2xl font-semibold">{data.robotsStatus || "--"}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">目标路径</div><div className="font-mono text-sm font-medium mt-1 break-all">{data.targetPath}</div></CardContent></Card>
              <Card><CardContent className="pt-6"><div className="text-sm text-muted-foreground">抓取权限</div><div className="mt-1">{statusBadge(data.allowed ? "pass" : "risk")}</div></CardContent></Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>规则分析</CardTitle>
                <CardDescription>robots.txt 配置检查</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>检查项</TableHead>
                      <TableHead>状态</TableHead>
                      <TableHead>说明</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.checks.map((c) => (
                      <TableRow key={c.name}>
                        <TableCell>{c.name}</TableCell>
                        <TableCell>{statusBadge(c.status)}</TableCell>
                        <TableCell className="whitespace-normal text-muted-foreground">{c.detail}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            {data.robotsContent && (
              <Card>
                <CardHeader>
                  <CardTitle>robots.txt 内容</CardTitle>
                </CardHeader>
                <CardContent>
                  <pre className="text-xs font-mono p-3 rounded-lg bg-secondary/50 overflow-auto max-h-48 text-foreground">
                    {data.robotsContent}
                  </pre>
                </CardContent>
              </Card>
            )}
          </div>
        );
      }}
    />
  );
}
