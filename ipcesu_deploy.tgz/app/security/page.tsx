"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { ChecksResult } from "@/components/tools/checks-result";
import { Card, CardContent } from "@/components/ui/card";
import { Shield } from "lucide-react";

interface SecurityResult {
  url: string;
  finalUrl: string;
  score: number;
  server: string;
  tls: {
    tlsVersion: string;
    cipher: string;
    validTo: string;
    daysRemaining: number;
  };
  checks: Array<{ name: string; status: "pass" | "warn" | "risk"; detail: string }>;
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="网站安全检测"
      description="安全配置分析"
      icon={Shield}
      tips={[
        "检查 HTTPS、HSTS、CSP、X-Frame-Options 等安全响应头。",
        "检测 TLS 协议版本、加密套件与证书有效期。",
        "检测由服务器真实请求与 TLS 握手完成。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      demo={false}
      onRun={async (values) => {
        const res = await fetch("/api/security", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ target: values.url.trim() }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "检测失败");
        return data as SecurityResult;
      }}
      renderResult={(result) => {
        const data = result as SecurityResult;
        return (
          <ChecksResult score={data.score} checks={data.checks}>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground">服务器</div>
                  <div className="font-mono text-sm font-medium mt-1 break-all">{data.server}</div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground">TLS 协议</div>
                  <div className="text-sm font-medium mt-1">{data.tls.tlsVersion}</div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground">加密套件</div>
                  <div className="font-mono text-xs font-medium mt-1 break-all">{data.tls.cipher}</div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground">证书剩余</div>
                  <div className="text-sm font-medium mt-1">{data.tls.daysRemaining} 天</div>
                </CardContent>
              </Card>
            </div>
          </ChecksResult>
        );
      }}
    />
  );
}
