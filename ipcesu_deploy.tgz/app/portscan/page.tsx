"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Scan, Network, Server, Shield, CheckCircle, Lock } from "lucide-react";

interface PortItem {
  port: number;
  service: string;
  status: "open" | "closed" | "timeout";
}

interface PortscanResult {
  target: string;
  resolvedIp: string;
  total: number;
  openCount: number;
  closedCount: number;
  timeoutCount: number;
  ports: PortItem[];
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="端口扫描"
      description="主机端口检测"
      icon={Scan}
      tips={[
        "输入主机地址，扫描常见端口开放情况。",
        "默认扫描 80、443、22、21、25、3306、3389 等端口。",
        "端口开放意味着服务正在监听，但需结合安全策略判断。",
        "请仅对自有或授权主机进行扫描。",
      ]}
      inputs={[
        {
          id: "target",
          label: "目标主机",
          type: "text",
          placeholder: "例如：baidu.com 或 192.168.1.1",
        },
        {
          id: "ports",
          label: "端口列表",
          type: "text",
          placeholder: "例如：80,443,22,3306",
          defaultValue: "80,443,22,21,25,3306,3389",
        },
      ]}
      demo={false}
      onRun={async (values) => {
        const res = await fetch("/api/portscan", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            target: values.target.trim(),
            ports: values.ports,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "扫描失败");
        return data as PortscanResult;
      }}
      renderResult={(result) => {
        const data = result as PortscanResult;
        return (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-3">
              <Badge
                variant="secondary"
                className="bg-foreground text-background hover:bg-foreground/90 border-0"
              >
                {data.openCount} 个开放
              </Badge>
              <span className="text-sm text-muted-foreground flex items-center gap-1">
                <Server className="h-3.5 w-3.5" />
                解析 IP：{data.resolvedIp}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                    <Network className="h-4 w-4 text-foreground" />
                    扫描端口数
                  </div>
                  <div className="font-medium text-foreground">{data.total}</div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    开放
                  </div>
                  <div className="font-medium text-foreground">{data.openCount}</div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                    <Shield className="h-4 w-4 text-red-600" />
                    关闭
                  </div>
                  <div className="font-medium text-foreground">{data.closedCount}</div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                    <Lock className="h-4 w-4 text-amber-600" />
                    超时
                  </div>
                  <div className="font-medium text-foreground">
                    {data.timeoutCount}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3 text-muted-foreground text-sm">
                  <Lock className="h-4 w-4 text-foreground" />
                  端口详情
                </div>
                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-24">端口</TableHead>
                        <TableHead>服务</TableHead>
                        <TableHead className="w-24">状态</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {data.ports.map((item, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-mono text-foreground">
                            {item.port}
                          </TableCell>
                          <TableCell className="text-foreground">
                            {item.service}
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                item.status === "open" ? "default" : "secondary"
                              }
                              className={
                                item.status === "open"
                                  ? "bg-green-500/15 text-green-600 hover:bg-green-500/20 border-0"
                                  : item.status === "timeout"
                                  ? "bg-amber-500/15 text-amber-600 hover:bg-amber-500/20 border-0"
                                  : ""
                              }
                            >
                              {item.status === "open"
                                ? "开放"
                                : item.status === "timeout"
                                ? "超时"
                                : "关闭"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </div>
        );
      }}
    />
  );
}
