"use client";

import { useState, Suspense } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Copy, Clock, CheckCircle, XCircle, Globe, Server } from "lucide-react";

interface HttpItem {
  url: string;
  statusCode: number;
  statusText: string;
  totalTime: number;
  server: string;
}

interface BatchHttpResult {
  total: number;
  available: number;
  failed: number;
  items: HttpItem[];
}

export default function BatchHttpPage() {
  return (
    <Suspense fallback={<BatchHttpPageSkeleton />}>
      <BatchHttpPageForm />
    </Suspense>
  );
}

function BatchHttpPageSkeleton() {
  return (
    <ToolPageLayout
      title="批量 HTTP(S)"
      description="多目标批量 HTTP(S) 可用性检测"
      icon={Copy}
      tips={[
        "每行输入一个 URL 或域名，支持批量检测网站可用性。",
        "可自动补全 https:// 协议头。",
        "结果包含状态码、响应耗时和 Server 头。",
        "单次最多检测 20 个目标，检测由服务器真实请求执行。",
      ]}
    >
      <div className="space-y-3">
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    </ToolPageLayout>
  );
}

function BatchHttpPageForm() {
  const [targets, setTargets] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<BatchHttpResult | null>(null);
  const [error, setError] = useState("");

  const handleTest = async () => {
    const lines = targets.split("\n").map((line) => line.trim()).filter(Boolean);
    if (lines.length === 0) {
      setError("请至少输入一个 URL");
      return;
    }

    setLoading(true);
    setError("");
    setResult(null);

    try {
      const res = await fetch("/api/batch-http", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ targets: lines.slice(0, 20) }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "检测失败");
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "检测失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ToolPageLayout
      title="批量 HTTP(S)"
      description="多目标批量 HTTP(S) 可用性检测"
      icon={Copy}
      tips={[
        "每行输入一个 URL 或域名，支持批量检测网站可用性。",
        "可自动补全 https:// 协议头。",
        "结果包含状态码、响应耗时和 Server 头。",
        "单次最多检测 20 个目标，检测由服务器真实请求执行。",
      ]}
    >
      <Card className="border-border/40 bg-card shadow-sm">
        <CardContent className="p-5 space-y-5">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">URL 列表</label>
            <textarea
              value={targets}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setTargets(e.target.value)}
              placeholder="例如：&#10;https://baidu.com&#10;https://qq.com&#10;example.com"
              rows={6}
              className="w-full rounded-lg border border-input bg-secondary/50 px-3 py-2 text-sm placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 outline-none resize-none font-mono"
            />
            <p className="text-xs text-muted-foreground">
              每行一个 URL，自动补全 https://，最多 20 个
            </p>
          </div>
          <Button
            onClick={handleTest}
            disabled={loading}
            className="bg-foreground hover:bg-foreground/90 text-background"
          >
            {loading ? "检测中..." : "开始批量检测"}
          </Button>
        </CardContent>
      </Card>

      {error && (
        <div className="p-4 rounded-lg bg-destructive/10 text-destructive text-sm">
          {error}
        </div>
      )}

      {loading && (
        <Card className="border-border/40 bg-card shadow-sm">
          <CardContent className="p-5 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
            </div>
            <Skeleton className="h-48 w-full" />
          </CardContent>
        </Card>
      )}

      {result && !loading && (
        <div className="space-y-4 animate-fade-in-up">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Copy className="h-4 w-4 text-foreground" />
                  检测总数
                </div>
                <div className="font-medium text-foreground">{result.total}</div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  可用
                </div>
                <div className="font-medium text-foreground">{result.available}</div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <XCircle className="h-4 w-4 text-red-600" />
                  异常
                </div>
                <div className="font-medium text-foreground">{result.failed}</div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-3 text-muted-foreground text-sm">
                <Globe className="h-4 w-4 text-foreground" />
                检测结果
              </div>
              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>URL</TableHead>
                      <TableHead>状态码</TableHead>
                      <TableHead>Server</TableHead>
                      <TableHead>耗时</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {result.items.map((item, index) => {
                      const isSuccess = item.statusCode < 400;
                      return (
                        <TableRow key={index}>
                          <TableCell className="font-mono text-foreground break-all">
                            {item.url}
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant="outline"
                              className={
                                isSuccess
                                  ? "bg-green-500/15 text-green-600 border-0"
                                  : "bg-red-500/15 text-red-600 border-0"
                              }
                            >
                              {item.statusCode}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-foreground">
                            <span className="flex items-center gap-1">
                              <Server className="h-3.5 w-3.5 text-muted-foreground" />
                              {item.server}
                            </span>
                          </TableCell>
                          <TableCell className="text-foreground">
                            <span className="flex items-center gap-1">
                              <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                              {isSuccess ? `${item.totalTime.toFixed(0)} ms` : "--"}
                            </span>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </ToolPageLayout>
  );
}
