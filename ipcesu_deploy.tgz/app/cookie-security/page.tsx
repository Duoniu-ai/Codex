"use client";

import { SimulatedToolPage } from "@/components/tools/simulated-tool-page";
import { StatusBadge } from "@/components/tools/checks-result";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Cookie } from "lucide-react";

interface CookieItem {
  name: string;
  secure: boolean;
  httpOnly: boolean;
  sameSite: string | null;
  expires: string | null;
  checks: Array<{ name: string; status: "pass" | "warn" | "risk"; detail: string }>;
}

interface CookieSecurityResult {
  url: string;
  total: number;
  riskCount: number;
  cookies: CookieItem[];
}

export default function Page() {
  return (
    <SimulatedToolPage
      title="Cookie 安全"
      description="Cookie 安全配置检测"
      icon={Cookie}
      tips={[
        "真实请求目标站点，解析响应中的 Set-Cookie 属性。",
        "检查 Secure、HttpOnly、SameSite 三个关键属性。",
        "会话类 Cookie 应同时启用三项以降低安全风险。",
      ]}
      inputs={[
        { id: "url", label: "目标 URL/域名", type: "text", placeholder: "https://example.com" },
      ]}
      demo={false}
      onRun={async (values) => {
        const res = await fetch("/api/cookie-security", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ target: values.url.trim() }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "检测失败");
        return data as CookieSecurityResult;
      }}
      renderResult={(result) => {
        const data = result as CookieSecurityResult;
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground">Cookie 总数</div>
                  <div className="text-2xl font-semibold text-foreground">{data.total}</div>
                </CardContent>
              </Card>
              <Card className="border-border/50 bg-card">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground">风险项</div>
                  <div className="text-2xl font-semibold text-red-700">{data.riskCount}</div>
                </CardContent>
              </Card>
            </div>

            {data.cookies.length === 0 && (
              <Card>
                <CardContent className="p-5 text-sm text-muted-foreground">
                  未检测到 Set-Cookie 响应头（站点可能未设置 Cookie）。
                </CardContent>
              </Card>
            )}

            {data.cookies.map((cookie) => (
              <Card key={cookie.name} className="border-border/50 bg-card">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base font-mono break-all">{cookie.name}</CardTitle>
                  <CardDescription>
                    {cookie.secure && <Badge className="mr-1 bg-green-100 text-green-700 border-green-200">Secure</Badge>}
                    {cookie.httpOnly && <Badge className="mr-1 bg-green-100 text-green-700 border-green-200">HttpOnly</Badge>}
                    {cookie.sameSite && <Badge className="bg-amber-100 text-amber-700 border-amber-200">SameSite={cookie.sameSite}</Badge>}
                    {cookie.expires && <span className="text-xs">有效期至 {cookie.expires}</span>}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>属性</TableHead>
                        <TableHead>状态</TableHead>
                        <TableHead>说明</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {cookie.checks.map((check) => (
                        <TableRow key={check.name}>
                          <TableCell className="font-medium">{check.name}</TableCell>
                          <TableCell><StatusBadge status={check.status} /></TableCell>
                          <TableCell className="text-muted-foreground whitespace-normal">{check.detail}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            ))}
          </div>
        );
      }}
    />
  );
}
