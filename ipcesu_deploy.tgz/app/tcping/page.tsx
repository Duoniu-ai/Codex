"use client";

import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ToolPageLayout } from "@/components/tools/tool-page-layout";
import { Network, Server, Gauge, Percent, Activity, Globe } from "lucide-react";

interface TcpingResult {
  target: string;
  port: number;
  resolvedIp: string;
  status: "open" | "closed" | "timeout";
  avgLatency: number;
  packetLoss: number;
  node: string;
}

const commonPorts = [
  { port: 80, label: "HTTP" },
  { port: 443, label: "HTTPS" },
  { port: 22, label: "SSH" },
  { port: 3306, label: "MySQL" },
  { port: 3389, label: "RDP" },
  { port: 8080, label: "Proxy" },
];

export default function TcpingPage() {
  return (
    <Suspense fallback={<TcpingPageSkeleton />}>
      <TcpingPageForm />
    </Suspense>
  );
}

function TcpingPageSkeleton() {
  return (
    <ToolPageLayout
      title="TCPing"
      description="TCP 端口连通性检测"
      icon={Network}
      tips={[
        "输入域名或 IP 地址及目标端口，检测 TCP 连通性。",
        "常用端口：80（HTTP）、443（HTTPS）、22（SSH）、3306（MySQL）。",
        "端口开放表示目标服务正在监听该端口。",
        "检测结果受本地网络与目标防火墙策略影响。",
      ]}
    >
      <div className="space-y-3">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-12 w-full" />
      </div>
    </ToolPageLayout>
  );
}

function TcpingPageForm() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get("q") || "";

  const [target, setTarget] = useState(initialQuery);
  const [port, setPort] = useState("80");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<TcpingResult | null>(null);
  const [error, setError] = useState("");

  const handleTest = async () => {
    if (!target.trim()) {
      setError("请输入目标地址");
      return;
    }
    const portNum = parseInt(port, 10);
    if (!port || isNaN(portNum) || portNum < 1 || portNum > 65535) {
      setError("端口范围应为 1-65535");
      return;
    }

    setLoading(true);
    setError("");
    setResult(null);

    try {
      const res = await fetch("/api/tcping", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          target: target.trim(),
          port: portNum,
          count: 4,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "检测失败");
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "检测失败");
    } finally {
      setLoading(false);
    }
  };

  const statusConfig = {
    open: { label: "端口开放", color: "bg-green-500/15 text-green-600" },
    closed: { label: "端口关闭", color: "bg-red-500/15 text-red-600" },
    timeout: { label: "连接超时", color: "bg-amber-500/15 text-amber-600" },
  };

  return (
    <ToolPageLayout
      title="TCPing"
      description="TCP 端口连通性检测"
      icon={Network}
      tips={[
        "输入域名或 IP 地址及目标端口，检测 TCP 连通性。",
        "常用端口：80（HTTP）、443（HTTPS）、22（SSH）、3306（MySQL）。",
        "端口开放表示目标服务正在监听该端口。",
        "检测结果受本地网络与目标防火墙策略影响。",
      ]}
    >
      <Card className="border-border/40 bg-card shadow-sm">
        <CardContent className="p-5 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
            <div className="sm:col-span-7 space-y-2">
              <label className="text-sm font-medium text-foreground">目标地址</label>
              <Input
                value={target}
                onChange={(e) => setTarget(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleTest()}
                placeholder="例如：baidu.com 或 8.8.8.8"
                className="bg-secondary/50 border-border/50"
              />
            </div>
            <div className="sm:col-span-3 space-y-2">
              <label className="text-sm font-medium text-foreground">端口</label>
              <Input
                type="number"
                min={1}
                max={65535}
                value={port}
                onChange={(e) => setPort(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleTest()}
                placeholder="80"
                className="bg-secondary/50 border-border/50"
              />
            </div>
            <div className="sm:col-span-2 flex items-end">
              <Button
                onClick={handleTest}
                disabled={loading}
                className="w-full bg-foreground hover:bg-foreground/90 text-background"
              >
                {loading ? "检测中..." : "开始检测"}
              </Button>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <span className="text-xs text-muted-foreground py-1">常用端口：</span>
            {commonPorts.map((item) => (
              <button
                key={item.port}
                onClick={() => setPort(String(item.port))}
                className="text-xs px-2 py-1 rounded-md border border-border/50 bg-secondary/30 text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors"
              >
                {item.port} {item.label}
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {error && (
        <div className="p-4 rounded-lg bg-destructive/10 text-destructive text-sm">
          {error}
        </div>
      )}

      {loading && (
        <Card className="border-border/40 bg-card shadow-sm">
          <CardContent className="p-5 space-y-3">
            <Skeleton className="h-12 w-full" />
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
            </div>
          </CardContent>
        </Card>
      )}

      {result && !loading && (
        <div className="space-y-4 animate-fade-in-up">
          <div className="flex flex-wrap items-center gap-3">
            <Badge variant="outline" className={statusConfig[result.status].color}>
              {statusConfig[result.status].label}
            </Badge>
            <span className="text-sm text-muted-foreground flex items-center gap-1">
              <Globe className="h-3.5 w-3.5" />
              测试节点：{result.node}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Server className="h-4 w-4 text-foreground" />
                  解析 IP
                </div>
                <div className="font-medium font-mono text-foreground break-all">
                  {result.resolvedIp}
                </div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Network className="h-4 w-4 text-foreground" />
                  目标端口
                </div>
                <div className="font-medium text-foreground">{result.port}</div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Gauge className="h-4 w-4 text-foreground" />
                  平均延迟
                </div>
                <div className="font-medium text-foreground">
                  {result.status === "open" ? `${result.avgLatency.toFixed(2)} ms` : "--"}
                </div>
              </CardContent>
            </Card>
            <Card className="border-border/50 bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                  <Percent className="h-4 w-4 text-foreground" />
                  丢包率
                </div>
                <div className="font-medium text-foreground">
                  {result.packetLoss.toFixed(0)} %
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2 text-muted-foreground text-sm">
                <Activity className="h-4 w-4 text-foreground" />
                检测目标
              </div>
              <div className="font-medium font-mono text-foreground break-all">
                {result.target}:{result.port}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </ToolPageLayout>
  );
}
