import sharp from "sharp";
import fs from "fs";
import path from "path";

const root = path.resolve(process.cwd(), "public");

const fontFamily =
  "'PingFang SC', 'Microsoft YaHei', 'Noto Sans CJK SC', system-ui, sans-serif";

const ogSvg = `
<svg width="1200" height="630" viewBox="0 0 1200 630" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#0b1220"/>
      <stop offset="55%" stop-color="#0f2557"/>
      <stop offset="100%" stop-color="#1e3a8a"/>
    </linearGradient>
    <linearGradient id="accent" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#38bdf8"/>
      <stop offset="100%" stop-color="#818cf8"/>
    </linearGradient>
  </defs>
  <rect width="1200" height="630" fill="url(#bg)"/>
  <g opacity="0.5" stroke="#38bdf8" stroke-width="2">
    <line x1="120" y1="500" x2="280" y2="420"/>
    <line x1="280" y1="420" x2="420" y2="500"/>
    <line x1="420" y1="500" x2="560" y2="380"/>
    <line x1="560" y1="380" x2="700" y2="480"/>
    <line x1="700" y1="480" x2="860" y2="360"/>
    <line x1="860" y1="360" x2="1040" y2="470"/>
  </g>
  <g fill="#38bdf8">
    <circle cx="120" cy="500" r="6"/>
    <circle cx="280" cy="420" r="5"/>
    <circle cx="420" cy="500" r="6"/>
    <circle cx="560" cy="380" r="5"/>
    <circle cx="700" cy="480" r="6"/>
    <circle cx="860" cy="360" r="5"/>
    <circle cx="1040" cy="470" r="6"/>
  </g>
  <g fill="#818cf8">
    <circle cx="180" cy="120" r="8" opacity="0.7"/>
    <circle cx="1050" cy="110" r="10" opacity="0.7"/>
    <circle cx="980" cy="560" r="6" opacity="0.5"/>
  </g>
  <rect x="90" y="70" width="72" height="72" rx="16" fill="url(#accent)"/>
  <text x="106" y="122" font-family="'Arial Black', 'Microsoft YaHei', sans-serif" font-size="44" font-weight="900" fill="#0b1220">IP</text>
  <text x="200" y="210" font-family="${fontFamily}" font-size="66" font-weight="700" fill="#ffffff">IPcesu 工具站</text>
  <text x="202" y="272" font-family="${fontFamily}" font-size="30" fill="#94a3b8">免费在线网络检测与网站分析平台</text>
  <rect x="202" y="310" width="120" height="4" rx="2" fill="url(#accent)"/>
  <text x="202" y="370" font-family="${fontFamily}" font-size="26" fill="#cbd5e1">Ping · IP 查询 · DNS · SSL · Whois · 路由追踪 · 网站测速 · SEO 诊断</text>
  <text x="202" y="560" font-family="${fontFamily}" font-size="20" fill="#64748b">无需安装 · 打开即用 · 真实检测数据</text>
</svg>`;

const iconSvg = `
<svg width="180" height="180" viewBox="0 0 180 180" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#38bdf8"/>
      <stop offset="100%" stop-color="#6366f1"/>
    </linearGradient>
  </defs>
  <rect width="180" height="180" rx="36" fill="url(#g)"/>
  <text x="90" y="122" text-anchor="middle" font-family="'Arial Black', 'Microsoft YaHei', sans-serif" font-size="92" font-weight="900" fill="#ffffff">IP</text>
</svg>`;

const faviconSvg = `
<svg width="64" height="64" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#38bdf8"/>
      <stop offset="100%" stop-color="#6366f1"/>
    </linearGradient>
  </defs>
  <rect width="64" height="64" rx="14" fill="url(#g)"/>
  <text x="32" y="44" text-anchor="middle" font-family="'Arial Black', 'Microsoft YaHei', sans-serif" font-size="32" font-weight="900" fill="#ffffff">IP</text>
</svg>`;

await sharp(Buffer.from(ogSvg))
  .resize(1200, 630)
  .png()
  .toFile(path.join(root, "og-image.png"));

await sharp(Buffer.from(iconSvg))
  .resize(180, 180)
  .png()
  .toFile(path.join(root, "apple-touch-icon.png"));

fs.writeFileSync(path.join(root, "favicon.svg"), faviconSvg, "utf-8");

// Remove leftover Next.js boilerplate assets
const stale = ["next.svg", "vercel.svg", "globe.svg", "window.svg", "file.svg"];
for (const file of stale) {
  const target = path.join(root, file);
  if (fs.existsSync(target)) {
    fs.rmSync(target, { force: true });
    console.log("removed", file);
  }
}

console.log("brand assets generated:", [
  "og-image.png",
  "apple-touch-icon.png",
  "favicon.svg",
].join(", "));
