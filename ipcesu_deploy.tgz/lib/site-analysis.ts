import { performance } from "perf_hooks";

export interface PageFetchResult {
  url: string;
  finalUrl: string;
  statusCode: number;
  statusText: string;
  headers: Record<string, string>;
  html: string;
  size: number;
  totalTime: number;
  ttfb: number;
  redirectCount: number;
}

export function normalizeUrl(rawUrl: string): string {
  const trimmed = rawUrl.trim();
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  return `https://${trimmed}`;
}

export async function fetchPage(
  rawUrl: string,
  opts: {
    maxRedirects?: number;
    timeoutMs?: number;
    bodyLimit?: number;
  } = {}
): Promise<PageFetchResult> {
  const { maxRedirects = 5, timeoutMs = 15000, bodyLimit = 2_000_000 } = opts;
  const url = normalizeUrl(rawUrl);
  const parsed = new URL(url);
  if (!/^https?:$/.test(parsed.protocol)) {
    throw new Error("仅支持 HTTP / HTTPS 协议");
  }

  const start = performance.now();
  let currentUrl = url;
  let redirectCount = 0;
  let ttfb = 0;
  let finalStatus = 0;
  let finalStatusText = "";
  let headers: Record<string, string> = {};
  const chunks: Buffer[] = [];

  for (let i = 0; i <= maxRedirects; i++) {
    const res = await fetch(currentUrl, {
      redirect: "manual",
      signal: AbortSignal.timeout(timeoutMs),
      headers: {
        "User-Agent":
          "Mozilla/5.0 (compatible; IPcesuBot/1.0; +https://test.ipcesu.com)",
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
      },
    });
    if (ttfb === 0) ttfb = performance.now() - start;

    const location = res.headers.get("location");
    if (
      res.status >= 300 &&
      res.status < 400 &&
      location &&
      i < maxRedirects
    ) {
      redirectCount++;
      currentUrl = new URL(location, currentUrl).toString();
      continue;
    }

    finalStatus = res.status;
    finalStatusText = res.statusText;
    headers = Object.fromEntries(res.headers.entries());

    const reader = res.body?.getReader();
    let received = 0;
    while (reader) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(Buffer.from(value));
      received += value.byteLength;
      if (received > bodyLimit) break;
    }
    break;
  }

  const html = Buffer.concat(chunks).toString("utf-8");
  return {
    url,
    finalUrl: currentUrl,
    statusCode: finalStatus,
    statusText: finalStatusText,
    headers,
    html,
    size: Buffer.byteLength(html),
    totalTime: performance.now() - start,
    ttfb,
    redirectCount,
  };
}

export interface PageMeta {
  title: string;
  description: string;
  keywords: string;
  canonical: string | null;
  robots: string | null;
  viewport: string | null;
  charset: string | null;
  lang: string | null;
  h1Count: number;
  h1s: string[];
  ogTitle: string | null;
  ogDescription: string | null;
  ogImage: string | null;
  ogType: string | null;
  twitterCard: string | null;
  imagesTotal: number;
  imagesWithoutAlt: number;
  linkCount: number;
  scriptCount: number;
  styleCount: number;
  structuredDataCount: number;
  wordCount: number;
  links: string[];
}

function stripHtml(input: string): string {
  return input
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&[a-zA-Z#0-9]+;/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function countWords(input: string): number {
  const text = stripHtml(input);
  const cjk = (text.match(/[\u4e00-\u9fff]/g) || []).length;
  const latin = (text.match(/[a-zA-Z0-9]+/g) || []).length;
  return cjk + latin;
}

export function extractMeta(html: string, baseUrl: string): PageMeta {
  const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const metaTags = html.match(/<meta[^>]+>/gi) || [];
  const meta: Record<string, string> = {};
  for (const tag of metaTags) {
    const nameMatch =
      tag.match(/\b(?:name|property|http-equiv)=["']([^"']+)["']/i) || [];
    const contentMatch = tag.match(/\bcontent=["']([^"']*)["']/i);
    if (nameMatch[1] && contentMatch) {
      meta[nameMatch[1].toLowerCase()] = contentMatch[1];
    }
  }

  const canonicalMatch = html.match(
    /<link[^>]+rel=["']canonical["'][^>]*>/i
  );
  const canonicalHref = canonicalMatch?.[0].match(/\bhref=["']([^"']+)["']/i);

  const htmlLang = html.match(/<html[^>]+lang=["']([^"']+)["']/i);
  const h1Matches = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/gi) || [];
  const imageMatches = html.match(/<img[^>]+>/gi) || [];
  const linkMatches = html.match(/<a[^>]+href=["']([^"']+)["'][^>]*>/gi) || [];
  const scriptCount = (html.match(/<script[^>]*>/gi) || []).length;
  const styleCount =
    (html.match(/<style[^>]*>/gi) || []).length +
    (html.match(/<link[^>]+rel=["']stylesheet["'][^>]*>/gi) || []).length;
  const structuredDataCount = (
    html.match(/<script[^>]+type=["']application\/ld\+json["'][^>]*>/gi) ||
    []
  ).length;

  let imagesWithoutAlt = 0;
  for (const img of imageMatches) {
    if (!/\balt=["']/.test(img)) imagesWithoutAlt++;
  }

  const links: string[] = [];
  for (const a of linkMatches) {
    const href = a.match(/\bhref=["']([^"']+)["']/i)?.[1];
    if (href && !href.startsWith("#") && !href.startsWith("javascript:")) {
      try {
        links.push(new URL(href, baseUrl).toString());
      } catch {
        // ignore malformed
      }
    }
  }

  const h1s = h1Matches.map((h) =>
    stripHtml(h).slice(0, 100)
  );

  return {
    title: meta["og:title"] || stripHtml(titleMatch?.[1] || "").slice(0, 200),
    description: meta["description"] || meta["og:description"] || "",
    keywords: meta["keywords"] || "",
    canonical: canonicalHref?.[1] || null,
    robots: meta["robots"] || null,
    viewport: meta["viewport"] || null,
    charset:
      html.match(/<meta[^>]+charset=["']?([\w-]+)["']?/i)?.[1] || null,
    lang: htmlLang?.[1] || null,
    h1Count: h1Matches.length,
    h1s,
    ogTitle: meta["og:title"] || null,
    ogDescription: meta["og:description"] || null,
    ogImage: meta["og:image"] || null,
    ogType: meta["og:type"] || null,
    twitterCard: meta["twitter:card"] || null,
    imagesTotal: imageMatches.length,
    imagesWithoutAlt,
    linkCount: links.length,
    scriptCount,
    styleCount,
    structuredDataCount,
    wordCount: countWords(html),
    links,
  };
}

export type CheckStatus = "pass" | "warn" | "risk";

export interface SeoCheck {
  name: string;
  status: CheckStatus;
  detail: string;
}

function check(condition: boolean, name: string, pass: string, fail: string): SeoCheck {
  return {
    name,
    status: condition ? "pass" : "risk",
    detail: condition ? pass : fail,
  };
}

export function analyzeSeo(
  meta: PageMeta,
  page: Pick<PageFetchResult, "finalUrl" | "headers" | "statusCode">,
  baseUrl: string
): { score: number; checks: SeoCheck[] } {
  const checks: SeoCheck[] = [];

  checks.push(
    check(
      meta.title.length > 0,
      "页面标题",
      meta.title ? `已设置标题（${meta.title.length} 字）` : "",
      "未设置 <title> 标题"
    )
  );
  checks.push(
    check(
      meta.title.length >= 10 && meta.title.length <= 60,
      "标题长度",
      "标题长度符合 SEO 建议（10-60 字）",
      `标题长度 ${meta.title.length} 字，建议控制在 10-60 字`
    )
  );
  checks.push(
    check(
      meta.description.length > 0,
      "Meta Description",
      meta.description ? "已设置页面描述" : "",
      "未设置 meta description"
    )
  );
  checks.push(
    check(
      meta.description.length >= 50 && meta.description.length <= 160,
      "描述长度",
      "描述长度符合建议（50-160 字）",
      `描述长度 ${meta.description.length} 字，建议 50-160 字`
    )
  );
  checks.push(
    check(
      Boolean(meta.canonical),
      "Canonical 标签",
      "已设置 canonical 规范链接",
      "未设置 canonical 标签"
    )
  );
  checks.push(
    check(
      meta.h1Count === 1,
      "H1 标签",
      meta.h1Count === 1 ? "页面包含唯一 H1 标题" : "",
      meta.h1Count === 0
        ? "页面缺少 H1 标签"
        : `页面包含 ${meta.h1Count} 个 H1 标签，建议只保留一个`
    )
  );
  checks.push(
    check(
      Boolean(meta.viewport),
      "移动端适配",
      "已设置 viewport",
      "未设置 viewport，移动端显示可能异常"
    )
  );
  checks.push(
    check(
      !meta.robots?.includes("noindex"),
      "蜘蛛索引",
      meta.robots?.includes("noindex") ? "" : "页面允许搜索引擎索引",
      "页面设置了 noindex，搜索引擎将不收录"
    )
  );
  checks.push(
    check(
      meta.structuredDataCount > 0,
      "结构化数据",
      `检测到 ${meta.structuredDataCount} 处 JSON-LD 结构化数据`,
      "未检测到 JSON-LD 结构化数据"
    )
  );
  checks.push(
    check(
      meta.imagesWithoutAlt === 0,
      "图片 Alt 属性",
      meta.imagesWithoutAlt === 0 ? "所有图片均已设置 alt" : "",
      `${meta.imagesWithoutAlt}/${meta.imagesTotal} 张图片缺少 alt 属性`
    )
  );
  checks.push(
    check(
      page.finalUrl.startsWith("https://"),
      "HTTPS",
      "站点使用 HTTPS 加密",
      "站点未启用 HTTPS"
    )
  );
  checks.push(
    check(
      meta.wordCount >= 300,
      "内容量",
      `正文约 ${meta.wordCount} 字`,
      `正文仅约 ${meta.wordCount} 字，建议 ≥ 300 字`
    )
  );
  checks.push(
    check(
      Boolean(meta.ogTitle && meta.ogDescription && meta.ogImage),
      "Open Graph",
      "已配置 OG 社交分享标签",
      "缺少 og:title / og:description / og:image"
    )
  );
  checks.push(
    check(
      Boolean(meta.lang),
      "语言声明",
      `已声明语言 ${meta.lang}`,
      "未声明 <html lang> 语言属性"
    )
  );
  checks.push(
    check(
      page.statusCode < 400,
      "可访问性",
      `HTTP ${page.statusCode} 正常响应`,
      `HTTP ${page.statusCode} 访问异常`
    )
  );

  const passCount = checks.filter((c) => c.status === "pass").length;
  const score = Math.round((passCount / checks.length) * 100);
  return { score, checks };
}

export interface PerformanceMetrics {
  ttfb: number;
  totalTime: number;
  sizeKb: number;
  compressed: boolean;
  compression: string;
  cacheControl: string | null;
  gzip: boolean;
  lcpEstimate: number;
  inpEstimate: number;
  clsEstimate: number;
}

export function analyzePerformance(
  page: Pick<PageFetchResult, "ttfb" | "totalTime" | "size" | "headers">,
  meta: PageMeta
): PerformanceMetrics {
  const encoding = String(page.headers["content-encoding"] || "").toLowerCase();
  const cacheControl = page.headers["cache-control"] || null;
  const sizeKb = Math.round(page.size / 1024);
  const transferMs = Math.max(page.totalTime - page.ttfb, 0);
  // LCP 服务器端估算：TTFB + 传输 + 固定渲染开销
  const lcpEstimate = Math.round(page.ttfb + transferMs + 350);
  // INP 估算：脚本数量启发式
  const scriptFactor = Math.min(meta.scriptCount, 30);
  const inpEstimate =
    scriptFactor <= 3 ? 120 : scriptFactor <= 10 ? 250 : 400;
  // CLS 估算：无浏览器无法实测，基于图片占比给出保守估算
  const clsEstimate =
    meta.imagesTotal > 10 || meta.imagesWithoutAlt > 5 ? 0.15 : 0.05;

  return {
    ttfb: Math.round(page.ttfb),
    totalTime: Math.round(page.totalTime),
    sizeKb,
    compressed: Boolean(encoding),
    compression: encoding || "none",
    cacheControl,
    gzip: encoding === "gzip",
    lcpEstimate,
    inpEstimate,
    clsEstimate,
  };
}

export function statusText(code: number): string {
  const map: Record<number, string> = {
    200: "OK",
    201: "Created",
    204: "No Content",
    301: "Moved Permanently",
    302: "Found",
    304: "Not Modified",
    307: "Temporary Redirect",
    308: "Permanent Redirect",
    400: "Bad Request",
    401: "Unauthorized",
    403: "Forbidden",
    404: "Not Found",
    410: "Gone",
    429: "Too Many Requests",
    500: "Internal Server Error",
    502: "Bad Gateway",
    503: "Service Unavailable",
    504: "Gateway Timeout",
  };
  return map[code] || "Unknown";
}

export async function runWithConcurrency<T>(
  items: T[],
  limit: number,
  worker: (item: T, index: number) => Promise<void>
): Promise<void> {
  let cursor = 0;
  const workers = Array.from(
    { length: Math.min(limit, items.length) },
    async () => {
      while (cursor < items.length) {
        const index = cursor++;
        await worker(items[index], index);
      }
    }
  );
  await Promise.all(workers);
}
