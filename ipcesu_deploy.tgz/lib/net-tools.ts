import { execFile } from "child_process";
import { promisify } from "util";
import net from "net";
import fs from "fs";
import { lookup } from "dns/promises";

const execFileAsync = promisify(execFile);

export interface PingResult {
  target: string;
  resolvedIp: string;
  status: "success" | "timeout" | "error";
  avgLatency: number;
  minLatency: number;
  maxLatency: number;
  packetLoss: number;
  ttl: number | null;
  node: string;
}

export interface TcpingResult {
  target: string;
  port: number;
  resolvedIp: string;
  status: "open" | "closed" | "timeout";
  avgLatency: number;
  packetLoss: number;
  latencies: number[];
  node: string;
}

export interface ScannedPort {
  port: number;
  service: string;
  status: "open" | "closed" | "timeout";
}

export interface PortScanResult {
  target: string;
  resolvedIp: string;
  total: number;
  openCount: number;
  closedCount: number;
  timeoutCount: number;
  ports: ScannedPort[];
}

export interface TracerouteHop {
  hop: number;
  ip: string | null;
  loss: number;
  sent: number;
  last: number | null;
  avg: number | null;
  best: number | null;
  worst: number | null;
  stdev: number | null;
}

export interface TracerouteResult {
  target: string;
  resolvedIp: string;
  hops: TracerouteHop[];
  node: string;
}

const SERVICE_MAP: Record<number, string> = {
  20: "FTP-DATA",
  21: "FTP",
  22: "SSH",
  23: "Telnet",
  25: "SMTP",
  53: "DNS",
  80: "HTTP",
  110: "POP3",
  143: "IMAP",
  443: "HTTPS",
  445: "SMB",
  465: "SMTPS",
  587: "SMTP",
  993: "IMAPS",
  995: "POP3S",
  1080: "SOCKS",
  1433: "MSSQL",
  1521: "Oracle",
  2049: "NFS",
  2375: "Docker",
  3000: "HTTP-Alt",
  3306: "MySQL",
  3389: "RDP",
  5432: "PostgreSQL",
  5900: "VNC",
  6379: "Redis",
  6443: "Kubernetes",
  8000: "HTTP-Alt",
  8080: "HTTP-Alt",
  8443: "HTTPS-Alt",
  8888: "HTTP-Alt",
  9000: "PHP-FPM",
  9200: "Elasticsearch",
  11211: "Memcached",
  27017: "MongoDB",
};

export function serviceName(port: number): string {
  return SERVICE_MAP[port] || "未知服务";
}

export function sanitizeHost(input: string): string {
  const trimmed = input.trim().replace(/^https?:\/\//i, "").split("/")[0];
  return trimmed.replace(/:\d+$/, "").replace(/\.$/, "");
}

export function isIpv4(host: string): boolean {
  const parts = host.split(".");
  if (parts.length !== 4) return false;
  return parts.every((part) => {
    if (!/^\d{1,3}$/.test(part)) return false;
    const n = parseInt(part, 10);
    return n >= 0 && n <= 255;
  });
}

export function isIpv6(host: string): boolean {
  return host.includes(":") && /^[0-9a-fA-F:.%]+$/.test(host);
}

export function isValidHostnameOrIp(host: string): boolean {
  if (!host || host.length > 253) return false;
  if (isIpv4(host) || isIpv6(host)) return true;
  return /^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*$/.test(
    host
  );
}

export async function resolveHost(
  host: string,
  family?: 4 | 6
): Promise<string> {
  const { address } = await lookup(host, family ? { family, verbatim: true } : {});
  return address;
}

export async function resolveAddresses(
  host: string,
  family: 4 | 6
): Promise<string[]> {
  try {
    const records = await lookup(host, { family, all: true, verbatim: true });
    return records.map((r) => r.address);
  } catch {
    return [];
  }
}

export async function serverHasIpv6(): Promise<boolean> {
  try {
    const content = fs.readFileSync("/proc/net/if_inet6", "utf-8");
    const hasGlobal = content.split("\n").some((line) => {
      const parts = line.trim().split(/\s+/);
      const addr = parts[0] || "";
      return addr !== "" && addr !== "00000000000000000000000000000001";
    });
    if (!hasGlobal) return false;
  } catch {
    // /proc not available — fall through to a live probe
  }
  try {
    await execFileAsync("ping6", ["-c", "1", "-W", "2", "2400:da00::666"], {
      timeout: 5000,
    });
    return true;
  } catch {
    return false;
  }
}

function parsePingOutput(
  output: string,
  fallbackIp: string
): {
  resolvedIp: string;
  avgLatency: number;
  minLatency: number;
  maxLatency: number;
  packetLoss: number;
  ttl: number | null;
} {
  let resolvedIp = fallbackIp;
  let avgLatency = 0;
  let minLatency = 0;
  let maxLatency = 0;
  let packetLoss = 0;
  let ttl: number | null = null;

  for (const line of output.split("\n")) {
    const ipMatch =
      line.match(/\(([0-9a-fA-F.:]+)\)/) ||
      line.match(/from\s+([0-9a-fA-F.:]+)/);
    if (ipMatch) resolvedIp = ipMatch[1].replace(/:$/, "");

    const lossMatch = line.match(/(\d+(?:\.\d+)?)% packet loss/);
    if (lossMatch) packetLoss = parseFloat(lossMatch[1]);

    const rttMatch =
      line.match(/rtt[^=]*=\s*([\d.]+)\/([\d.]+)\/([\d.]+)\/([\d.]+)/) ||
      line.match(
        /round-trip[^=]*=\s*([\d.]+)\/([\d.]+)\/([\d.]+)\/([\d.]+)/
      );
    if (rttMatch) {
      minLatency = parseFloat(rttMatch[1]);
      avgLatency = parseFloat(rttMatch[2]);
      maxLatency = parseFloat(rttMatch[3]);
    }

    const ttlMatch = line.match(/ttl=(\d+)/i);
    if (ttlMatch) ttl = parseInt(ttlMatch[1], 10);
  }

  return {
    resolvedIp,
    avgLatency,
    minLatency,
    maxLatency,
    packetLoss,
    ttl,
  };
}

export async function runPing(
  target: string,
  opts: {
    count?: number;
    family?: 4 | 6;
    timeoutSec?: number;
    node?: string;
  } = {}
): Promise<PingResult> {
  const { count = 4, family = 4, timeoutSec = 3, node = "默认节点" } = opts;
  const host = sanitizeHost(target);
  if (!isValidHostnameOrIp(host)) {
    throw new Error("请输入有效的域名或 IP 地址");
  }

  let resolvedIp: string;
  try {
    resolvedIp = await resolveHost(host, family);
  } catch {
    throw new Error(
      family === 6 ? "无法解析该域名的 IPv6 地址" : "无法解析该域名"
    );
  }

  const bin = family === 6 ? "ping6" : "ping";
  try {
    const { stdout } = await execFileAsync(
      bin,
      ["-c", String(count), "-W", String(timeoutSec), resolvedIp],
      { timeout: count * timeoutSec * 1000 + 5000, maxBuffer: 1024 * 1024 }
    );
    return {
      target: host,
      ...parsePingOutput(stdout, resolvedIp),
      status: "success",
      node,
    };
  } catch (err) {
    const stdout = (err as { stdout?: string }).stdout || "";
    if (stdout) {
      const parsed = parsePingOutput(stdout, resolvedIp);
      return {
        target: host,
        ...parsed,
        status: parsed.packetLoss >= 100 ? "timeout" : "success",
        node,
      };
    }
    throw new Error("Ping 执行失败");
  }
}

export function tcpingProbe(
  host: string,
  port: number,
  timeoutMs = 3000,
  family?: 4 | 6
): Promise<{ status: "open" | "closed" | "timeout"; latency: number }> {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    const start = Date.now();
    let settled = false;
    const finish = (
      status: "open" | "closed" | "timeout",
      latency = 0
    ) => {
      if (!settled) {
        settled = true;
        socket.destroy();
        resolve({ status, latency });
      }
    };

    socket.setTimeout(timeoutMs);
    socket.once("connect", () => finish("open", Date.now() - start));
    socket.once("timeout", () => finish("timeout"));
    socket.once("error", (err: NodeJS.ErrnoException) => {
      finish(err.code === "ECONNREFUSED" ? "closed" : "timeout");
    });
    socket.connect({ host, port, family });
  });
}

export async function runTcping(
  target: string,
  port: number,
  opts: {
    count?: number;
    timeoutMs?: number;
    family?: 4 | 6;
    node?: string;
  } = {}
): Promise<TcpingResult> {
  const { count = 4, timeoutMs = 3000, family, node = "默认节点" } = opts;
  const host = sanitizeHost(target);
  if (!isValidHostnameOrIp(host)) {
    throw new Error("请输入有效的域名或 IP 地址");
  }
  if (!port || port < 1 || port > 65535) {
    throw new Error("端口范围应为 1-65535");
  }

  let resolvedIp: string;
  try {
    resolvedIp = await resolveHost(host, family);
  } catch {
    throw new Error("无法解析该域名");
  }

  const latencies: number[] = [];
  let closed = 0;
  for (let i = 0; i < count; i++) {
    const result = await tcpingProbe(resolvedIp, port, timeoutMs, family);
    if (result.status === "open") latencies.push(result.latency);
    if (result.status === "closed") closed++;
  }

  const packetLoss = ((count - latencies.length) / count) * 100;
  let status: TcpingResult["status"] = "open";
  if (latencies.length === 0) {
    status = closed >= count ? "closed" : "timeout";
  }
  const avgLatency =
    latencies.length > 0
      ? latencies.reduce((a, b) => a + b, 0) / latencies.length
      : 0;

  return {
    target: host,
    port,
    resolvedIp,
    status,
    avgLatency,
    packetLoss,
    latencies,
    node,
  };
}

export async function scanPorts(
  target: string,
  ports: number[],
  opts: {
    timeoutMs?: number;
    concurrency?: number;
    family?: 4 | 6;
  } = {}
): Promise<PortScanResult> {
  const { timeoutMs = 1500, concurrency = 10, family } = opts;
  const host = sanitizeHost(target);
  if (!isValidHostnameOrIp(host)) {
    throw new Error("请输入有效的主机地址");
  }
  if (ports.length === 0) {
    throw new Error("请至少输入一个端口");
  }

  const resolvedIp = await resolveHost(host, family);
  const results: ScannedPort[] = [];
  let cursor = 0;
  const workerCount = Math.min(concurrency, ports.length);
  const workers = Array.from({ length: workerCount }, async () => {
    while (cursor < ports.length) {
      const port = ports[cursor++];
      const probe = await tcpingProbe(resolvedIp, port, timeoutMs, family);
      results.push({
        port,
        service: serviceName(port),
        status: probe.status,
      });
    }
  });
  await Promise.all(workers);
  results.sort((a, b) => a.port - b.port);

  return {
    target: host,
    resolvedIp,
    total: results.length,
    openCount: results.filter((p) => p.status === "open").length,
    closedCount: results.filter((p) => p.status === "closed").length,
    timeoutCount: results.filter((p) => p.status === "timeout").length,
    ports: results,
  };
}

export async function runTraceroute(
  target: string,
  family: 4 | 6 = 4,
  node = "默认节点"
): Promise<TracerouteResult> {
  const host = sanitizeHost(target);
  if (!isValidHostnameOrIp(host)) {
    throw new Error("请输入有效的域名或 IP 地址");
  }

  const resolvedIp = await resolveHost(host, family);
  const args = ["-r", "-c", "3", "-m", "20", "-n"];
  if (family === 6) args.push("-6");
  args.push(resolvedIp);

  const { stdout } = await execFileAsync("mtr", args, {
    timeout: 90000,
    maxBuffer: 4 * 1024 * 1024,
  });

  const hops: TracerouteHop[] = [];
  for (const line of stdout.split("\n")) {
    const match = line.match(
      /^\s*(\d+)\.\|--\s+(\S+)\s+([\d.]+)%\s+(\d+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)/
    );
    if (!match) continue;
    hops.push({
      hop: parseInt(match[1], 10),
      ip: match[2] === "???" ? null : match[2],
      loss: parseFloat(match[3]),
      sent: parseInt(match[4], 10),
      last: parseFloat(match[5]),
      avg: parseFloat(match[6]),
      best: parseFloat(match[7]),
      worst: parseFloat(match[8]),
      stdev: parseFloat(match[9]),
    });
  }

  if (hops.length === 0) {
    throw new Error("路由追踪未获取到有效数据");
  }

  return { target: host, resolvedIp, hops, node };
}
